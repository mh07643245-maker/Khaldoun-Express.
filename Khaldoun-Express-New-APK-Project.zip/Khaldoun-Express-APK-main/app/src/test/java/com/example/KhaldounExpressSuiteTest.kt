package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import androidx.test.core.app.ApplicationProvider
import com.example.backup.BackupManager
import com.example.bulkpaste.BulkPasteImporter
import com.example.database.LocalDatabase
import com.example.excelimport.ExcelImporter
import com.example.pdf.ArabicPdfExporter
import com.example.reports.ReportType
import com.example.reports.ReportsManager
import com.example.repositories.DraftShipmentInput
import com.example.repositories.ShipmentRepository
import com.example.shipments.CompanyFolder
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.ShipmentSource
import com.example.shipments.ShipmentStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KhaldounExpressSuiteTest {

    private lateinit var context: Context
    private lateinit var db: LocalDatabase
    private lateinit var repo: ShipmentRepository
    private lateinit var reportsManager: ReportsManager
    private lateinit var backupManager: BackupManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = LocalDatabase.createInMemoryForTest(context)
        repo = ShipmentRepository(db)
        reportsManager = ReportsManager(repo)
        backupManager = BackupManager(context, db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    // 1. توحيد الأرقام العربية والإنجليزية + 2. الحفاظ على الصفر الأول
    @Test
    fun `normalize arabic and western numerals while preserving leading zero`() {
        val arabicPhone = "٠١٠١٢٣٤٥٦٧٨"
        val westernPhone = "01234567890"
        val intlPhone = "+20 111 222 3333"

        val normArabic = PhoneNumberNormalizer.normalize(arabicPhone)
        val normWestern = PhoneNumberNormalizer.normalize(westernPhone)
        val normIntl = PhoneNumberNormalizer.normalize(intlPhone)

        assertEquals("01012345678", normArabic)
        assertTrue(normArabic.startsWith("0"))
        assertEquals("01234567890", normWestern)
        assertTrue(normWestern.startsWith("0"))
        assertEquals("01112223333", normIntl)
        assertEquals("45678", PhoneNumberNormalizer.extractLast5Digits(arabicPhone))
        assertEquals("67890", PhoneNumberNormalizer.extractLast5Digits(westernPhone))
    }

    // 3. البحث بآخر 5 أرقام + 4. التعامل مع الأرقام المتكررة
    @Test
    fun `search by last 5 digits handles duplicate endings without unique collision`() = runBlocking {
        val compId = repo.addCompany("شركة النور")
        repo.saveShipmentBatch(
            companyId = compId,
            items = listOf(
                DraftShipmentInput("أحمد محمد", "01000012345", "برج العرب", 450.0),
                DraftShipmentInput("محمود علي", "01199912345", "الإسكندرية", 600.0)
            ),
            source = ShipmentSource.MANUAL,
            batchId = ""
        )

        val matches = repo.findByScannedPhoneOrLast5("12345")
        assertEquals(2, matches.size)
        assertNotEquals(matches[0].shipment.id, matches[1].shipment.id)

        val searchFlowResults = repo.observeSearchShipments("١٢٣٤٥").first()
        assertEquals(2, searchFlowResults.size)
    }

    // 5. إضافة شركة + 6. إضافة شحنة + 7. تعديل شحنة + 8. حذف شحنة
    @Test
    fun `company and shipment crud with edit history and permanent delete`() = runBlocking {
        val compId = repo.addCompany("بوسطة إكسبريس", code = "BST", contactPhone = "01022334455")
        assertTrue(compId > 0L)

        repo.addSingleShipment(compId, "كريم حسن", "01234567890", "مجمع الأحياء", 350.0)
        val list = repo.observeActiveShipmentsByCompany(compId).first()
        assertEquals(1, list.size)
        val shipmentId = list.first().shipment.id
        assertEquals(ShipmentStatus.INITIAL.code, list.first().shipment.statusCode)
        assertEquals(CompanyFolder.DELIVERED.code, list.first().shipment.folder)

        repo.updateShipmentDetails(
            shipmentId = shipmentId,
            customerName = "كريم حسن المعدل",
            rawPhone = "01234567890",
            address = "برج العرب الجديدة",
            originalPrice = 350.0,
            deliveredPrice = 350.0,
            status = ShipmentStatus.DELIVERED,
            notes = "تم التعديل",
            folder = CompanyFolder.DELIVERED
        )

        val updated = repo.observeShipmentById(shipmentId).first()!!
        assertEquals("كريم حسن المعدل", updated.shipment.customerName)
        val history = repo.observeEditHistoryForShipment(shipmentId).first()
        assertTrue(history.any { it.fieldName == "اسم العميل" })

        repo.deleteShipmentPermanently(shipmentId)
        val afterDelete = repo.observeActiveShipmentsByCompany(compId).first()
        assertTrue(afterDelete.isEmpty())
    }

    // 9. استيراد أوردرات متعددة بالنسخ واللصق + 10. معالجة السطور الناقصة + 11. الحفاظ على الأسعار
    @Test
    fun `bulk paste imports large batch preserves prices and flags incomplete lines`() = runBlocking {
        val raw = buildString {
            appendLine("أحمد محمد\t01234567890\tبرج العرب القديم بجوار السوق\t450")
            appendLine("محمود علي\t٠١٠١٢٣٤٥٦٧٨\tبرج العرب الجديدة شارع المركز\t600")
            appendLine("سطر ناقص\t01122") // incomplete row — must NOT be silently dropped!
        }

        val parsed = BulkPasteImporter.parseTabSeparatedBatch(raw)
        assertEquals(3, parsed.totalDetected)
        assertEquals(2, parsed.validCount)
        assertEquals(1, parsed.needsReviewCount)
        assertEquals("01234567890", parsed.rows[0].rawPhone)
        assertEquals("٠١٠١٢٣٤٥٦٧٨", parsed.rows[1].rawPhone)
        assertEquals(450.0, parsed.rows[0].parsedPrice!!, 0.001)
        assertEquals(600.0, parsed.rows[1].parsedPrice!!, 0.001)
        assertTrue(parsed.rows[2].needsReview)

        val compId = repo.addCompany("شركة الدلتا")
        val savable = parsed.rows.filter { it.isSavable }.map {
            DraftShipmentInput(it.customerName, it.rawPhone, it.address, it.parsedPrice!!, it.needsReview)
        }
        val firstSave = repo.saveShipmentBatch(compId, savable, ShipmentSource.BULK_PASTE, parsed.batchId)
        assertEquals(2, firstSave.insertedCount)
        assertFalse(firstSave.duplicateBatchBlocked)

        // Prevent accidental double save of identical batch
        val duplicateSave = repo.saveShipmentBatch(compId, savable, ShipmentSource.BULK_PASTE, parsed.batchId)
        assertTrue(duplicateSave.duplicateBatchBlocked)
        assertEquals(0, duplicateSave.insertedCount)
    }

    // 12. استيراد Excel مع اختلاف ترتيب الأعمدة والحفاظ على الصفر الأول
    @Test
    fun `excel importer reads reordered xlsx columns and preserves leading zeros`() {
        val xlsxBytes = createSampleXlsxBytes()
        val res = ExcelImporter.parseXlsxStream(ByteArrayInputStream(xlsxBytes), "orders.xlsx")

        assertEquals(2, res.rows.size)
        assertEquals("سارة إبراهيم", res.rows[0].customerName)
        assertEquals("01098765432", res.rows[0].rawPhone)
        assertEquals(750.0, res.rows[0].parsedPrice!!, 0.001)
        assertEquals("الإسكندرية سموحة", res.rows[0].address)

        // Second row had numeric phone without leading zero stored by Excel -> recovered to 011...
        assertEquals("01122334455", res.rows[1].rawPhone)
        assertEquals(520.5, res.rows[1].parsedPrice!!, 0.001)
    }

    // 13. نقل الشحنة من المسلم إلى الحالات + الحفاظ على السعر الأصلي
    @Test
    fun `stock handling moves any processed shipment to cases folder and preserves original price`() = runBlocking {
        val compId = repo.addCompany("الفتح للشحن")
        repo.addSingleShipment(compId, "طارق سعيد", "01555667788", "العجمي", 900.0)
        val initial = repo.observeActiveShipmentsByCompany(compId).first().first()
        assertEquals(CompanyFolder.DELIVERED.code, initial.shipment.folder)

        // Even when status is DELIVERED ("تم التسليم"), handling in Stock moves it to CASES ("الحالات")
        repo.handleShipmentInStock(
            shipmentId = initial.shipment.id,
            deliveredPrice = 0.0,
            status = ShipmentStatus.POSTPONED,
            noteText = "لا يرد"
        )

        val updated = repo.observeShipmentById(initial.shipment.id).first()!!
        assertEquals(CompanyFolder.CASES.code, updated.shipment.folder)
        assertEquals(ShipmentStatus.POSTPONED.code, updated.shipment.statusCode)
        assertEquals(900.0, updated.shipment.originalPrice, 0.001)
        assertEquals(0.0, updated.shipment.deliveredPrice, 0.001)
        assertEquals("لا يرد", updated.shipment.notes)
    }

    // 14. حساب الإجماليات + 15. إنشاء التقارير + 16. إنشاء PDF عربي
    @Test
    @Config(sdk = [36], shadows = [TestShadowPdfDocument::class])
    fun `totals reports and arabic rtl pdf export work end to end`() = runBlocking {
        val compId = repo.addCompany("إكسبرس مصر")
        repo.saveShipmentBatch(
            companyId = compId,
            items = listOf(
                DraftShipmentInput("عميل 1", "01011112222", "القاهرة", 400.0),
                DraftShipmentInput("عميل 2", "01033334444", "الجيزة", 600.0)
            ),
            source = ShipmentSource.MANUAL,
            batchId = ""
        )
        val shipments = repo.observeActiveShipmentsByCompany(compId).first()
        repo.handleShipmentInStock(shipments[0].shipment.id, 400.0, ShipmentStatus.DELIVERED, "تم بنجاح")

        val dashboard = repo.observeDashboardSummary().first()
        assertEquals(2, dashboard.totalTodayShipments)
        assertEquals(1, dashboard.deliveredFolderCount)
        assertEquals(1, dashboard.casesFolderCount)
        assertEquals(1000.0, dashboard.totalOriginalPrice, 0.001)
        assertEquals(400.0, dashboard.totalDeliveredPrice, 0.001)

        val report = reportsManager.generateActiveReport(ReportType.ALL_COMPANIES)
        assertEquals(2, report.totalCount)
        assertEquals(1000.0, report.totalOriginalPrice, 0.001)
        assertEquals(400.0, report.totalDeliveredPrice, 0.001)

        val casesReport = reportsManager.generateActiveReport(ReportType.COMPANY_CASES, companyId = compId)
        assertEquals(1, casesReport.totalCount)

        val pdfFile = ArabicPdfExporter.exportReportToPdf(context, report, NumeralStyle.WESTERN)
        assertTrue(pdfFile.exists())
        assertTrue(pdfFile.length() > 500L)
        val header = pdfFile.inputStream().use { it.readNBytes(5).decodeToString() }
        assertEquals("%PDF-", header)
    }

    // 17. حفظ واستعادة النسخ الاحتياطية + إنهاء اليوم والحفاظ على الأرشيف
    @Test
    fun `backup restore and end of day archiving preserve historical records`() = runBlocking {
        val compId = repo.addCompany("شركة الأمان")
        repo.addSingleShipment(compId, "منى خالد", "01200011122", "طنطا", 820.0)

        val backupRes = backupManager.createLocalBackup("MANUAL_LOCAL")
        assertTrue(backupRes.success)
        assertEquals(1, backupRes.shipmentCount)

        // Archive day (End of Day)
        repo.archiveDayAfterBackup("2026-11-12", backupRes.filePath, "{}")
        val activeAfterEod = repo.observeActiveShipments().first()
        assertTrue(activeAfterEod.isEmpty())

        val archivedReport = reportsManager.generateArchivedReport("2026-11-12")
        assertEquals(1, archivedReport.totalCount)
        assertEquals(820.0, archivedReport.totalOriginalPrice, 0.001)

        // Delete active & restore from backup file -> original pre-EOD active shipment restored!
        val restoreRes = backupManager.restoreFromLocalFile(backupRes.filePath)
        assertTrue(restoreRes.success)
        val activeAfterRestore = repo.observeActiveShipments().first()
        assertEquals(1, activeAfterRestore.size)
        assertEquals("منى خالد", activeAfterRestore.first().shipment.customerName)
    }

    private fun createSampleXlsxBytes(): ByteArray {
        val sharedStringsXml = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="7" uniqueCount="7">
              <si><t>السعر</t></si>
              <si><t>رقم الهاتف</t></si>
              <si><t>العنوان</t></si>
              <si><t>اسم العميل</t></si>
              <si><t>سارة إبراهيم</t></si>
              <si><t>01098765432</t></si>
              <si><t>الإسكندرية سموحة</t></si>
            </sst>
        """.trimIndent()

        val workbookXml = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
              <sheets>
                <sheet name="Orders" sheetId="1" r:id="rId1"/>
              </sheets>
            </workbook>
        """.trimIndent()

        val relsXml = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
            </Relationships>
        """.trimIndent()

        // Columns intentionally reordered: A=Price, B=Phone, C=Address, D=CustomerName
        val sheetXml = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
              <sheetData>
                <row r="1">
                  <c r="A1" t="s"><v>0</v></c>
                  <c r="B1" t="s"><v>1</v></c>
                  <c r="C1" t="s"><v>2</v></c>
                  <c r="D1" t="s"><v>3</v></c>
                </row>
                <row r="2">
                  <c r="A2"><v>750</v></c>
                  <c r="B2" t="s"><v>5</v></c>
                  <c r="C2" t="s"><v>6</v></c>
                  <c r="D2" t="s"><v>4</v></c>
                </row>
                <row r="3">
                  <c r="A3"><v>520.5</v></c>
                  <c r="B3"><v>1122334455</v></c>
                  <c r="C3" t="inlineStr"><is><t>مدينة نصر</t></is></c>
                  <c r="D3" t="inlineStr"><is><t>ياسر عادل</t></is></c>
                </row>
              </sheetData>
            </worksheet>
        """.trimIndent()

        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            fun add(name: String, content: String) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            add("xl/sharedStrings.xml", sharedStringsXml)
            add("xl/workbook.xml", workbookXml)
            add("xl/_rels/workbook.xml.rels", relsXml)
            add("xl/worksheets/sheet1.xml", sheetXml)
        }
        return baos.toByteArray()
    }
}

@Implements(PdfDocument::class)
class TestShadowPdfDocument {
    private val pages = mutableListOf<PdfDocument.PageInfo>()

    @Implementation
    fun __constructor__() {
        // No-op native init on JVM
    }

    @Implementation
    fun startPage(pageInfo: PdfDocument.PageInfo): PdfDocument.Page {
        pages.add(pageInfo)
        val bitmap = Bitmap.createBitmap(pageInfo.pageWidth, pageInfo.pageHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val ctor = PdfDocument.Page::class.java.declaredConstructors.first()
        ctor.isAccessible = true
        return ctor.newInstance(canvas, pageInfo) as PdfDocument.Page
    }

    @Implementation
    fun finishPage(page: PdfDocument.Page) {
        // No-op
    }

    @Implementation
    fun writeTo(out: OutputStream) {
        val minimalPdf = "%PDF-1.4\n% Khaldoun Express Arabic RTL PDF Test Output (pages=${pages.size})\n" +
            "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n" +
            "2 0 obj << /Type /Pages /Count ${pages.size} /Kids [] >> endobj\n" +
            "%%EOF\n"
        out.write(minimalPdf.padEnd(600, ' ').toByteArray(Charsets.UTF_8))
    }

    @Implementation
    fun close() {
        // No-op
    }
}
