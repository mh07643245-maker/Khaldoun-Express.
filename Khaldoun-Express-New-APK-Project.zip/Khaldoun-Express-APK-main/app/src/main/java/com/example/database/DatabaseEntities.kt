package com.example.database

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.shipments.CompanyFolder
import com.example.shipments.ShipmentSource
import com.example.shipments.ShipmentStatus

@Entity(
    tableName = "companies",
    indices = [Index(value = ["name"]), Index(value = ["isArchived"]), Index(value = ["isActive"])]
)
data class CompanyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String = "",
    val contactPhone: String = "",
    val notes: String = "",
    val isActive: Boolean = true,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "shipments",
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["normalizedPhone"]),
        Index(value = ["last5Digits"]),
        Index(value = ["customerName"]),
        Index(value = ["isArchived"]),
        Index(value = ["folder"]),
        Index(value = ["archiveDate"])
    ]
)
data class ShipmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long,
    val customerName: String,
    val rawPhone: String,
    val normalizedPhone: String,
    val last5Digits: String,
    val address: String,
    val originalPrice: Double,
    val deliveredPrice: Double = 0.0,
    val folder: String = CompanyFolder.DELIVERED.code,
    val statusCode: String = ShipmentStatus.INITIAL.code,
    val notes: String = "",
    val sourceType: String = ShipmentSource.MANUAL.code,
    val needsReview: Boolean = false,
    val isArchived: Boolean = false,
    val archiveDate: String? = null,
    val batchId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shipment_statuses")
data class ShipmentStatusEntity(
    @PrimaryKey val code: String,
    val arabicName: String,
    val sortOrder: Int,
    val isStockActionable: Boolean
)

@Entity(
    tableName = "shipment_notes",
    foreignKeys = [
        ForeignKey(
            entity = ShipmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["shipmentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["shipmentId"])]
)
data class ShipmentNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shipmentId: Long,
    val noteText: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "edit_history",
    foreignKeys = [
        ForeignKey(
            entity = ShipmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["shipmentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["shipmentId"]), Index(value = ["editedAt"])]
)
data class EditHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shipmentId: Long,
    val fieldName: String,
    val oldValue: String,
    val newValue: String,
    val actionNote: String = "",
    val editedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "daily_archives",
    indices = [Index(value = ["archiveDate"], unique = true)]
)
data class DailyArchiveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val archiveDate: String,
    val totalShipments: Int,
    val deliveredFolderCount: Int,
    val casesFolderCount: Int,
    val totalOriginalPrice: Double,
    val totalDeliveredPrice: Double,
    val backupFilePath: String,
    val summaryJson: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "backup_records",
    indices = [Index(value = ["createdAt"])]
)
data class BackupRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val backupType: String, // AUTO_DAY, END_OF_DAY, MANUAL_LOCAL, GOOGLE_DRIVE
    val fileName: String,
    val localPath: String,
    val driveFileId: String? = null,
    val shipmentCount: Int,
    val companyCount: Int,
    val status: String, // SUCCESS, FAILED
    val message: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class ShipmentWithCompany(
    @Embedded val shipment: ShipmentEntity,
    val companyName: String
)

data class CompanyShipmentCounts(
    val companyId: Long,
    val companyName: String,
    val isActive: Boolean,
    val isArchived: Boolean,
    val totalCount: Int,
    val deliveredFolderCount: Int,
    val casesFolderCount: Int,
    val totalOriginalPrice: Double,
    val totalDeliveredPrice: Double
)

data class DashboardSummary(
    val totalTodayShipments: Int = 0,
    val deliveredFolderCount: Int = 0,
    val casesFolderCount: Int = 0,
    val totalOriginalPrice: Double = 0.0,
    val totalDeliveredPrice: Double = 0.0
)
