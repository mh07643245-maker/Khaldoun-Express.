package com.example.stock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.camera.CameraScanner
import com.example.camera.CameraScannerConfig
import com.example.database.EditHistoryEntity
import com.example.database.ShipmentNoteEntity
import com.example.database.ShipmentWithCompany
import com.example.ocr.OcrEngine
import com.example.settings.AppSettingsState
import com.example.shipments.CompanyFolder
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.QuickNoteSuggestions
import com.example.shipments.ShipmentStatus
import com.example.ui.CameraLookupState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FolderPill
import com.example.ui.components.ShipmentSummaryCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberLight
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealDelivered

@Composable
fun StockScreen(
    searchQuery: String,
    searchResults: List<ShipmentWithCompany>,
    selectedShipment: ShipmentWithCompany?,
    selectedNotes: List<ShipmentNoteEntity>,
    selectedEditHistory: List<EditHistoryEntity>,
    settings: AppSettingsState,
    ocrEngine: OcrEngine,
    cameraLookupState: CameraLookupState,
    liveDetectedText: String,
    liveEngineStats: String,
    onSearchQueryChange: (String) -> Unit,
    onSelectShipment: (Long?) -> Unit,
    onCameraDetected: (String, String, String, Long, Boolean) -> Unit,
    onResetCameraScan: () -> Unit,
    onChooseCameraMatch: (ShipmentWithCompany) -> Unit,
    onSaveStockHandling: (Long, Double, ShipmentStatus, String) -> Unit,
    onSaveFullEdit: (Long, String, String, String, Double, Double, ShipmentStatus, String, CompanyFolder) -> Unit,
    onDeleteShipment: (Long) -> Unit,
    initialOpenCamera: Boolean = false,
    onConsumedInitialCamera: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showCameraScanner by remember { mutableStateOf(initialOpenCamera) }

    LaunchedEffect(initialOpenCamera) {
        if (initialOpenCamera) {
            showCameraScanner = true
            onConsumedInitialCamera()
        }
    }

    if (showCameraScanner) {
        LiveCameraScannerScreen(
            ocrEngine = ocrEngine,
            settings = settings,
            cameraLookupState = cameraLookupState,
            liveDetectedText = liveDetectedText,
            liveEngineStats = liveEngineStats,
            onDetected = onCameraDetected,
            onResetScan = onResetCameraScan,
            onChooseMatch = { match ->
                onChooseCameraMatch(match)
                showCameraScanner = false
            },
            onOpenMatchedShipment = {
                showCameraScanner = false
            },
            onClose = {
                showCameraScanner = false
                onResetCameraScan()
            },
            modifier = modifier
        )
        return
    }

    if (selectedShipment != null) {
        StockShipmentDetailScreen(
            item = selectedShipment,
            notesHistory = selectedNotes,
            editHistory = selectedEditHistory,
            numeralStyle = settings.numeralStyle,
            onBack = { onSelectShipment(null) },
            onSaveHandling = { delivPrice, status, note ->
                onSaveStockHandling(selectedShipment.shipment.id, delivPrice, status, note)
            },
            onSaveFullEdit = { name, phone, addr, orig, deliv, status, note, folder ->
                onSaveFullEdit(selectedShipment.shipment.id, name, phone, addr, orig, deliv, status, note, folder)
            },
            onDelete = {
                onDeleteShipment(selectedShipment.shipment.id)
            },
            modifier = modifier
        )
        return
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    onResetCameraScan()
                    showCameraScanner = true
                },
                containerColor = AmberAccent,
                contentColor = Color.White,
                modifier = Modifier.testTag("stock_open_camera_fab")
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "فتح البحث بالكاميرا المباشرة")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    label = { Text("بحث بالاسم أو الهاتف أو آخر 5 أرقام") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("stock_search_input")
                )
                Button(
                    onClick = {
                        onResetCameraScan()
                        showCameraScanner = true
                    },
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("stock_camera_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "كاميرا")
                }
            }

            Text(
                text = "النتائج النشطة (${PhoneNumberNormalizer.formatDigitsForDisplay(searchResults.size.toString(), settings.numeralStyle)})",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 84.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (searchResults.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Default.Inventory2,
                            title = if (searchQuery.isBlank()) "لا توجد شحنات نشطة في المخزن" else "لم يتم العثور على شحنة مطابقة",
                            subtitle = "يمكنك البحث بالاسم أو رقم الهاتف كاملًا أو آخر 5 أرقام بالأرقام العربية أو الإنجليزية، أو استخدام الكاميرا المباشرة."
                        )
                    }
                } else {
                    items(searchResults, key = { it.shipment.id }) { item ->
                        ShipmentSummaryCard(
                            item = item,
                            numeralStyle = settings.numeralStyle,
                            onClick = { onSelectShipment(item.shipment.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LiveCameraScannerScreen(
    ocrEngine: OcrEngine,
    settings: AppSettingsState,
    cameraLookupState: CameraLookupState,
    liveDetectedText: String,
    liveEngineStats: String,
    onDetected: (String, String, String, Long, Boolean) -> Unit,
    onResetScan: () -> Unit,
    onChooseMatch: (ShipmentWithCompany) -> Unit,
    onOpenMatchedShipment: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onClose)

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraError by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Automatically open detail screen when a unique shipment is found
    LaunchedEffect(cameraLookupState) {
        if (cameraLookupState is CameraLookupState.SingleFound) {
            onOpenMatchedShipment()
        }
    }

    val scanner = remember(ocrEngine) { CameraScanner(context, ocrEngine) }

    DisposableEffect(Unit) {
        onDispose {
            scanner.shutdown()
            if (settings.releaseOcrWhenIdle) {
                ocrEngine.release()
            }
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        if (!hasCameraPermission) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "مطلوب إذن الكاميرا لقراءة أرقام الهواتف على ملصقات الشحنات",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                    Text("منح إذن الكاميرا")
                }
                OutlinedButton(onClick = onClose) {
                    Text("إغلاق", color = Color.White)
                }
            }
        } else {
            var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }

            LaunchedEffect(
                previewViewRef,
                lifecycleOwner,
                settings.cameraFrameIntervalMs,
                settings.cameraLowResolution,
                settings.ocrMode
            ) {
                val pv = previewViewRef ?: return@LaunchedEffect
                scanner.start(
                    lifecycleOwner = lifecycleOwner,
                    previewView = pv,
                    config = CameraScannerConfig(
                        frameIntervalMs = settings.cameraFrameIntervalMs,
                        lowResolutionMode = settings.cameraLowResolution,
                        ocrMode = settings.ocrMode
                    ),
                    onFrameResult = { res ->
                        onDetected(
                            res.detectedPhone,
                            res.last5Digits,
                            res.engineUsed,
                            res.inferenceTimeMs,
                            res.isConfirmedStable
                        )
                    },
                    onError = { cameraError = it }
                )
            }

            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }.also { previewViewRef = it }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Center Target Reticle (matches ROI crop area)
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.76f)
                    .height(110.dp)
                    .border(2.5.dp, AmberLight, MaterialTheme.shapes.medium)
            )

            // Top bar overlay
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose, modifier = Modifier.testTag("camera_close_button")) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق الكاميرا", tint = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "وجّه الكاميرا إلى رقم الهاتف على الملصق",
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (liveEngineStats.isNotBlank()) {
                        Text(
                            text = liveEngineStats,
                            color = AmberLight,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                IconButton(onClick = {
                    scanner.resetTriggerCooldown()
                    onResetScan()
                }) {
                    Icon(Icons.Default.Refresh, contentDescription = "إعادة المسح", tint = Color.White)
                }
            }

            // Bottom live detection & results panel
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(12.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (liveDetectedText.isBlank()) {
                            "جاري البحث المستمر عن رقم الهاتف محليًا..."
                        } else {
                            "الرقم المكتشف: ${PhoneNumberNormalizer.formatDigitsForDisplay(liveDetectedText, settings.numeralStyle)}"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    cameraError?.let {
                        Text(it, color = ErrorCrimson, style = MaterialTheme.typography.bodySmall)
                    }

                    when (cameraLookupState) {
                        CameraLookupState.Scanning -> {
                            Text(
                                text = "القراءة مستمرة تلقائيًا دون التقاط صورة • يدعم الأرقام العربية والإنجليزية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        is CameraLookupState.NotFound -> {
                            Text(
                                text = "لم يتم العثور على شحنة نشطة تطابق الرقم (${cameraLookupState.detectedPhone}) أو آخر 5 أرقام (${cameraLookupState.last5}).",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ErrorCrimson,
                                fontWeight = FontWeight.SemiBold
                            )
                            Button(
                                onClick = {
                                    scanner.resetTriggerCooldown()
                                    onResetScan()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("مسح رقم آخر")
                            }
                        }
                        is CameraLookupState.MultipleFound -> {
                            Text(
                                text = "تم العثور على ${cameraLookupState.matches.size} شحنات بنفس آخر 5 أرقام (${cameraLookupState.last5}) — اختر الشحنة:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = AmberAccent
                            )
                            cameraLookupState.matches.take(4).forEach { match ->
                                Card(
                                    onClick = { onChooseMatch(match) },
                                    modifier = Modifier.fillMaxWidth(),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${match.shipment.customerName} (${match.companyName})", fontWeight = FontWeight.Bold)
                                        Text("${match.shipment.rawPhone} • ${CurrencyFormatter.formatEgp(match.shipment.originalPrice, settings.numeralStyle)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                        is CameraLookupState.SingleFound -> {
                            Text("تم فتح الشحنة المطابقة!", color = TealDelivered, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StockShipmentDetailScreen(
    item: ShipmentWithCompany,
    notesHistory: List<ShipmentNoteEntity>,
    editHistory: List<EditHistoryEntity>,
    numeralStyle: NumeralStyle,
    onBack: () -> Unit,
    onSaveHandling: (deliveredPrice: Double, status: ShipmentStatus, noteText: String) -> Unit,
    onSaveFullEdit: (
        name: String,
        phone: String,
        address: String,
        originalPrice: Double,
        deliveredPrice: Double,
        status: ShipmentStatus,
        notes: String,
        folder: CompanyFolder
    ) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val s = item.shipment

    var deliveredPriceText by remember(s.id, s.deliveredPrice) {
        mutableStateOf(
            if (s.deliveredPrice == 0.0 && s.folder == CompanyFolder.DELIVERED.code) {
                CurrencyFormatter.formatPlainAmount(s.originalPrice)
            } else {
                CurrencyFormatter.formatPlainAmount(s.deliveredPrice)
            }
        )
    }
    var selectedStatus by remember(s.id, s.statusCode) {
        val current = ShipmentStatus.fromCode(s.statusCode)
        mutableStateOf(if (current == ShipmentStatus.INITIAL) ShipmentStatus.DELIVERED else current)
    }
    var noteText by remember(s.id, s.notes) { mutableStateOf(s.notes) }

    var showFullEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
                Text("معالجة الشحنة في المخزن", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Row {
                IconButton(onClick = { showHistoryDialog = true }) {
                    Icon(Icons.Default.History, contentDescription = "سجل التعديلات")
                }
                IconButton(onClick = { showFullEditDialog = true }, modifier = Modifier.testTag("edit_shipment_button")) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل كامل")
                }
                IconButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.testTag("delete_shipment_button")) {
                    Icon(Icons.Default.DeleteForever, contentDescription = "حذف الشحنة", tint = ErrorCrimson)
                }
            }
        }

        // Customer & Price summary card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(s.customerName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    FolderPill(s.folder)
                }
                Text("الشركة: ${item.companyName}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = PhoneNumberNormalizer.formatDigitsForDisplay(s.rawPhone, numeralStyle),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Button(
                        onClick = {
                            val dialNum = s.normalizedPhone.ifBlank { s.rawPhone }
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$dialNum"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.testTag("call_customer_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = TealDelivered)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("اتصال")
                    }
                }
                Text("العنوان: ${s.address.ifBlank { "غير مسجل" }}", style = MaterialTheme.typography.bodyMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "السعر الأصلي: ${CurrencyFormatter.formatEgp(s.originalPrice, numeralStyle)}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    StatusPill(s.statusCode)
                }
            }
        }

        // Editable Stock Handling Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تحديث الحالة والمبلغ المسلم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = deliveredPriceText,
                    onValueChange = { deliveredPriceText = it },
                    label = { Text("السعر المسلم (ج.م) — يمكنك تسجيل 0 عند عدم التسليم") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("delivered_price_input")
                )

                Text("الحالة الأساسية:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ShipmentStatus.stockHandlingStatuses.forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = {
                                selectedStatus = st
                                if (st == ShipmentStatus.CANCELLED || st == ShipmentStatus.POSTPONED) {
                                    deliveredPriceText = "0"
                                }
                            },
                            label = { Text(st.arabicLabel) },
                            modifier = Modifier.testTag("status_chip_${st.code}")
                        )
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("ملاحظات حرة") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stock_note_input")
                )

                Text("اقتراحات سريعة:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuickNoteSuggestions.defaultNotes.forEach { suggestion ->
                        FilterChip(
                            selected = noteText == suggestion,
                            onClick = { noteText = suggestion },
                            label = { Text(suggestion) }
                        )
                    }
                }

                Button(
                    onClick = {
                        val parsedDeliv = PhoneNumberNormalizer.parsePrice(deliveredPriceText) ?: 0.0
                        onSaveHandling(parsedDeliv, selectedStatus, noteText)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("save_stock_handling_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("حفظ ونقل إلى مجلد الحالات", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("تأكيد حذف الشحنة نهائيًا") },
            text = { Text("هل أنت متأكد من حذف شحنة (${s.customerName}) نهائيًا؟ لا يمكن التراجع عن الحذف.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson),
                    modifier = Modifier.testTag("confirm_delete_shipment_button")
                ) {
                    Text("نعم، احذف نهائيًا")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") }
            }
        )
    }

    if (showFullEditDialog) {
        var name by remember { mutableStateOf(s.customerName) }
        var phone by remember { mutableStateOf(s.rawPhone) }
        var addr by remember { mutableStateOf(s.address) }
        var origText by remember { mutableStateOf(CurrencyFormatter.formatPlainAmount(s.originalPrice)) }
        var delivText by remember { mutableStateOf(CurrencyFormatter.formatPlainAmount(s.deliveredPrice)) }
        var editNote by remember { mutableStateOf(s.notes) }
        var editFolder by remember { mutableStateOf(CompanyFolder.fromCode(s.folder)) }
        var editStatus by remember { mutableStateOf(ShipmentStatus.fromCode(s.statusCode)) }

        AlertDialog(
            onDismissRequest = { showFullEditDialog = false },
            title = { Text("تعديل جميع بيانات الشحنة") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم العميل") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true)
                    OutlinedTextField(value = addr, onValueChange = { addr = it }, label = { Text("العنوان") })
                    OutlinedTextField(value = origText, onValueChange = { origText = it }, label = { Text("السعر الأصلي") }, singleLine = true)
                    OutlinedTextField(value = delivText, onValueChange = { delivText = it }, label = { Text("السعر المسلم") }, singleLine = true)
                    OutlinedTextField(value = editNote, onValueChange = { editNote = it }, label = { Text("الملاحظات") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompanyFolder.entries.forEach { f ->
                            FilterChip(
                                selected = editFolder == f,
                                onClick = { editFolder = f },
                                label = { Text(f.arabicLabel) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val orig = PhoneNumberNormalizer.parsePrice(origText) ?: s.originalPrice
                    val deliv = PhoneNumberNormalizer.parsePrice(delivText) ?: s.deliveredPrice
                    onSaveFullEdit(name, phone, addr, orig, deliv, editStatus, editNote, editFolder)
                    showFullEditDialog = false
                }) {
                    Text("حفظ التعديلات")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFullEditDialog = false }) { Text("إلغاء") }
            }
        )
    }

    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = { Text("سجل التعديلات والملاحظات") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (editHistory.isEmpty() && notesHistory.isEmpty()) {
                        Text("لا توجد تعديلات مسجلة على هذه الشحنة حتى الآن.")
                    } else {
                        editHistory.forEach { h ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("${h.fieldName}: ${h.oldValue.ifBlank { "-" }} ← ${h.newValue.ifBlank { "-" }}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                    if (h.actionNote.isNotBlank()) {
                                        Text(h.actionNote, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) { Text("إغلاق") }
            }
        )
    }
}
