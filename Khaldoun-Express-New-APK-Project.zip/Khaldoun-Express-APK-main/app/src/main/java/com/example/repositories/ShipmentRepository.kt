package com.example.repositories

import androidx.room.withTransaction
import com.example.database.CompanyEntity
import com.example.database.CompanyShipmentCounts
import com.example.database.DailyArchiveEntity
import com.example.database.DashboardSummary
import com.example.database.EditHistoryEntity
import com.example.database.LocalDatabase
import com.example.database.ShipmentEntity
import com.example.database.ShipmentNoteEntity
import com.example.database.ShipmentWithCompany
import com.example.shipments.CompanyFolder
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.ShipmentSource
import com.example.shipments.ShipmentStatus
import kotlinx.coroutines.flow.Flow

data class DraftShipmentInput(
    val customerName: String,
    val rawPhone: String,
    val address: String,
    val originalPrice: Double,
    val needsReview: Boolean = false
)

data class BatchSaveResult(
    val insertedCount: Int,
    val duplicateBatchBlocked: Boolean = false,
    val batchId: String
)

class ShipmentRepository(private val database: LocalDatabase) {
    private val companyDao = database.companyDao()
    private val shipmentDao = database.shipmentDao()
    private val metadataDao = database.metadataDao()

    fun observeDashboardSummary(): Flow<DashboardSummary> = shipmentDao.observeDashboardSummary()

    fun observeCompanyCounts(): Flow<List<CompanyShipmentCounts>> = shipmentDao.observeCompanyCounts()

    fun observeAllCompanies(): Flow<List<CompanyEntity>> = companyDao.observeAllCompanies()

    fun observeSelectableCompanies(): Flow<List<CompanyEntity>> = companyDao.observeSelectableCompanies()

    fun observeActiveShipments(): Flow<List<ShipmentWithCompany>> =
        shipmentDao.observeActiveShipmentsWithCompany()

    fun observeActiveShipmentsByCompany(companyId: Long): Flow<List<ShipmentWithCompany>> =
        shipmentDao.observeActiveShipmentsByCompany(companyId)

    fun observeShipmentById(shipmentId: Long): Flow<ShipmentWithCompany?> =
        shipmentDao.observeShipmentById(shipmentId)

    fun observeNotesForShipment(shipmentId: Long): Flow<List<ShipmentNoteEntity>> =
        metadataDao.observeNotesForShipment(shipmentId)

    fun observeEditHistoryForShipment(shipmentId: Long): Flow<List<EditHistoryEntity>> =
        metadataDao.observeEditHistoryForShipment(shipmentId)

    fun observeDailyArchives(): Flow<List<DailyArchiveEntity>> = metadataDao.observeDailyArchives()

    fun observeSearchShipments(rawQuery: String): Flow<List<ShipmentWithCompany>> {
        val trimmed = rawQuery.trim()
        if (trimmed.isEmpty()) return shipmentDao.observeActiveShipmentsWithCompany()
        val normalized = PhoneNumberNormalizer.normalize(trimmed)
        val last5 = if (normalized.length >= 5) normalized.takeLast(5) else "__NONE__"
        val phonePattern = normalized.ifEmpty { trimmed }
        return shipmentDao.observeSearchActiveShipments(
            query = trimmed,
            normalizedQuery = phonePattern,
            last5 = last5
        )
    }

    suspend fun findByScannedPhoneOrLast5(rawScanned: String): List<ShipmentWithCompany> {
        val normalized = PhoneNumberNormalizer.normalize(rawScanned)
        if (normalized.length < 5) return emptyList()
        val last5 = PhoneNumberNormalizer.extractLast5Digits(normalized)
        return shipmentDao.findActiveByPhoneOrLast5(normalized, last5)
    }

    suspend fun addCompany(
        name: String,
        code: String = "",
        contactPhone: String = "",
        notes: String = ""
    ): Long {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "اسم الشركة مطلوب" }
        val now = System.currentTimeMillis()
        return companyDao.insertCompany(
            CompanyEntity(
                name = cleanName,
                code = code.trim(),
                contactPhone = PhoneNumberNormalizer.preserveRawPhone(contactPhone),
                notes = notes.trim(),
                isActive = true,
                isArchived = false,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateCompany(company: CompanyEntity) {
        companyDao.updateCompany(company.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun setCompanyActive(companyId: Long, active: Boolean) {
        val existing = companyDao.getCompanyById(companyId) ?: return
        companyDao.updateCompany(existing.copy(isActive = active, updatedAt = System.currentTimeMillis()))
    }

    suspend fun setCompanyArchived(companyId: Long, archived: Boolean) {
        val existing = companyDao.getCompanyById(companyId) ?: return
        companyDao.updateCompany(
            existing.copy(
                isArchived = archived,
                isActive = if (archived) false else existing.isActive,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun saveShipmentBatch(
        companyId: Long,
        items: List<DraftShipmentInput>,
        source: ShipmentSource,
        batchId: String
    ): BatchSaveResult {
        if (items.isEmpty()) return BatchSaveResult(0, false, batchId)
        return database.withTransaction {
            if (batchId.isNotEmpty() && shipmentDao.countByBatchId(batchId) > 0) {
                return@withTransaction BatchSaveResult(0, duplicateBatchBlocked = true, batchId = batchId)
            }
            val now = System.currentTimeMillis()
            val entities = items.map { draft ->
                val rawPhone = PhoneNumberNormalizer.preserveRawPhone(draft.rawPhone)
                val normalizedPhone = PhoneNumberNormalizer.normalize(rawPhone)
                val last5 = PhoneNumberNormalizer.extractLast5Digits(normalizedPhone)
                ShipmentEntity(
                    companyId = companyId,
                    customerName = draft.customerName.trim(),
                    rawPhone = rawPhone,
                    normalizedPhone = normalizedPhone,
                    last5Digits = last5,
                    address = draft.address.trim(),
                    originalPrice = draft.originalPrice,
                    deliveredPrice = 0.0,
                    folder = CompanyFolder.DELIVERED.code,
                    statusCode = ShipmentStatus.INITIAL.code,
                    notes = "",
                    sourceType = source.code,
                    needsReview = draft.needsReview,
                    isArchived = false,
                    archiveDate = null,
                    batchId = batchId,
                    createdAt = now,
                    updatedAt = now
                )
            }
            val ids = shipmentDao.insertShipments(entities)
            BatchSaveResult(insertedCount = ids.size, duplicateBatchBlocked = false, batchId = batchId)
        }
    }

    suspend fun addSingleShipment(
        companyId: Long,
        customerName: String,
        rawPhone: String,
        address: String,
        originalPrice: Double
    ): Long {
        val result = saveShipmentBatch(
            companyId = companyId,
            items = listOf(
                DraftShipmentInput(
                    customerName = customerName,
                    rawPhone = rawPhone,
                    address = address,
                    originalPrice = originalPrice
                )
            ),
            source = ShipmentSource.MANUAL,
            batchId = ""
        )
        return result.insertedCount.toLong()
    }

    /**
     * Handles a shipment inside the Stock (المخزن) section.
     * Rule: ANY shipment handled in Stock moves to the CASES ("الحالات") folder of its company,
     * regardless of the chosen status or note. Original price remains untouched.
     */
    suspend fun handleShipmentInStock(
        shipmentId: Long,
        deliveredPrice: Double,
        status: ShipmentStatus,
        noteText: String
    ) {
        database.withTransaction {
            val current = shipmentDao.getShipmentById(shipmentId) ?: return@withTransaction
            val now = System.currentTimeMillis()
            val cleanNote = noteText.trim()
            val historyEntries = mutableListOf<EditHistoryEntity>()

            if (current.folder != CompanyFolder.CASES.code) {
                historyEntries.add(
                    EditHistoryEntity(
                        shipmentId = shipmentId,
                        fieldName = "المجلد",
                        oldValue = CompanyFolder.fromCode(current.folder).arabicLabel,
                        newValue = CompanyFolder.CASES.arabicLabel,
                        actionNote = "معالجة داخل المخزن",
                        editedAt = now
                    )
                )
            }
            if (current.statusCode != status.code) {
                historyEntries.add(
                    EditHistoryEntity(
                        shipmentId = shipmentId,
                        fieldName = "الحالة",
                        oldValue = ShipmentStatus.fromCode(current.statusCode).arabicLabel,
                        newValue = status.arabicLabel,
                        actionNote = "تحديث حالة من المخزن",
                        editedAt = now
                    )
                )
            }
            if (current.deliveredPrice != deliveredPrice) {
                historyEntries.add(
                    EditHistoryEntity(
                        shipmentId = shipmentId,
                        fieldName = "السعر المسلم",
                        oldValue = current.deliveredPrice.toString(),
                        newValue = deliveredPrice.toString(),
                        actionNote = "تحديث السعر المسلم",
                        editedAt = now
                    )
                )
            }
            if (cleanNote != current.notes) {
                historyEntries.add(
                    EditHistoryEntity(
                        shipmentId = shipmentId,
                        fieldName = "الملاحظات",
                        oldValue = current.notes,
                        newValue = cleanNote,
                        actionNote = "تحديث الملاحظة",
                        editedAt = now
                    )
                )
            }

            shipmentDao.updateShipment(
                current.copy(
                    deliveredPrice = deliveredPrice.coerceAtLeast(0.0),
                    statusCode = status.code,
                    folder = CompanyFolder.CASES.code,
                    notes = cleanNote,
                    updatedAt = now
                )
            )
            if (cleanNote.isNotEmpty() && cleanNote != current.notes) {
                metadataDao.insertNote(
                    ShipmentNoteEntity(
                        shipmentId = shipmentId,
                        noteText = cleanNote,
                        createdAt = now
                    )
                )
            }
            if (historyEntries.isNotEmpty()) {
                metadataDao.insertEditHistoryList(historyEntries)
            }
        }
    }

    /**
     * Full edit of shipment fields with audit trail in EditHistory.
     */
    suspend fun updateShipmentDetails(
        shipmentId: Long,
        customerName: String,
        rawPhone: String,
        address: String,
        originalPrice: Double,
        deliveredPrice: Double,
        status: ShipmentStatus,
        notes: String,
        folder: CompanyFolder? = null
    ) {
        database.withTransaction {
            val current = shipmentDao.getShipmentById(shipmentId) ?: return@withTransaction
            val now = System.currentTimeMillis()
            val cleanName = customerName.trim()
            val cleanRawPhone = PhoneNumberNormalizer.preserveRawPhone(rawPhone)
            val normalizedPhone = PhoneNumberNormalizer.normalize(cleanRawPhone)
            val last5 = PhoneNumberNormalizer.extractLast5Digits(normalizedPhone)
            val cleanAddress = address.trim()
            val cleanNotes = notes.trim()
            val targetFolder = folder?.code ?: current.folder

            val history = mutableListOf<EditHistoryEntity>()
            fun recordIfChanged(label: String, oldVal: String, newVal: String) {
                if (oldVal != newVal) {
                    history.add(
                        EditHistoryEntity(
                            shipmentId = shipmentId,
                            fieldName = label,
                            oldValue = oldVal,
                            newValue = newVal,
                            actionNote = "تعديل بيانات الشحنة",
                            editedAt = now
                        )
                    )
                }
            }

            recordIfChanged("اسم العميل", current.customerName, cleanName)
            recordIfChanged("رقم الهاتف", current.rawPhone, cleanRawPhone)
            recordIfChanged("العنوان", current.address, cleanAddress)
            recordIfChanged("السعر الأصلي", current.originalPrice.toString(), originalPrice.toString())
            recordIfChanged("السعر المسلم", current.deliveredPrice.toString(), deliveredPrice.toString())
            recordIfChanged(
                "الحالة",
                ShipmentStatus.fromCode(current.statusCode).arabicLabel,
                status.arabicLabel
            )
            recordIfChanged("الملاحظات", current.notes, cleanNotes)
            recordIfChanged(
                "المجلد",
                CompanyFolder.fromCode(current.folder).arabicLabel,
                CompanyFolder.fromCode(targetFolder).arabicLabel
            )

            shipmentDao.updateShipment(
                current.copy(
                    customerName = cleanName,
                    rawPhone = cleanRawPhone,
                    normalizedPhone = normalizedPhone,
                    last5Digits = last5,
                    address = cleanAddress,
                    originalPrice = originalPrice.coerceAtLeast(0.0),
                    deliveredPrice = deliveredPrice.coerceAtLeast(0.0),
                    statusCode = status.code,
                    notes = cleanNotes,
                    folder = targetFolder,
                    needsReview = false,
                    updatedAt = now
                )
            )
            if (cleanNotes.isNotEmpty() && cleanNotes != current.notes) {
                metadataDao.insertNote(
                    ShipmentNoteEntity(
                        shipmentId = shipmentId,
                        noteText = cleanNotes,
                        createdAt = now
                    )
                )
            }
            if (history.isNotEmpty()) {
                metadataDao.insertEditHistoryList(history)
            }
        }
    }

    suspend fun deleteShipmentPermanently(shipmentId: Long) {
        shipmentDao.deleteShipmentById(shipmentId)
    }

    suspend fun getActiveShipmentsOnce(): List<ShipmentWithCompany> =
        shipmentDao.getActiveShipmentsOnce()

    suspend fun getArchivedShipmentsByDate(archiveDate: String): List<ShipmentWithCompany> =
        shipmentDao.getArchivedShipmentsByDate(archiveDate)

    suspend fun getCompanyById(companyId: Long): CompanyEntity? =
        companyDao.getCompanyById(companyId)

    suspend fun getAllCompaniesOnce(): List<CompanyEntity> =
        companyDao.getAllCompaniesOnce()

    suspend fun getDailyArchiveByDate(date: String): DailyArchiveEntity? =
        metadataDao.getDailyArchiveByDate(date)

    suspend fun archiveDayAfterBackup(
        archiveDate: String,
        backupFilePath: String,
        summaryJson: String
    ) {
        database.withTransaction {
            val active = shipmentDao.getActiveShipmentsOnce()
            val deliveredCount = active.count { it.shipment.folder == CompanyFolder.DELIVERED.code }
            val casesCount = active.count { it.shipment.folder == CompanyFolder.CASES.code }
            val totalOrig = active.sumOf { it.shipment.originalPrice }
            val totalDeliv = active.sumOf { it.shipment.deliveredPrice }
            val now = System.currentTimeMillis()

            metadataDao.insertDailyArchive(
                DailyArchiveEntity(
                    archiveDate = archiveDate,
                    totalShipments = active.size,
                    deliveredFolderCount = deliveredCount,
                    casesFolderCount = casesCount,
                    totalOriginalPrice = totalOrig,
                    totalDeliveredPrice = totalDeliv,
                    backupFilePath = backupFilePath,
                    summaryJson = summaryJson,
                    createdAt = now
                )
            )
            shipmentDao.archiveAllActiveShipments(archiveDate = archiveDate, timestamp = now)
        }
    }
}
