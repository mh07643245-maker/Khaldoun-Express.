package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.shipments.ShipmentStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CompanyEntity::class,
        ShipmentEntity::class,
        ShipmentStatusEntity::class,
        ShipmentNoteEntity::class,
        EditHistoryEntity::class,
        DailyArchiveEntity::class,
        BackupRecordEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LocalDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun shipmentDao(): ShipmentDao
    abstract fun metadataDao(): ShipmentMetadataDao
    abstract fun restoreDao(): RestoreTransactionDao

    companion object {
        private const val DB_NAME = "khaldoun_express.db"

        @Volatile
        private var INSTANCE: LocalDatabase? = null

        fun getInstance(context: Context): LocalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun createInMemoryForTest(context: Context): LocalDatabase {
            return Room.inMemoryDatabaseBuilder(context, LocalDatabase::class.java)
                .allowMainThreadQueries()
                .build()
        }

        private fun buildDatabase(context: Context): LocalDatabase {
            return Room.databaseBuilder(context, LocalDatabase::class.java, DB_NAME)
                .addCallback(
                    object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.metadataDao()?.insertStatuses(defaultStatuses())
                            }
                        }
                    }
                )
                .build()
        }

        fun defaultStatuses(): List<ShipmentStatusEntity> = listOf(
            ShipmentStatusEntity(ShipmentStatus.INITIAL.code, ShipmentStatus.INITIAL.arabicLabel, 0, false),
            ShipmentStatusEntity(ShipmentStatus.DELIVERED.code, ShipmentStatus.DELIVERED.arabicLabel, 1, true),
            ShipmentStatusEntity(ShipmentStatus.DELIVERY_ISSUE.code, ShipmentStatus.DELIVERY_ISSUE.arabicLabel, 2, true),
            ShipmentStatusEntity(ShipmentStatus.POSTPONED.code, ShipmentStatus.POSTPONED.arabicLabel, 3, true),
            ShipmentStatusEntity(ShipmentStatus.CANCELLED.code, ShipmentStatus.CANCELLED.arabicLabel, 4, true)
        )
    }
}
