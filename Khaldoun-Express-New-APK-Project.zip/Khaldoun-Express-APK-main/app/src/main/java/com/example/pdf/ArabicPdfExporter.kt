package com.example.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.reports.ReportRow
import com.example.reports.ShipmentReport
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Generates native Android Arabic RTL PDFs using Skia + HarfBuzz StaticLayout shaping
 * with the bundled Cairo TTF font so Arabic ligatures, RTL direction, and EGP totals
 * render crisply without disconnected letters or missing-glyph boxes.
 */
object ArabicPdfExporter {

    private const val PAGE_WIDTH = 595 // A4 width in points
    private const val PAGE_HEIGHT = 842 // A4 height in points
    private const val MARGIN = 24f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2) // 547pt

    suspend fun exportReportToPdf(
        context: Context,
        report: ShipmentReport,
        numeralStyle: NumeralStyle = NumeralStyle.WESTERN
    ): File = withContext(Dispatchers.IO) {
        val reportsDir = File(context.filesDir, "reports").apply { mkdirs() }
        val safeCompany = report.companyName.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(24)
        val fileName = "khaldoun_report_${report.reportDate}_${safeCompany}_${System.currentTimeMillis()}.pdf"
        val outFile = File(reportsDir, fileName)

        val baseTypeface = try {
            ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT
        } catch (_: Exception) {
            Typeface.DEFAULT
        }

        val document = PdfDocument()
        try {
            renderReportPages(document, report, baseTypeface, numeralStyle)
            FileOutputStream(outFile).use { fos ->
                document.writeTo(fos)
            }
        } finally {
            document.close()
        }
        outFile
    }

    private fun renderReportPages(
        document: PdfDocument,
        report: ShipmentReport,
        typeface: Typeface,
        numeralStyle: NumeralStyle
    ) {
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            textSize = 15f
            color = Color.WHITE
        }
        val subHeaderPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            textSize = 10f
            color = Color.parseColor("#E2E8F0")
        }
        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            textSize = 10f
            color = Color.parseColor("#0F172A")
        }
        val thPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            textSize = 8.5f
            color = Color.WHITE
        }
        val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            textSize = 8.2f
            color = Color.parseColor("#0F172A")
        }
        val totalPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            textSize = 10.5f
            color = Color.parseColor("#0A1A33")
        }

        val headerBgPaint = Paint().apply { color = Color.parseColor("#0A1A33") }
        val accentStripePaint = Paint().apply { color = Color.parseColor("#D97706") }
        val thBgPaint = Paint().apply { color = Color.parseColor("#1E3A5F") }
        val zebraPaint = Paint().apply { color = Color.parseColor("#F8FAFC") }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
        }
        val totalsBgPaint = Paint().apply { color = Color.parseColor("#FEF3C7") }

        // Columns ordered RTL (drawn from right edge to left edge):
        // م (24) | العميل (88) | الهاتف (74) | العنوان (110) | الأصلي (56) | المسلم (56) | الحالة (64) | الملاحظات (75)
        // Sum = 547pt = CONTENT_WIDTH
        val colWidths = floatArrayOf(24f, 88f, 74f, 110f, 56f, 56f, 64f, 75f)
        val colHeaders = listOf(
            "م",
            "اسم العميل",
            "رقم الهاتف",
            "العنوان",
            "الأصلي",
            "المسلم",
            "الحالة",
            "الملاحظات"
        )

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        var y = drawBrandHeader(canvas, report, numeralStyle, headerBgPaint, accentStripePaint, titlePaint, subHeaderPaint, metaPaint)
        y = drawTableHeader(canvas, y, colWidths, colHeaders, thBgPaint, borderPaint, thPaint)

        report.rows.forEachIndexed { index, row ->
            val values = rowToCells(index + 1, row, numeralStyle)
            val layouts = values.mapIndexed { colIdx, text ->
                buildRtlLayout(text, cellPaint, (colWidths[colIdx] - 6f).toInt().coerceAtLeast(12))
            }
            val rowHeight = (layouts.maxOfOrNull { it.height } ?: 14) + 10f

            if (y + rowHeight > PAGE_HEIGHT - 84f) {
                drawPageFooter(canvas, pageNumber, cellPaint, numeralStyle)
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = drawCompactContinuationHeader(canvas, report, headerBgPaint, titlePaint)
                y = drawTableHeader(canvas, y, colWidths, colHeaders, thBgPaint, borderPaint, thPaint)
            }

            if (index % 2 == 1) {
                canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + rowHeight, zebraPaint)
            }
            drawRtlRow(canvas, y, rowHeight, colWidths, layouts, borderPaint)
            y += rowHeight
        }

        // Totals footer box
        if (y + 64f > PAGE_HEIGHT - 36f) {
            drawPageFooter(canvas, pageNumber, cellPaint, numeralStyle)
            document.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = document.startPage(pageInfo)
            canvas = page.canvas
            y = MARGIN + 10f
        }

        y += 10f
        val totalsHeight = 46f
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + totalsHeight, totalsBgPaint)
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + totalsHeight, borderPaint)

        val countText = "عدد الشحنات: ${PhoneNumberNormalizer.formatDigitsForDisplay(report.totalCount.toString(), numeralStyle)}"
        val origText = "إجمالي السعر الأصلي: ${CurrencyFormatter.formatEgp(report.totalOriginalPrice, numeralStyle)}"
        val delivText = "إجمالي السعر المسلم: ${CurrencyFormatter.formatEgp(report.totalDeliveredPrice, numeralStyle)}"
        val summaryLine = "$countText   |   $origText   |   $delivText"

        val totalLayout = buildRtlLayout(summaryLine, totalPaint, (CONTENT_WIDTH - 16f).toInt())
        canvas.save()
        canvas.translate(MARGIN + 8f, y + (totalsHeight - totalLayout.height) / 2f)
        totalLayout.draw(canvas)
        canvas.restore()

        drawPageFooter(canvas, pageNumber, cellPaint, numeralStyle)
        document.finishPage(page)
    }

    private fun drawBrandHeader(
        canvas: Canvas,
        report: ShipmentReport,
        numeralStyle: NumeralStyle,
        headerBgPaint: Paint,
        accentStripePaint: Paint,
        titlePaint: TextPaint,
        subHeaderPaint: TextPaint,
        metaPaint: TextPaint
    ): Float {
        val top = MARGIN
        val headerHeight = 56f
        canvas.drawRect(MARGIN, top, PAGE_WIDTH - MARGIN, top + headerHeight, headerBgPaint)
        canvas.drawRect(MARGIN, top + headerHeight, PAGE_WIDTH - MARGIN, top + headerHeight + 3f, accentStripePaint)

        val brandLayout = buildRtlLayout("خلدون إكسبريس – Khaldoun Express", titlePaint, (CONTENT_WIDTH - 20f).toInt())
        canvas.save()
        canvas.translate(MARGIN + 10f, top + 8f)
        brandLayout.draw(canvas)
        canvas.restore()

        val subtitleLayout = buildRtlLayout("${report.title}  |  ${report.folderSubtitle}", subHeaderPaint, (CONTENT_WIDTH - 20f).toInt())
        canvas.save()
        canvas.translate(MARGIN + 10f, top + 32f)
        subtitleLayout.draw(canvas)
        canvas.restore()

        val metaY = top + headerHeight + 10f
        val dateDisp = PhoneNumberNormalizer.formatDigitsForDisplay(report.reportDate, numeralStyle)
        val metaText = "الشركة: ${report.companyName}     |     تاريخ التقرير: $dateDisp"
        val metaLayout = buildRtlLayout(metaText, metaPaint, CONTENT_WIDTH.toInt())
        canvas.save()
        canvas.translate(MARGIN, metaY)
        metaLayout.draw(canvas)
        canvas.restore()

        return metaY + metaLayout.height + 10f
    }

    private fun drawCompactContinuationHeader(
        canvas: Canvas,
        report: ShipmentReport,
        headerBgPaint: Paint,
        titlePaint: TextPaint
    ): Float {
        val top = MARGIN
        canvas.drawRect(MARGIN, top, PAGE_WIDTH - MARGIN, top + 28f, headerBgPaint)
        val l = buildRtlLayout("خلدون إكسبريس – ${report.companyName} (${report.reportDate})", titlePaint, (CONTENT_WIDTH - 16f).toInt())
        canvas.save()
        canvas.translate(MARGIN + 8f, top + 4f)
        l.draw(canvas)
        canvas.restore()
        return top + 34f
    }

    private fun drawTableHeader(
        canvas: Canvas,
        y: Float,
        colWidths: FloatArray,
        headers: List<String>,
        bgPaint: Paint,
        borderPaint: Paint,
        textPaint: TextPaint
    ): Float {
        val layouts = headers.mapIndexed { idx, h ->
            buildRtlLayout(h, textPaint, (colWidths[idx] - 6f).toInt().coerceAtLeast(12))
        }
        val rowHeight = (layouts.maxOfOrNull { it.height } ?: 14) + 10f
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + rowHeight, bgPaint)
        drawRtlRow(canvas, y, rowHeight, colWidths, layouts, borderPaint)
        return y + rowHeight
    }

    private fun drawRtlRow(
        canvas: Canvas,
        y: Float,
        rowHeight: Float,
        colWidths: FloatArray,
        layouts: List<StaticLayout>,
        borderPaint: Paint
    ) {
        var rightEdge = PAGE_WIDTH - MARGIN
        for (i in colWidths.indices) {
            val w = colWidths[i]
            val leftEdge = rightEdge - w
            canvas.drawRect(leftEdge, y, rightEdge, y + rowHeight, borderPaint)
            val layout = layouts[i]
            canvas.save()
            canvas.translate(leftEdge + 3f, y + 5f)
            layout.draw(canvas)
            canvas.restore()
            rightEdge = leftEdge
        }
    }

    private fun rowToCells(index: Int, row: ReportRow, numeralStyle: NumeralStyle): List<String> {
        val idxStr = PhoneNumberNormalizer.formatDigitsForDisplay(index.toString(), numeralStyle)
        val phoneDisp = PhoneNumberNormalizer.formatDigitsForDisplay(row.rawPhone, numeralStyle)
        val origDisp = PhoneNumberNormalizer.formatDigitsForDisplay(CurrencyFormatter.formatPlainAmount(row.originalPrice), numeralStyle)
        val delivDisp = PhoneNumberNormalizer.formatDigitsForDisplay(CurrencyFormatter.formatPlainAmount(row.deliveredPrice), numeralStyle)
        return listOf(
            idxStr,
            row.customerName.ifBlank { "-" },
            phoneDisp.ifBlank { "-" },
            row.address.ifBlank { "-" },
            origDisp,
            delivDisp,
            row.statusLabel,
            row.notes.ifBlank { "-" }
        )
    }

    private fun drawPageFooter(
        canvas: Canvas,
        pageNumber: Int,
        paint: TextPaint,
        numeralStyle: NumeralStyle
    ) {
        val pNum = PhoneNumberNormalizer.formatDigitsForDisplay(pageNumber.toString(), numeralStyle)
        val footer = buildRtlLayout("خلدون إكسبريس – صفحة $pNum", paint, CONTENT_WIDTH.toInt())
        canvas.save()
        canvas.translate(MARGIN, PAGE_HEIGHT - 24f)
        footer.draw(canvas)
        canvas.restore()
    }

    private fun buildRtlLayout(text: String, paint: TextPaint, widthPx: Int): StaticLayout {
        val safeWidth = widthPx.coerceAtLeast(10)
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(1.5f, 1.0f)
            .setIncludePad(false)
            .build()
    }
}
