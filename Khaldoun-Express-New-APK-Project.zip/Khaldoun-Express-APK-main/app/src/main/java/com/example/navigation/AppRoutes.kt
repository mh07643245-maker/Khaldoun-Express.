package com.example.navigation

import kotlinx.serialization.Serializable

@Serializable
object RouteDashboard

@Serializable
data class RouteImport(val initialTabName: String = "BULK_PASTE")

@Serializable
object RouteCompanies

@Serializable
data class RouteCompanyDetail(val companyId: Long)

@Serializable
data class RouteStock(val openCamera: Boolean = false)

@Serializable
object RouteReports

@Serializable
object RouteSettings
