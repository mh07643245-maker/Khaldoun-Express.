package com.example.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ocr.OcrEngineMode
import com.example.shipments.NumeralStyle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "khaldoun_express_prefs")

data class AppSettingsState(
    val numeralStyle: NumeralStyle = NumeralStyle.WESTERN,
    val ocrMode: OcrEngineMode = OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT,
    val cameraLowResolution: Boolean = false,
    val cameraFrameIntervalMs: Long = 400L,
    val autoBackupEnabled: Boolean = true,
    val releaseOcrWhenIdle: Boolean = true,
    val driveAccountLabel: String = ""
)

class AppPreferences(private val context: Context) {

    private object Keys {
        val NUMERAL_STYLE = stringPreferencesKey("numeral_style")
        val OCR_MODE = stringPreferencesKey("ocr_mode")
        val CAMERA_LOW_RES = booleanPreferencesKey("camera_low_res")
        val CAMERA_FRAME_INTERVAL = longPreferencesKey("camera_frame_interval_ms")
        val AUTO_BACKUP = booleanPreferencesKey("auto_backup_enabled")
        val RELEASE_OCR_IDLE = booleanPreferencesKey("release_ocr_when_idle")
        val DRIVE_ACCOUNT = stringPreferencesKey("drive_account_label")
    }

    val settingsFlow: Flow<AppSettingsState> = context.dataStore.data.map { prefs ->
        AppSettingsState(
            numeralStyle = NumeralStyle.fromCode(prefs[Keys.NUMERAL_STYLE] ?: NumeralStyle.WESTERN.code),
            ocrMode = OcrEngineMode.fromCode(prefs[Keys.OCR_MODE] ?: OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT.code),
            cameraLowResolution = prefs[Keys.CAMERA_LOW_RES] ?: false,
            cameraFrameIntervalMs = prefs[Keys.CAMERA_FRAME_INTERVAL] ?: 400L,
            autoBackupEnabled = prefs[Keys.AUTO_BACKUP] ?: true,
            releaseOcrWhenIdle = prefs[Keys.RELEASE_OCR_IDLE] ?: true,
            driveAccountLabel = prefs[Keys.DRIVE_ACCOUNT].orEmpty()
        )
    }

    suspend fun setNumeralStyle(style: NumeralStyle) {
        context.dataStore.edit { it[Keys.NUMERAL_STYLE] = style.code }
    }

    suspend fun setOcrMode(mode: OcrEngineMode) {
        context.dataStore.edit { it[Keys.OCR_MODE] = mode.code }
    }

    suspend fun setCameraLowResolution(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CAMERA_LOW_RES] = enabled }
    }

    suspend fun setCameraFrameIntervalMs(intervalMs: Long) {
        context.dataStore.edit { it[Keys.CAMERA_FRAME_INTERVAL] = intervalMs.coerceIn(200L, 1200L) }
    }

    suspend fun setAutoBackupEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_BACKUP] = enabled }
    }

    suspend fun setReleaseOcrWhenIdle(enabled: Boolean) {
        context.dataStore.edit { it[Keys.RELEASE_OCR_IDLE] = enabled }
    }

    suspend fun setDriveAccountLabel(label: String) {
        context.dataStore.edit { it[Keys.DRIVE_ACCOUNT] = label }
    }
}
