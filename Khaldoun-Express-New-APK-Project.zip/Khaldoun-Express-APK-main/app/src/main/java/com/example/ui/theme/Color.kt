package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Khaldoun Express Brand Palette — Deep Logistics Navy + Express Amber + Teal
val NavyPrimary = Color(0xFF0A1A33)
val NavyContainer = Color(0xFF1E3A5F)
val OnNavyContainer = Color(0xFFE0ECFF)

val AmberAccent = Color(0xFFD97706)
val AmberLight = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF78350F)

val TealDelivered = Color(0xFF0F766E)
val TealLight = Color(0xFF14B8A6)
val TealContainer = Color(0xFFCCFBF1)
val OnTealContainer = Color(0xFF134E4A)

val ErrorCrimson = Color(0xFFDC2626)
val ErrorContainerLight = Color(0xFFFEE2E2)
val OnErrorContainerLight = Color(0xFF7F1D1D)

val PostponedBlue = Color(0xFF2563EB)
val PostponedContainer = Color(0xFFDBEAFE)

val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceVariantLight = Color(0xFFE2E8F0)
val CardLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

val SurfaceDark = Color(0xFF0B1220)
val SurfaceVariantDark = Color(0xFF1E293B)
val CardDark = Color(0xFF131D31)
val OnSurfaceDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)
