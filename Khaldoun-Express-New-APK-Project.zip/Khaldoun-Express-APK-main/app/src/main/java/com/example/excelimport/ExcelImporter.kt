package com.example.excelimport

import android.content.Context
import android.net.Uri
import com.example.bulkpaste.BulkPasteDraftRow
import com.example.shipments.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

data class ExcelImportResult(
    val fileName: String,
    val rows: List<BulkPasteDraftRow>,
    val detectedHeaders: List<String>,
    val skippedEmptyRows: Int,
    val errorMessages: List<String>
) {
    val totalDetected: Int get() = rows.size
    val validCount: Int get() = rows.count { !it.needsReview }
    val needsReviewCount: Int get() = rows.count { it.needsReview }
}

private enum class ColumnRole {
    NAME, PHONE, ADDRESS, PRICE
}

/**
 * Pure-Kotlin streaming XLSX reader using ZipInputStream + XmlPullParser.
 * Designed for Android minSdk 24+ (no javax.xml.stream dependency, minimal memory footprint on OPPO A5).
 * Preserves leading zeros in phone strings and handles dynamic column ordering.
 */
object ExcelImporter {

    suspend fun importFromUri(context: Context, uri: Uri, displayFileName: String): ExcelImportResult =
        withContext(Dispatchers.IO) {
            val stream = context.contentResolver.openInputStream(uri)
                ?: return@withContext ExcelImportResult(
                    fileName = displayFileName,
                    rows = emptyList(),
                    detectedHeaders = emptyList(),
                    skippedEmptyRows = 0,
                    errorMessages = listOf("تعذر فتح ملف Excel المحدد")
                )
            stream.use { parseXlsxStream(it, displayFileName) }
        }

    fun parseXlsxStream(inputStream: InputStream, fileName: String): ExcelImportResult {
        val entries = mutableMapOf<String, ByteArray>()
        try {
            ZipInputStream(inputStream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val name = entry.name.trimStart('/')
                        if (name == "xl/sharedStrings.xml" ||
                            name == "xl/workbook.xml" ||
                            name == "xl/_rels/workbook.xml.rels" ||
                            name.startsWith("xl/worksheets/sheet")
                        ) {
                            entries[name] = zip.readBytes()
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } catch (e: Exception) {
            return ExcelImportResult(
                fileName = fileName,
                rows = emptyList(),
                detectedHeaders = emptyList(),
                skippedEmptyRows = 0,
                errorMessages = listOf("الملف ليس بصيغة XLSX صالحة: ${e.localizedMessage ?: "خطأ قراءة"}")
            )
        }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheetPath = resolveFirstSheetPath(entries)
        val sheetBytes = sheetPath?.let { entries[it] }
            ?: entries.keys.filter { it.startsWith("xl/worksheets/sheet") }.sorted().firstOrNull()?.let { entries[it] }

        if (sheetBytes == null) {
            return ExcelImportResult(
                fileName = fileName,
                rows = emptyList(),
                detectedHeaders = emptyList(),
                skippedEmptyRows = 0,
                errorMessages = listOf("لم يتم العثور على ورقة عمل داخل ملف Excel")
            )
        }

        val rawGrid = parseWorksheetGrid(sheetBytes, sharedStrings)
        if (rawGrid.isEmpty()) {
            return ExcelImportResult(
                fileName = fileName,
                rows = emptyList(),
                detectedHeaders = emptyList(),
                skippedEmptyRows = 0,
                errorMessages = listOf("ورقة العمل فارغة")
            )
        }

        return mapGridToDraftRows(fileName, rawGrid)
    }

    private fun mapGridToDraftRows(
        fileName: String,
        grid: List<Map<Int, CellValue>>
    ): ExcelImportResult {
        val errors = mutableListOf<String>()
        var headerRowIndex = -1
        var columnMapping: Map<ColumnRole, Int> = emptyMap()
        var detectedHeaders: List<String> = emptyList()

        // Find header row within first 5 non-empty rows
        for (i in 0 until minOf(5, grid.size)) {
            val row = grid[i]
            val maxCol = row.keys.maxOrNull() ?: continue
            val headers = (0..maxCol).map { col -> row[col]?.text?.trim().orEmpty() }
            val detected = detectColumnMapping(headers)
            if (detected.size >= 2) {
                headerRowIndex = i
                columnMapping = detected
                detectedHeaders = headers.filter { it.isNotBlank() }
                break
            }
        }

        // Fallback to standard 4-column order if no explicit header row was found
        val startIndex = if (headerRowIndex >= 0) headerRowIndex + 1 else 0
        if (columnMapping.isEmpty()) {
            columnMapping = mapOf(
                ColumnRole.NAME to 0,
                ColumnRole.PHONE to 1,
                ColumnRole.ADDRESS to 2,
                ColumnRole.PRICE to 3
            )
        }

        val rows = mutableListOf<BulkPasteDraftRow>()
        var skippedEmpty = 0
        var rowId = 1L

        for (i in startIndex until grid.size) {
            val rowMap = grid[i]
            val allEmpty = rowMap.values.all { it.text.isBlank() }
            if (allEmpty) {
                skippedEmpty++
                continue
            }

            try {
                val nameCol = columnMapping[ColumnRole.NAME] ?: 0
                val phoneCol = columnMapping[ColumnRole.PHONE] ?: 1
                val addressCol = columnMapping[ColumnRole.ADDRESS] ?: 2
                val priceCol = columnMapping[ColumnRole.PRICE] ?: 3

                val name = rowMap[nameCol]?.text?.trim().orEmpty()
                val phoneCell = rowMap[phoneCol]
                val rawPhone = formatExcelPhoneCell(phoneCell)
                val address = rowMap[addressCol]?.text?.trim().orEmpty()
                val rawPrice = formatExcelPriceCell(rowMap[priceCol])
                val parsedPrice = PhoneNumberNormalizer.parsePrice(rawPrice)

                val issues = mutableListOf<String>()
                if (name.isBlank()) issues.add("اسم العميل مفقود")
                val normPhone = PhoneNumberNormalizer.normalize(rawPhone)
                if (rawPhone.isBlank()) {
                    issues.add("رقم الهاتف مفقود")
                } else if (normPhone.length < 7) {
                    issues.add("رقم الهاتف غير مكتمل")
                } else if (phoneCell?.isNumeric == true && !rawPhone.startsWith("0") && rawPhone.length == 10 &&
                    rawPhone.startsWith("1")
                ) {
                    issues.add("تحقق من الصفر الأول (تمت قراءته كرقم في Excel)")
                }
                if (address.isBlank()) issues.add("العنوان مفقود")
                if (parsedPrice == null) issues.add("السعر غير واضح")

                rows.add(
                    BulkPasteDraftRow(
                        rowId = rowId++,
                        lineNumber = i + 1,
                        customerName = name,
                        rawPhone = rawPhone,
                        address = address,
                        rawPrice = rawPrice,
                        parsedPrice = parsedPrice,
                        issues = issues
                    )
                )
            } catch (e: Exception) {
                errors.add("خطأ في الصف ${i + 1}: ${e.localizedMessage ?: "بيانات غير صالحة"}")
            }
        }

        return ExcelImportResult(
            fileName = fileName,
            rows = rows,
            detectedHeaders = detectedHeaders,
            skippedEmptyRows = skippedEmpty,
            errorMessages = errors
        )
    }

    private fun detectColumnMapping(headers: List<String>): Map<ColumnRole, Int> {
        val result = mutableMapOf<ColumnRole, Int>()
        headers.forEachIndexed { index, raw ->
            val h = PhoneNumberNormalizer.toWesternDigits(raw).trim().lowercase()
            if (h.isEmpty()) return@forEachIndexed
            when {
                ColumnRole.PHONE !in result && (
                    h.contains("هاتف") || h.contains("موبايل") || h.contains("تليفون") ||
                        h.contains("جوال") || h.contains("phone") || h.contains("mobile") || h.contains("tel")
                    ) -> result[ColumnRole.PHONE] = index

                ColumnRole.PRICE !in result && (
                    h.contains("سعر") || h.contains("مبلغ") || h.contains("قيمة") ||
                        h.contains("إجمالي") || h.contains("اجمالي") || h.contains("تحصيل") ||
                        h.contains("price") || h.contains("amount") || h.contains("cod") || h.contains("total")
                    ) -> result[ColumnRole.PRICE] = index

                ColumnRole.ADDRESS !in result && (
                    h.contains("عنوان") || h.contains("منطقة") || h.contains("محافظة") ||
                        h.contains("address") || h.contains("city") || h.contains("area")
                    ) -> result[ColumnRole.ADDRESS] = index

                ColumnRole.NAME !in result && (
                    h.contains("اسم") || h.contains("عميل") || h.contains("مستلم") ||
                        h.contains("name") || h.contains("customer") || h.contains("client")
                    ) -> result[ColumnRole.NAME] = index
            }
        }
        return result
    }

    private fun formatExcelPhoneCell(cell: CellValue?): String {
        if (cell == null) return ""
        val raw = PhoneNumberNormalizer.preserveRawPhone(cell.text)
        if (!cell.isNumeric) return raw
        // If Excel stored an integer like 1012345678.0 or scientific 1.012345678E9, avoid scientific notation!
        val asBigDecimal = raw.toBigDecimalOrNull()
        val integerString = if (asBigDecimal != null) {
            asBigDecimal.stripTrailingZeros().toPlainString().substringBefore('.')
        } else {
            raw
        }
        // If Egyptian 10-digit mobile lost its leading zero due to numeric Excel formatting, restore leading '0'
        return if (integerString.length == 10 && integerString.startsWith("1") &&
            integerString[1] in charArrayOf('0', '1', '2', '5')
        ) {
            "0$integerString"
        } else {
            integerString
        }
    }

    private fun formatExcelPriceCell(cell: CellValue?): String {
        if (cell == null) return ""
        val raw = cell.text.trim()
        if (!cell.isNumeric) return raw
        val bd = raw.toBigDecimalOrNull() ?: return raw
        val stripped = bd.stripTrailingZeros()
        return if (stripped.scale() <= 0) stripped.toPlainString() else stripped.toPlainString()
    }

    private data class CellValue(val text: String, val isNumeric: Boolean)

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val strings = mutableListOf<String>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")

        var inSi = false
        var inText = false
        val current = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "si" -> {
                            inSi = true
                            current.clear()
                        }
                        "t" -> if (inSi) inText = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inSi && inText) current.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "t" -> inText = false
                        "si" -> {
                            strings.add(current.toString())
                            inSi = false
                        }
                    }
                }
            }
            event = parser.next()
        }
        return strings
    }

    private fun resolveFirstSheetPath(entries: Map<String, ByteArray>): String? {
        val workbookBytes = entries["xl/workbook.xml"] ?: return null
        val relsBytes = entries["xl/_rels/workbook.xml.rels"] ?: return null

        var firstRid: String? = null
        val factory = XmlPullParserFactory.newInstance()
        val wbParser = factory.newPullParser()
        wbParser.setInput(ByteArrayInputStream(workbookBytes), "UTF-8")
        var event = wbParser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && wbParser.name == "sheet") {
                for (i in 0 until wbParser.attributeCount) {
                    if (wbParser.getAttributeName(i).endsWith("id")) {
                        firstRid = wbParser.getAttributeValue(i)
                        break
                    }
                }
                if (firstRid != null) break
            }
            event = wbParser.next()
        }
        if (firstRid == null) return null

        val relParser = factory.newPullParser()
        relParser.setInput(ByteArrayInputStream(relsBytes), "UTF-8")
        event = relParser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && relParser.name == "Relationship") {
                val id = relParser.getAttributeValue(null, "Id")
                val target = relParser.getAttributeValue(null, "Target")
                if (id == firstRid && target != null) {
                    return if (target.startsWith("/")) target.trimStart('/') else "xl/${target.trimStart('/')}"
                }
            }
            event = relParser.next()
        }
        return null
    }

    private fun parseWorksheetGrid(
        sheetBytes: ByteArray,
        sharedStrings: List<String>
    ): List<Map<Int, CellValue>> {
        val rows = mutableListOf<Map<Int, CellValue>>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(sheetBytes), "UTF-8")

        var currentRow: MutableMap<Int, CellValue>? = null
        var currentColIndex = -1
        var currentCellType = ""
        var inValueTag = false
        var inInlineTextTag = false
        val valueBuilder = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> currentRow = mutableMapOf()
                        "c" -> {
                            val cellRef = parser.getAttributeValue(null, "r").orEmpty()
                            currentColIndex = columnReferenceToIndex(cellRef, (currentRow?.keys?.maxOrNull() ?: -1) + 1)
                            currentCellType = parser.getAttributeValue(null, "t").orEmpty()
                            valueBuilder.clear()
                        }
                        "v" -> {
                            inValueTag = true
                            valueBuilder.clear()
                        }
                        "t" -> {
                            if (currentCellType == "inlineStr") {
                                inInlineTextTag = true
                            }
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inValueTag || inInlineTextTag) {
                        valueBuilder.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> inValueTag = false
                        "t" -> inInlineTextTag = false
                        "c" -> {
                            val rawText = valueBuilder.toString()
                            val cellValue = when (currentCellType) {
                                "s" -> {
                                    val idx = rawText.trim().toIntOrNull()
                                    CellValue(if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else "", false)
                                }
                                "inlineStr", "str", "e" -> CellValue(rawText, false)
                                "b" -> CellValue(if (rawText == "1") "TRUE" else "FALSE", false)
                                else -> CellValue(rawText, rawText.isNotBlank())
                            }
                            if (currentColIndex >= 0) {
                                currentRow?.put(currentColIndex, cellValue)
                            }
                        }
                        "row" -> {
                            currentRow?.let { rows.add(it) }
                            currentRow = null
                        }
                    }
                }
            }
            event = parser.next()
        }
        return rows
    }

    private fun columnReferenceToIndex(cellRef: String, fallback: Int): Int {
        if (cellRef.isBlank()) return fallback
        var col = 0
        var hasLetters = false
        for (ch in cellRef) {
            if (ch in 'A'..'Z') {
                hasLetters = true
                col = col * 26 + (ch - 'A' + 1)
            } else if (ch in 'a'..'z') {
                hasLetters = true
                col = col * 26 + (ch - 'a' + 1)
            } else {
                break
            }
        }
        return if (hasLetters) col - 1 else fallback
    }
}
