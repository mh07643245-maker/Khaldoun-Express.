package com.example.shipments

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

enum class CompanyFolder(val code: String, val arabicLabel: String) {
    DELIVERED("DELIVERED", "المسلم"),
    CASES("CASES", "الحالات");

    companion object {
        fun fromCode(code: String): CompanyFolder =
            entries.firstOrNull { it.code == code } ?: DELIVERED
    }
}

enum class ShipmentStatus(val code: String, val arabicLabel: String) {
    INITIAL("INITIAL", "تم"),
    DELIVERED("DELIVERED", "تم التسليم"),
    DELIVERY_ISSUE("DELIVERY_ISSUE", "مشكلة في التسليم"),
    POSTPONED("POSTPONED", "مؤجل"),
    CANCELLED("CANCELLED", "لاغي");

    companion object {
        fun fromCode(code: String): ShipmentStatus =
            entries.firstOrNull { it.code == code } ?: INITIAL

        val stockHandlingStatuses: List<ShipmentStatus> =
            listOf(DELIVERED, DELIVERY_ISSUE, POSTPONED, CANCELLED)
    }
}

enum class ShipmentSource(val code: String, val arabicLabel: String) {
    BULK_PASTE("BULK_PASTE", "نسخ ولصق مجمّع"),
    IMAGE_OCR("IMAGE_OCR", "استخراج من صورة"),
    EXCEL("EXCEL", "ملف Excel"),
    MANUAL("MANUAL", "إدخال يدوي");

    companion object {
        fun fromCode(code: String): ShipmentSource =
            entries.firstOrNull { it.code == code } ?: MANUAL
    }
}

enum class NumeralStyle(val code: String, val arabicLabel: String) {
    WESTERN("WESTERN", "أرقام إنجليزية (0123)"),
    ARABIC_INDIC("ARABIC_INDIC", "أرقام عربية (٠١٢٣)");

    companion object {
        fun fromCode(code: String): NumeralStyle =
            entries.firstOrNull { it.code == code } ?: WESTERN
    }
}

object CurrencyFormatter {
    private val symbols = DecimalFormatSymbols(Locale.US)
    private val integerFormat = DecimalFormat("#,##0", symbols)
    private val decimalFormat = DecimalFormat("#,##0.##", symbols)

    fun formatEgp(amount: Double, numeralStyle: NumeralStyle = NumeralStyle.WESTERN): String {
        val formatted = if (amount % 1.0 == 0.0) {
            integerFormat.format(amount)
        } else {
            decimalFormat.format(amount)
        }
        val localized = PhoneNumberNormalizer.formatDigitsForDisplay(formatted, numeralStyle)
        return "$localized ج.م"
    }

    fun formatPlainAmount(amount: Double): String {
        return if (amount % 1.0 == 0.0) {
            amount.toLong().toString()
        } else {
            DecimalFormat("0.##", symbols).format(amount)
        }
    }
}

object QuickNoteSuggestions {
    val defaultNotes = listOf(
        "رقم مغلق",
        "لا يرد",
        "رفض الاستلام",
        "رفض دفع المبلغ",
        "عنوان غير صحيح",
        "استلام جزئي",
        "مغلق",
        "مشكلة أخرى"
    )
}
