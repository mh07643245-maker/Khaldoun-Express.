package com.example.settings

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.backup.DriveBackupFile
import com.example.database.BackupRecordEntity
import com.example.database.DailyArchiveEntity
import com.example.ocr.OcrDiagnostics
import com.example.ocr.OcrEngineMode
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.ui.DeviceDiagnosticsInfo
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.TealDelivered
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    settings: AppSettingsState,
    ocrDiagnostics: OcrDiagnostics?,
    deviceInfo: DeviceDiagnosticsInfo,
    backupRecords: List<BackupRecordEntity>,
    archives: List<DailyArchiveEntity>,
    driveBackups: List<DriveBackupFile>,
    driveConnected: Boolean,
    onBack: () -> Unit,
    onOpenCompanies: () -> Unit,
    onNumeralStyleChange: (NumeralStyle) -> Unit,
    onOcrModeChange: (OcrEngineMode) -> Unit,
    onCameraLowResChange: (Boolean) -> Unit,
    onCameraIntervalChange: (Long) -> Unit,
    onAutoBackupChange: (Boolean) -> Unit,
    onReleaseOcrIdleChange: (Boolean) -> Unit,
    onCreateLocalBackup: () -> Unit,
    onExportBackupUri: (android.net.Uri) -> Unit,
    onRestoreLocalFile: (String) -> Unit,
    onRestoreUri: (android.net.Uri) -> Unit,
    onDriveTokenObtained: (token: String, accountLabel: String) -> Unit,
    onUploadDriveBackup: () -> Unit,
    onRestoreDriveBackup: (DriveBackupFile) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) onExportBackupUri(uri)
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onRestoreUri(uri)
    }

    val driveAuthLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            try {
                val authResult = Identity.getAuthorizationClient(context)
                    .getAuthorizationResultFromIntent(result.data)
                val token = authResult.accessToken
                if (!token.isNullOrBlank()) {
                    onDriveTokenObtained(token, "Google Drive متصل")
                    onShowMessage("تم ربط حساب Google Drive بنجاح")
                }
            } catch (e: Exception) {
                onShowMessage("تعذر إتمام ربط Google Drive: ${e.localizedMessage ?: ""}")
            }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
            }
            Text("الإعدادات ومعلومات الجهاز", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Companies shortcut
            item {
                SettingsSectionCard(title = "إدارة الشركات") {
                    OutlinedButton(onClick = onOpenCompanies, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Business, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("فتح إدارة شركات الشحن")
                    }
                }
            }

            // 2. Numerals display
            item {
                SettingsSectionCard(title = "إعدادات الأرقام العربية والإنجليزية") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumeralStyle.entries.forEach { style ->
                            FilterChip(
                                selected = settings.numeralStyle == style,
                                onClick = { onNumeralStyleChange(style) },
                                label = { Text(style.arabicLabel) },
                                modifier = Modifier.testTag("numeral_chip_${style.code}")
                            )
                        }
                    }
                }
            }

            // 3. Camera & Performance (OPPO A5 optimization)
            item {
                SettingsSectionCard(title = "إعدادات الكاميرا والأداء (مُحسّن لـ OPPO A5)") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("وضع توفير البطارية (640×480)", fontWeight = FontWeight.SemiBold)
                            Text("الافتراضي 1280×720 — لا يستخدم دقة 50MP كاملة أبدًا", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = settings.cameraLowResolution, onCheckedChange = onCameraLowResChange)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "فاصل قراءة الإطارات: ${settings.cameraFrameIntervalMs} مللي ثانية",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = settings.cameraFrameIntervalMs.toFloat(),
                        onValueChange = { onCameraIntervalChange(it.toLong()) },
                        valueRange = 250f..1000f,
                        steps = 5
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("تحرير ذاكرة OCR عند الخروج", fontWeight = FontWeight.SemiBold)
                            Text("يقلل استهلاك RAM والمعالج عند إغلاق الكاميرا", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = settings.releaseOcrWhenIdle, onCheckedChange = onReleaseOcrIdleChange)
                    }
                }
            }

            // 4. OCR Engine Diagnostics & Mode
            item {
                SettingsSectionCard(title = "إعدادات محرك OCR المحلي") {
                    OcrEngineMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.ocrMode == mode,
                            onClick = { onOcrModeChange(mode) },
                            label = { Text(mode.arabicLabel) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    ocrDiagnostics?.let { diag ->
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "نموذج Tesseract العربي: ${if (diag.arabicModelReady) "جاهز محليًا" else "غير متاح"} • الإنجليزي: ${if (diag.englishModelReady) "جاهز" else "غير متاح"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (diag.arabicModelReady) TealDelivered else AmberAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = diag.paddleNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 5. Local Backup, SAF Export & Restore
            item {
                SettingsSectionCard(title = "النسخ الاحتياطي المحلي والاستعادة") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("نسخ احتياطي تلقائي خلال اليوم", fontWeight = FontWeight.SemiBold)
                            Text("يعمل في الخلفية عبر WorkManager دون إنترنت", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = settings.autoBackupEnabled, onCheckedChange = onAutoBackupChange)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onCreateLocalBackup,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("backup_now_button")
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("نسخ الآن")
                        }
                        OutlinedButton(
                            onClick = { exportBackupLauncher.launch("khaldoun_backup.json") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تصدير ملف")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { importBackupLauncher.launch(arrayOf("application/json", "*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("استعادة نسخة احتياطية من ملف")
                    }

                    if (backupRecords.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("النسخ المحلية المحفوظة (حسب التاريخ):", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        backupRecords.take(5).forEach { rec ->
                            val dateTxt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(rec.createdAt))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${rec.backupType} • $dateTxt", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text("${rec.shipmentCount} شحنة • ${rec.companyCount} شركة", style = MaterialTheme.typography.labelSmall)
                                }
                                OutlinedButton(onClick = { onRestoreLocalFile(rec.localPath) }) {
                                    Text("استعادة")
                                }
                            }
                        }
                    }
                }
            }

            // 6. Google Drive Cloud Backup (Optional with OAuth)
            item {
                SettingsSectionCard(title = "النسخ الاحتياطي السحابي (Google Drive API)") {
                    Text(
                        text = "الحالة: ${if (driveConnected) "حساب Google مرتبط (${settings.driveAccountLabel})" else "غير مرتبط (التطبيق يعمل محليًا بالكامل بدون إنترنت)"}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "متطلب OAuth: الصلاحية المطلوبة https://www.googleapis.com/auth/drive.file — يتم تفعيلها بتسجيل بصمة SHA-1 لـ OAuth Client في Google Cloud Console.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val req = AuthorizationRequest.builder()
                                    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.file")))
                                    .build()
                                Identity.getAuthorizationClient(context)
                                    .authorize(req)
                                    .addOnSuccessListener { authResult ->
                                        if (authResult.hasResolution()) {
                                            authResult.pendingIntent?.intentSender?.let { sender ->
                                                driveAuthLauncher.launch(IntentSenderRequest.Builder(sender).build())
                                            }
                                        } else {
                                            val token = authResult.accessToken
                                            if (!token.isNullOrBlank()) {
                                                onDriveTokenObtained(token, "Google Drive متصل")
                                                onShowMessage("تم التحقق من ربط Google Drive")
                                            }
                                        }
                                    }
                                    .addOnFailureListener { e ->
                                        onShowMessage("ربط Google Drive يتطلب إعداد OAuth SHA-1 في Google Cloud Console: ${e.localizedMessage ?: ""}")
                                    }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ربط Google")
                        }
                        Button(
                            onClick = onUploadDriveBackup,
                            enabled = driveConnected,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("رفع إلى Drive")
                        }
                    }
                    driveBackups.take(4).forEach { df ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(df.name, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { onRestoreDriveBackup(df) }) {
                                Text("استعادة")
                            }
                        }
                    }
                }
            }

            // 7. Archive Management summary
            item {
                SettingsSectionCard(title = "إدارة الأرشيف (${archives.size} يوم مؤرشف)") {
                    if (archives.isEmpty()) {
                        Text("لا توجد أيام مؤرشفة بعد.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        archives.take(7).forEach { arch ->
                            Text(
                                text = "يوم ${arch.archiveDate}: ${PhoneNumberNormalizer.formatDigitsForDisplay(arch.totalShipments.toString(), settings.numeralStyle)} شحنة",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            // 8. Device & App Info (No personal data)
            item {
                SettingsSectionCard(title = "معلومات الجهاز والتطبيق") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(deviceInfo.manufacturerModel, fontWeight = FontWeight.Bold)
                    }
                    Text("إصدار Android الفعلي: ${deviceInfo.androidVersion} (API ${deviceInfo.sdkInt})", style = MaterialTheme.typography.bodySmall)
                    Text("الذاكرة المتاحة: ${deviceInfo.availableRamMb} MB من إجمالي ${deviceInfo.totalRamMb} MB", style = MaterialTheme.typography.bodySmall)
                    Text("المعالج المدعوم (ABIs): ${deviceInfo.supportedAbis}", style = MaterialTheme.typography.bodySmall)
                    Text("إصدار التطبيق: ${deviceInfo.appVersion} — خلدون إكسبريس", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
