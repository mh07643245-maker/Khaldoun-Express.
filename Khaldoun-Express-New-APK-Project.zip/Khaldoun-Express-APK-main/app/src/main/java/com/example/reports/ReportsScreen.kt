package com.example.reports

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.database.CompanyEntity
import com.example.database.DailyArchiveEntity
import com.example.shipments.CompanyFolder
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.ui.ReportsUiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealDelivered
import java.io.File

@Composable
fun ReportsScreen(
    uiState: ReportsUiState,
    companies: List<CompanyEntity>,
    archives: List<DailyArchiveEntity>,
    numeralStyle: NumeralStyle,
    onSelectReportType: (ReportType) -> Unit,
    onSelectCompany: (Long?) -> Unit,
    onSelectFolder: (CompanyFolder?) -> Unit,
    onSelectArchiveDate: (String) -> Unit,
    onExportPdf: (onReady: (File) -> Unit) -> Unit,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pendingSaveFile by remember { mutableStateOf<File?>(null) }

    val savePdfSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val srcFile = pendingSaveFile
        if (uri != null && srcFile != null && srcFile.exists()) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    srcFile.inputStream().use { input -> input.copyTo(out) }
                }
                onMessage("تم حفظ ملف PDF في الجهاز بنجاح")
            } catch (e: Exception) {
                onMessage("تعذر حفظ PDF: ${e.localizedMessage ?: ""}")
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("نوع التقرير الشامل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReportType.entries.forEach { type ->
                    FilterChip(
                        selected = uiState.selectedReportType == type,
                        onClick = { onSelectReportType(type) },
                        label = { Text(type.arabicTitle) },
                        modifier = Modifier.testTag("report_type_${type.code}")
                    )
                }
            }
        }

        if (uiState.selectedReportType == ReportType.ARCHIVE_BY_DATE) {
            item {
                Text("اختر يومًا من الأرشيف:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                if (archives.isEmpty()) {
                    Text(
                        text = "لا توجد أيام مؤرشفة بعد — يتم إنشاء الأرشيف عند الضغط على (إنهاء اليوم / بدء يوم جديد).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        archives.forEach { arch ->
                            FilterChip(
                                selected = uiState.selectedArchiveDate == arch.archiveDate,
                                onClick = { onSelectArchiveDate(arch.archiveDate) },
                                label = { Text("${arch.archiveDate} (${arch.totalShipments})") }
                            )
                        }
                    }
                }
            }
        }

        // Company filter
        item {
            Text("فلترة حسب الشركة:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = uiState.selectedCompanyId == null,
                    onClick = { onSelectCompany(null) },
                    label = { Text("جميع الشركات") }
                )
                companies.forEach { company ->
                    FilterChip(
                        selected = uiState.selectedCompanyId == company.id,
                        onClick = { onSelectCompany(company.id) },
                        label = { Text(company.name) }
                    )
                }
            }
        }

        // Folder filter (strictly المسلم / الحالات / الكل)
        item {
            Text("المجلد داخل الشركة:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = uiState.selectedFolder == null,
                    onClick = { onSelectFolder(null) },
                    label = { Text("المسلم + الحالات") }
                )
                CompanyFolder.entries.forEach { folder ->
                    FilterChip(
                        selected = uiState.selectedFolder == folder,
                        onClick = { onSelectFolder(folder) },
                        label = { Text(folder.arabicLabel) }
                    )
                }
            }
        }

        // Export Arabic PDF actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onExportPdf { file ->
                            val uri = FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                file
                            )
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة التقرير PDF"))
                        }
                    },
                    enabled = !uiState.isLoading && (uiState.currentReport?.rows?.isNotEmpty() == true),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("export_share_pdf_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("تصدير ومشاركة PDF")
                }

                OutlinedButton(
                    onClick = {
                        onExportPdf { file ->
                            pendingSaveFile = file
                            savePdfSafLauncher.launch(file.name)
                        }
                    },
                    enabled = !uiState.isLoading && (uiState.currentReport?.rows?.isNotEmpty() == true),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_pdf_device_button")
                ) {
                    Icon(Icons.Default.SaveAlt, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("حفظ PDF")
                }
            }
        }

        if (uiState.isLoading) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp))
                    Text("جاري تجهيز التقرير...")
                }
            }
        }

        val report = uiState.currentReport
        if (report != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AmberContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(report.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${report.companyName}  •  ${report.folderSubtitle}  •  التاريخ: ${PhoneNumberNormalizer.formatDigitsForDisplay(report.reportDate, numeralStyle)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "إجمالي الأصلي: ${CurrencyFormatter.formatEgp(report.totalOriginalPrice, numeralStyle)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "إجمالي المسلم: ${CurrencyFormatter.formatEgp(report.totalDeliveredPrice, numeralStyle)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TealDelivered
                            )
                        }
                        Text(
                            text = "عدد الشحنات: ${PhoneNumberNormalizer.formatDigitsForDisplay(report.totalCount.toString(), numeralStyle)}",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            if (report.rows.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Assessment,
                        title = "لا توجد شحنات في هذا التقرير",
                        subtitle = "غيّر نوع التقرير أو الشركة أو المجلد لعرض الشحنات المسجلة."
                    )
                }
            } else {
                items(report.rows, key = { it.shipmentId }) { row ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(row.customerName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Text("${row.folderLabel} • ${row.statusLabel}", style = MaterialTheme.typography.labelSmall, color = AmberAccent, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = "${PhoneNumberNormalizer.formatDigitsForDisplay(row.rawPhone, numeralStyle)}  •  ${row.companyName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (row.address.isNotBlank()) {
                                Text(row.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("الأصلي: ${CurrencyFormatter.formatEgp(row.originalPrice, numeralStyle)}", style = MaterialTheme.typography.labelMedium)
                                Text("المسلم: ${CurrencyFormatter.formatEgp(row.deliveredPrice, numeralStyle)}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TealDelivered)
                            }
                            if (row.notes.isNotBlank()) {
                                Text("ملاحظات: ${row.notes}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
