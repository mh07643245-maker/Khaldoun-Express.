package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.app.AppContainer
import com.example.pdf.ArabicPdfExporter
import com.example.reports.ReportType
import com.example.reports.ShipmentReport
import com.example.shipments.CompanyFolder
import com.example.shipments.NumeralStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class ReportsUiState(
    val selectedReportType: ReportType = ReportType.ALL_COMPANIES,
    val selectedCompanyId: Long? = null,
    val selectedFolder: CompanyFolder? = null,
    val selectedArchiveDate: String? = null,
    val currentReport: ShipmentReport? = null,
    val isLoading: Boolean = false,
    val lastExportedPdf: File? = null,
    val message: String? = null
)

class ReportsViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val reportsManager = container.reportsManager

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    init {
        generateReport()
    }

    fun selectReportType(type: ReportType) {
        _uiState.update {
            val defaultFolder = when (type) {
                ReportType.COMPANY_DELIVERED -> CompanyFolder.DELIVERED
                ReportType.COMPANY_CASES -> CompanyFolder.CASES
                else -> null
            }
            it.copy(selectedReportType = type, selectedFolder = defaultFolder, message = null)
        }
        generateReport()
    }

    fun selectCompany(companyId: Long?) {
        _uiState.update { it.copy(selectedCompanyId = companyId) }
        generateReport()
    }

    fun selectFolder(folder: CompanyFolder?) {
        _uiState.update { it.copy(selectedFolder = folder) }
        generateReport()
    }

    fun selectArchiveDate(date: String) {
        _uiState.update {
            it.copy(
                selectedReportType = ReportType.ARCHIVE_BY_DATE,
                selectedArchiveDate = date
            )
        }
        generateReport()
    }

    fun generateReport() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val report = if (state.selectedReportType == ReportType.ARCHIVE_BY_DATE && state.selectedArchiveDate != null) {
                reportsManager.generateArchivedReport(
                    archiveDate = state.selectedArchiveDate,
                    companyId = state.selectedCompanyId,
                    folderFilter = state.selectedFolder
                )
            } else {
                reportsManager.generateActiveReport(
                    type = state.selectedReportType,
                    companyId = state.selectedCompanyId,
                    folderFilter = state.selectedFolder
                )
            }
            _uiState.update { it.copy(currentReport = report, isLoading = false) }
        }
    }

    fun exportCurrentReportToPdf(numeralStyle: NumeralStyle, onPdfReady: (File) -> Unit) {
        val report = _uiState.value.currentReport ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            try {
                val pdfFile = ArabicPdfExporter.exportReportToPdf(appContext, report, numeralStyle)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        lastExportedPdf = pdfFile,
                        message = "تم إنشاء ملف PDF العربي بنجاح: ${pdfFile.name}"
                    )
                }
                onPdfReady(pdfFile)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        message = "فشل تصدير PDF: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                    )
                }
            }
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }

    companion object {
        fun factory(appContext: Context, container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ReportsViewModel(appContext.applicationContext, container) as T
                }
            }
    }
}
