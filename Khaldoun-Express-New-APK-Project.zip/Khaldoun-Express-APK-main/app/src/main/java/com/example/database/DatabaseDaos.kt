package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies ORDER BY isArchived ASC, isActive DESC, name ASC")
    fun observeAllCompanies(): Flow<List<CompanyEntity>>

    @Query("SELECT * FROM companies WHERE isActive = 1 AND isArchived = 0 ORDER BY name ASC")
    fun observeSelectableCompanies(): Flow<List<CompanyEntity>>

    @Query("SELECT * FROM companies ORDER BY id ASC")
    suspend fun getAllCompaniesOnce(): List<CompanyEntity>

    @Query("SELECT * FROM companies WHERE id = :companyId LIMIT 1")
    suspend fun getCompanyById(companyId: Long): CompanyEntity?

    @Query("SELECT * FROM companies WHERE name = :name LIMIT 1")
    suspend fun getCompanyByName(name: String): CompanyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompany(company: CompanyEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanies(companies: List<CompanyEntity>)

    @Update
    suspend fun updateCompany(company: CompanyEntity)

    @Query("SELECT COUNT(*) FROM companies")
    suspend fun getCompanyCount(): Int
}

@Dao
interface ShipmentDao {
    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 0
        ORDER BY s.updatedAt DESC, s.id DESC
        """
    )
    fun observeActiveShipmentsWithCompany(): Flow<List<ShipmentWithCompany>>

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 0 AND s.companyId = :companyId
        ORDER BY s.updatedAt DESC, s.id DESC
        """
    )
    fun observeActiveShipmentsByCompany(companyId: Long): Flow<List<ShipmentWithCompany>>

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 0
          AND (
            s.customerName LIKE '%' || :query || '%'
            OR s.normalizedPhone LIKE '%' || :normalizedQuery || '%'
            OR s.last5Digits = :last5
            OR s.rawPhone LIKE '%' || :query || '%'
          )
        ORDER BY s.updatedAt DESC, s.id DESC
        """
    )
    fun observeSearchActiveShipments(
        query: String,
        normalizedQuery: String,
        last5: String
    ): Flow<List<ShipmentWithCompany>>

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 0
          AND (s.last5Digits = :last5 OR s.normalizedPhone = :normalizedPhone)
        ORDER BY
          CASE WHEN s.normalizedPhone = :normalizedPhone THEN 0 ELSE 1 END,
          s.updatedAt DESC
        """
    )
    suspend fun findActiveByPhoneOrLast5(
        normalizedPhone: String,
        last5: String
    ): List<ShipmentWithCompany>

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 1 AND s.archiveDate = :archiveDate
        ORDER BY c.name ASC, s.id DESC
        """
    )
    suspend fun getArchivedShipmentsByDate(archiveDate: String): List<ShipmentWithCompany>

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.isArchived = 0
        ORDER BY c.name ASC, s.folder ASC, s.id DESC
        """
    )
    suspend fun getActiveShipmentsOnce(): List<ShipmentWithCompany>

    @Query("SELECT * FROM shipments ORDER BY id ASC")
    suspend fun getAllShipmentsOnce(): List<ShipmentEntity>

    @Query("SELECT * FROM shipments WHERE id = :shipmentId LIMIT 1")
    suspend fun getShipmentById(shipmentId: Long): ShipmentEntity?

    @Query(
        """
        SELECT s.*, c.name AS companyName
        FROM shipments s
        INNER JOIN companies c ON s.companyId = c.id
        WHERE s.id = :shipmentId LIMIT 1
        """
    )
    fun observeShipmentById(shipmentId: Long): Flow<ShipmentWithCompany?>

    @Query(
        """
        SELECT
          COUNT(*) AS totalTodayShipments,
          COALESCE(SUM(CASE WHEN folder = 'DELIVERED' THEN 1 ELSE 0 END), 0) AS deliveredFolderCount,
          COALESCE(SUM(CASE WHEN folder = 'CASES' THEN 1 ELSE 0 END), 0) AS casesFolderCount,
          COALESCE(SUM(originalPrice), 0.0) AS totalOriginalPrice,
          COALESCE(SUM(deliveredPrice), 0.0) AS totalDeliveredPrice
        FROM shipments
        WHERE isArchived = 0
        """
    )
    fun observeDashboardSummary(): Flow<DashboardSummary>

    @Query(
        """
        SELECT
          c.id AS companyId,
          c.name AS companyName,
          c.isActive AS isActive,
          c.isArchived AS isArchived,
          COUNT(s.id) AS totalCount,
          COALESCE(SUM(CASE WHEN s.folder = 'DELIVERED' THEN 1 ELSE 0 END), 0) AS deliveredFolderCount,
          COALESCE(SUM(CASE WHEN s.folder = 'CASES' THEN 1 ELSE 0 END), 0) AS casesFolderCount,
          COALESCE(SUM(s.originalPrice), 0.0) AS totalOriginalPrice,
          COALESCE(SUM(s.deliveredPrice), 0.0) AS totalDeliveredPrice
        FROM companies c
        LEFT JOIN shipments s ON c.id = s.companyId AND s.isArchived = 0
        GROUP BY c.id
        ORDER BY c.isArchived ASC, c.isActive DESC, totalCount DESC, c.name ASC
        """
    )
    fun observeCompanyCounts(): Flow<List<CompanyShipmentCounts>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipment(shipment: ShipmentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(shipments: List<ShipmentEntity>): List<Long>

    @Update
    suspend fun updateShipment(shipment: ShipmentEntity)

    @Query("DELETE FROM shipments WHERE id = :shipmentId")
    suspend fun deleteShipmentById(shipmentId: Long)

    @Query(
        """
        UPDATE shipments
        SET isArchived = 1, archiveDate = :archiveDate, updatedAt = :timestamp
        WHERE isArchived = 0
        """
    )
    suspend fun archiveAllActiveShipments(archiveDate: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM shipments WHERE isArchived = 0")
    suspend fun getActiveShipmentCount(): Int

    @Query("SELECT COUNT(*) FROM shipments")
    suspend fun getTotalShipmentCount(): Int

    @Query("SELECT COUNT(*) FROM shipments WHERE batchId = :batchId AND isArchived = 0")
    suspend fun countByBatchId(batchId: String): Int
}

@Dao
interface ShipmentMetadataDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertStatuses(statuses: List<ShipmentStatusEntity>)

    @Query("SELECT * FROM shipment_statuses ORDER BY sortOrder ASC")
    fun observeStatuses(): Flow<List<ShipmentStatusEntity>>

    @Insert
    suspend fun insertNote(note: ShipmentNoteEntity): Long

    @Insert
    suspend fun insertNotes(notes: List<ShipmentNoteEntity>)

    @Query("SELECT * FROM shipment_notes WHERE shipmentId = :shipmentId ORDER BY createdAt DESC")
    fun observeNotesForShipment(shipmentId: Long): Flow<List<ShipmentNoteEntity>>

    @Query("SELECT * FROM shipment_notes ORDER BY id ASC")
    suspend fun getAllNotesOnce(): List<ShipmentNoteEntity>

    @Insert
    suspend fun insertEditHistory(entry: EditHistoryEntity): Long

    @Insert
    suspend fun insertEditHistoryList(entries: List<EditHistoryEntity>)

    @Query("SELECT * FROM edit_history WHERE shipmentId = :shipmentId ORDER BY editedAt DESC")
    fun observeEditHistoryForShipment(shipmentId: Long): Flow<List<EditHistoryEntity>>

    @Query("SELECT * FROM edit_history ORDER BY id ASC")
    suspend fun getAllEditHistoryOnce(): List<EditHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyArchive(archive: DailyArchiveEntity): Long

    @Query("SELECT * FROM daily_archives ORDER BY archiveDate DESC, createdAt DESC")
    fun observeDailyArchives(): Flow<List<DailyArchiveEntity>>

    @Query("SELECT * FROM daily_archives ORDER BY archiveDate DESC")
    suspend fun getAllDailyArchivesOnce(): List<DailyArchiveEntity>

    @Query("SELECT * FROM daily_archives WHERE archiveDate = :date LIMIT 1")
    suspend fun getDailyArchiveByDate(date: String): DailyArchiveEntity?

    @Insert
    suspend fun insertBackupRecord(record: BackupRecordEntity): Long

    @Query("SELECT * FROM backup_records ORDER BY createdAt DESC LIMIT 50")
    fun observeBackupRecords(): Flow<List<BackupRecordEntity>>

    @Query("SELECT * FROM backup_records ORDER BY createdAt DESC")
    suspend fun getAllBackupRecordsOnce(): List<BackupRecordEntity>
}

@Dao
interface RestoreTransactionDao {
    @Query("DELETE FROM shipment_notes")
    suspend fun clearNotes()

    @Query("DELETE FROM edit_history")
    suspend fun clearEditHistory()

    @Query("DELETE FROM shipments")
    suspend fun clearShipments()

    @Query("DELETE FROM companies")
    suspend fun clearCompanies()

    @Query("DELETE FROM daily_archives")
    suspend fun clearDailyArchives()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanies(companies: List<CompanyEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(shipments: List<ShipmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<ShipmentNoteEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEditHistory(history: List<EditHistoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyArchives(archives: List<DailyArchiveEntity>)

    @Transaction
    suspend fun replaceDatabaseSnapshot(
        companies: List<CompanyEntity>,
        shipments: List<ShipmentEntity>,
        notes: List<ShipmentNoteEntity>,
        history: List<EditHistoryEntity>,
        archives: List<DailyArchiveEntity>
    ) {
        clearNotes()
        clearEditHistory()
        clearShipments()
        clearCompanies()
        clearDailyArchives()
        if (companies.isNotEmpty()) insertCompanies(companies)
        if (shipments.isNotEmpty()) insertShipments(shipments)
        if (notes.isNotEmpty()) insertNotes(notes)
        if (history.isNotEmpty()) insertEditHistory(history)
        if (archives.isNotEmpty()) insertDailyArchives(archives)
    }
}
