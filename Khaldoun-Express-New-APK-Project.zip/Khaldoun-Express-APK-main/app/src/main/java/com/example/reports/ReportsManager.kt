package com.example.reports

import com.example.database.ShipmentWithCompany
import com.example.repositories.ShipmentRepository
import com.example.shipments.CompanyFolder
import com.example.shipments.ShipmentStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ReportType(val code: String, val arabicTitle: String) {
    COMPANY_DELIVERED("COMPANY_DELIVERED", "تقرير المسلم للشركة"),
    COMPANY_CASES("COMPANY_CASES", "تقرير الحالات للشركة"),
    COMPANY_DAILY("COMPANY_DAILY", "التقرير اليومي للشركة"),
    ALL_COMPANIES("ALL_COMPANIES", "التقرير الشامل لجميع الشركات"),
    ARCHIVE_BY_DATE("ARCHIVE_BY_DATE", "تقرير يوم سابق من الأرشيف")
}

data class ReportRow(
    val shipmentId: Long,
    val companyName: String,
    val customerName: String,
    val rawPhone: String,
    val address: String,
    val originalPrice: Double,
    val deliveredPrice: Double,
    val folderLabel: String,
    val statusLabel: String,
    val notes: String
)

data class ShipmentReport(
    val reportType: ReportType,
    val title: String,
    val companyName: String,
    val reportDate: String,
    val folderSubtitle: String,
    val rows: List<ReportRow>,
    val totalCount: Int,
    val totalOriginalPrice: Double,
    val totalDeliveredPrice: Double
)

class ReportsManager(private val repository: ShipmentRepository) {

    fun todayDateKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    suspend fun generateActiveReport(
        type: ReportType,
        companyId: Long? = null,
        folderFilter: CompanyFolder? = null
    ): ShipmentReport {
        val allActive = repository.getActiveShipmentsOnce()
        val companyName = if (companyId != null) {
            repository.getCompanyById(companyId)?.name ?: "شركة غير محددة"
        } else {
            "جميع الشركات"
        }

        val effectiveFolder = folderFilter ?: when (type) {
            ReportType.COMPANY_DELIVERED -> CompanyFolder.DELIVERED
            ReportType.COMPANY_CASES -> CompanyFolder.CASES
            else -> null
        }

        val filtered = allActive.filter { item ->
            val matchesCompany = companyId == null || item.shipment.companyId == companyId
            val matchesFolder = effectiveFolder == null || item.shipment.folder == effectiveFolder.code
            matchesCompany && matchesFolder
        }

        val folderSubtitle = when {
            effectiveFolder != null -> "مجلد: ${effectiveFolder.arabicLabel}"
            else -> "جميع المجلدات (المسلم + الحالات)"
        }

        return buildReport(
            type = type,
            title = type.arabicTitle,
            companyName = companyName,
            reportDate = todayDateKey(),
            folderSubtitle = folderSubtitle,
            items = filtered
        )
    }

    suspend fun generateArchivedReport(
        archiveDate: String,
        companyId: Long? = null,
        folderFilter: CompanyFolder? = null
    ): ShipmentReport {
        val archived = repository.getArchivedShipmentsByDate(archiveDate)
        val companyName = if (companyId != null) {
            repository.getCompanyById(companyId)?.name ?: "شركة غير محددة"
        } else {
            "جميع الشركات"
        }
        val filtered = archived.filter { item ->
            val matchesCompany = companyId == null || item.shipment.companyId == companyId
            val matchesFolder = folderFilter == null || item.shipment.folder == folderFilter.code
            matchesCompany && matchesFolder
        }
        val folderSubtitle = folderFilter?.let { "مجلد: ${it.arabicLabel}" } ?: "جميع المجلدات"
        return buildReport(
            type = ReportType.ARCHIVE_BY_DATE,
            title = "تقرير أرشيف يوم $archiveDate",
            companyName = companyName,
            reportDate = archiveDate,
            folderSubtitle = folderSubtitle,
            items = filtered
        )
    }

    fun buildReport(
        type: ReportType,
        title: String,
        companyName: String,
        reportDate: String,
        folderSubtitle: String,
        items: List<ShipmentWithCompany>
    ): ShipmentReport {
        val rows = items.map { item ->
            val s = item.shipment
            ReportRow(
                shipmentId = s.id,
                companyName = item.companyName,
                customerName = s.customerName,
                rawPhone = s.rawPhone,
                address = s.address,
                originalPrice = s.originalPrice,
                deliveredPrice = s.deliveredPrice,
                folderLabel = CompanyFolder.fromCode(s.folder).arabicLabel,
                statusLabel = ShipmentStatus.fromCode(s.statusCode).arabicLabel,
                notes = s.notes
            )
        }
        return ShipmentReport(
            reportType = type,
            title = title,
            companyName = companyName,
            reportDate = reportDate,
            folderSubtitle = folderSubtitle,
            rows = rows,
            totalCount = rows.size,
            totalOriginalPrice = rows.sumOf { it.originalPrice },
            totalDeliveredPrice = rows.sumOf { it.deliveredPrice }
        )
    }
}
