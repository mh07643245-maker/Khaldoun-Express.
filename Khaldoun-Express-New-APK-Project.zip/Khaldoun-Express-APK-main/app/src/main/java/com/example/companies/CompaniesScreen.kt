package com.example.companies

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.database.CompanyEntity
import com.example.database.CompanyShipmentCounts
import com.example.database.ShipmentWithCompany
import com.example.shipments.CompanyFolder
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.ui.components.AddCompanyDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ShipmentSummaryCard
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.TealDelivered

@Composable
fun CompaniesScreen(
    companies: List<CompanyEntity>,
    companyCounts: List<CompanyShipmentCounts>,
    numeralStyle: NumeralStyle,
    onAddCompany: (name: String, code: String, phone: String, notes: String) -> Unit,
    onUpdateCompany: (CompanyEntity) -> Unit,
    onToggleActive: (Long, Boolean) -> Unit,
    onToggleArchived: (Long, Boolean) -> Unit,
    onOpenCompanyDetail: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingCompany by remember { mutableStateOf<CompanyEntity?>(null) }

    val countsMap = remember(companyCounts) { companyCounts.associateBy { it.companyId } }
    val filtered = remember(companies, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) companies
        else companies.filter { it.name.lowercase().contains(q) || it.code.lowercase().contains(q) }
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.testTag("add_company_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة شركة")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("البحث عن شركة شحن") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_company_input")
                )
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Business,
                        title = "لا توجد شركات مطابقة",
                        subtitle = "اضغط على زر (+) لإضافة شركة شحن جديدة.",
                        actionLabel = "إضافة شركة",
                        onAction = { showAddDialog = true }
                    )
                }
            } else {
                items(filtered, key = { it.id }) { company ->
                    val stats = countsMap[company.id]
                    CompanyManageCard(
                        company = company,
                        stats = stats,
                        numeralStyle = numeralStyle,
                        onOpen = { onOpenCompanyDetail(company.id) },
                        onEdit = { editingCompany = company },
                        onToggleActive = { onToggleActive(company.id, !company.isActive) },
                        onToggleArchive = { onToggleArchived(company.id, !company.isArchived) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddCompanyDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, code, phone, notes ->
                onAddCompany(name, code, phone, notes)
                showAddDialog = false
            }
        )
    }

    editingCompany?.let { target ->
        AddCompanyDialog(
            initialCompany = target,
            onDismiss = { editingCompany = null },
            onConfirm = { name, code, phone, notes ->
                onUpdateCompany(target.copy(name = name, code = code, contactPhone = phone, notes = notes))
                editingCompany = null
            }
        )
    }
}

@Composable
private fun CompanyManageCard(
    company: CompanyEntity,
    stats: CompanyShipmentCounts?,
    numeralStyle: NumeralStyle,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onToggleActive: () -> Unit,
    onToggleArchive: () -> Unit
) {
    Card(
        onClick = onOpen,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("company_card_${company.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = company.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    val stateLabel = when {
                        company.isArchived -> "مؤرشفة (السجلات محفوظة)"
                        !company.isActive -> "معطلة (السجلات محفوظة)"
                        else -> "نشطة"
                    }
                    Text(
                        text = "الحالة: $stateLabel" + if (company.code.isNotBlank()) " • كود: ${company.code}" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (company.isActive && !company.isArchived) TealDelivered else AmberAccent
                    )
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل الشركة")
                }
            }

            if (stats != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "مجلد المسلم: ${PhoneNumberNormalizer.formatDigitsForDisplay(stats.deliveredFolderCount.toString(), numeralStyle)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TealDelivered,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "مجلد الحالات: ${PhoneNumberNormalizer.formatDigitsForDisplay(stats.casesFolderCount.toString(), numeralStyle)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleActive,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (company.isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (company.isActive) "تعطيل" else "تفعيل")
                }
                OutlinedButton(
                    onClick = onToggleArchive,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Archive, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (company.isArchived) "إلغاء الأرشفة" else "أرشفة")
                }
            }
        }
    }
}

/**
 * Displays a single company's shipments strictly grouped into ONLY TWO folders:
 * 1. المسلم (DELIVERED)
 * 2. الحالات (CASES)
 */
@Composable
fun CompanyDetailScreen(
    company: CompanyEntity?,
    shipments: List<ShipmentWithCompany>,
    numeralStyle: NumeralStyle,
    onBack: () -> Unit,
    onOpenShipment: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var selectedFolder by remember { mutableStateOf(CompanyFolder.DELIVERED) }
    val deliveredList = remember(shipments) {
        shipments.filter { it.shipment.folder == CompanyFolder.DELIVERED.code }
    }
    val casesList = remember(shipments) {
        shipments.filter { it.shipment.folder == CompanyFolder.CASES.code }
    }
    val visibleList = if (selectedFolder == CompanyFolder.DELIVERED) deliveredList else casesList

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = company?.name ?: "تفاصيل الشركة",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "إجمالي النشط: ${PhoneNumberNormalizer.formatDigitsForDisplay(shipments.size.toString(), numeralStyle)} شحنة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Strictly TWO folders inside every company: المسلم and الحالات
        TabRow(selectedTabIndex = selectedFolder.ordinal) {
            Tab(
                selected = selectedFolder == CompanyFolder.DELIVERED,
                onClick = { selectedFolder = CompanyFolder.DELIVERED },
                text = {
                    Text(
                        "المسلم (${PhoneNumberNormalizer.formatDigitsForDisplay(deliveredList.size.toString(), numeralStyle)})",
                        fontWeight = FontWeight.Bold
                    )
                },
                icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                modifier = Modifier.testTag("folder_tab_delivered")
            )
            Tab(
                selected = selectedFolder == CompanyFolder.CASES,
                onClick = { selectedFolder = CompanyFolder.CASES },
                text = {
                    Text(
                        "الحالات (${PhoneNumberNormalizer.formatDigitsForDisplay(casesList.size.toString(), numeralStyle)})",
                        fontWeight = FontWeight.Bold
                    )
                },
                icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                modifier = Modifier.testTag("folder_tab_cases")
            )
        }

        val totalOrig = visibleList.sumOf { it.shipment.originalPrice }
        val totalDeliv = visibleList.sumOf { it.shipment.deliveredPrice }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الأصلي: ${CurrencyFormatter.formatEgp(totalOrig, numeralStyle)}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "المسلم: ${CurrencyFormatter.formatEgp(totalDeliv, numeralStyle)}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = TealDelivered
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (visibleList.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Folder,
                        title = "مجلد ${selectedFolder.arabicLabel} فارغ",
                        subtitle = if (selectedFolder == CompanyFolder.DELIVERED) {
                            "الشحنات الجديدة تبدأ هنا تلقائيًا بحالة (تم)."
                        } else {
                            "أي شحنة تتم معالجتها في المخزن تنتقل هنا تلقائيًا."
                        }
                    )
                }
            } else {
                items(visibleList, key = { it.shipment.id }) { item ->
                    ShipmentSummaryCard(
                        item = item,
                        numeralStyle = numeralStyle,
                        onClick = { onOpenShipment(item.shipment.id) }
                    )
                }
            }
        }
    }
}
