package com.example.ui

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.app.AppContainer
import com.example.backup.BackupWorker
import com.example.backup.DriveBackupFile
import com.example.database.BackupRecordEntity
import com.example.database.CompanyEntity
import com.example.database.CompanyShipmentCounts
import com.example.database.DailyArchiveEntity
import com.example.database.DashboardSummary
import com.example.database.ShipmentWithCompany
import com.example.ocr.OcrDiagnostics
import com.example.ocr.OcrEngineMode
import com.example.settings.AppSettingsState
import com.example.shipments.NumeralStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeviceDiagnosticsInfo(
    val manufacturerModel: String,
    val androidVersion: String,
    val sdkInt: Int,
    val supportedAbis: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val appVersion: String
)

sealed interface EndOfDayUiState {
    data object Idle : EndOfDayUiState
    data object FirstConfirm : EndOfDayUiState
    data object SecondConfirm : EndOfDayUiState
    data object Processing : EndOfDayUiState
    data class Completed(val message: String, val success: Boolean) : EndOfDayUiState
}

class MainViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val repo = container.shipmentRepository
    private val backupManager = container.backupManager
    private val prefs = container.preferences

    val dashboardSummary: StateFlow<DashboardSummary> = repo.observeDashboardSummary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    val companyCounts: StateFlow<List<CompanyShipmentCounts>> = repo.observeCompanyCounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCompanies: StateFlow<List<CompanyEntity>> = repo.observeAllCompanies()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectableCompanies: StateFlow<List<CompanyEntity>> = repo.observeSelectableCompanies()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeShipments: StateFlow<List<ShipmentWithCompany>> = repo.observeActiveShipments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyArchives: StateFlow<List<DailyArchiveEntity>> = repo.observeDailyArchives()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val backupRecords: StateFlow<List<BackupRecordEntity>> = backupManager.observeBackupRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettingsState> = prefs.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsState())

    private val _endOfDayState = MutableStateFlow<EndOfDayUiState>(EndOfDayUiState.Idle)
    val endOfDayState: StateFlow<EndOfDayUiState> = _endOfDayState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _ocrDiagnostics = MutableStateFlow<OcrDiagnostics?>(null)
    val ocrDiagnostics: StateFlow<OcrDiagnostics?> = _ocrDiagnostics.asStateFlow()

    private val _driveBackups = MutableStateFlow<List<DriveBackupFile>>(emptyList())
    val driveBackups: StateFlow<List<DriveBackupFile>> = _driveBackups.asStateFlow()

    private val _driveAccessToken = MutableStateFlow<String?>(null)
    val driveAccessToken: StateFlow<String?> = _driveAccessToken.asStateFlow()

    init {
        refreshOcrDiagnostics()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun refreshOcrDiagnostics() {
        viewModelScope.launch {
            _ocrDiagnostics.value = container.ocrEngine.getDiagnostics()
        }
    }

    fun getDeviceInfo(): DeviceDiagnosticsInfo {
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val availMb = memInfo.availMem / (1024L * 1024L)
        return DeviceDiagnosticsInfo(
            manufacturerModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = Build.VERSION.RELEASE ?: "غير معروف",
            sdkInt = Build.VERSION.SDK_INT,
            supportedAbis = Build.SUPPORTED_ABIS.joinToString(", "),
            totalRamMb = totalMb,
            availableRamMb = availMb,
            appVersion = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
        )
    }

    // Company CRUD
    fun addCompany(name: String, code: String, phone: String, notes: String) {
        viewModelScope.launch {
            try {
                repo.addCompany(name, code, phone, notes)
                _statusMessage.value = "تمت إضافة شركة $name بنجاح"
            } catch (e: Exception) {
                _statusMessage.value = e.localizedMessage ?: "تعذر إضافة الشركة"
            }
        }
    }

    fun updateCompany(company: CompanyEntity) {
        viewModelScope.launch {
            repo.updateCompany(company)
            _statusMessage.value = "تم تحديث بيانات ${company.name}"
        }
    }

    fun toggleCompanyActive(companyId: Long, active: Boolean) {
        viewModelScope.launch {
            repo.setCompanyActive(companyId, active)
            _statusMessage.value = if (active) "تم تفعيل الشركة" else "تم تعطيل الشركة مع الاحتفاظ بجميع سجلاتها"
        }
    }

    fun toggleCompanyArchived(companyId: Long, archived: Boolean) {
        viewModelScope.launch {
            repo.setCompanyArchived(companyId, archived)
            _statusMessage.value = if (archived) "تمت أرشفة الشركة" else "تم إلغاء أرشفة الشركة"
        }
    }

    fun observeCompanyShipments(companyId: Long) =
        repo.observeActiveShipmentsByCompany(companyId)

    // End of Day workflow (Two-step confirmation + verified backup + non-destructive archive)
    fun startEndOfDayFlow() {
        _endOfDayState.value = EndOfDayUiState.FirstConfirm
    }

    fun advanceToSecondEndOfDayConfirm() {
        _endOfDayState.value = EndOfDayUiState.SecondConfirm
    }

    fun cancelEndOfDayFlow() {
        _endOfDayState.value = EndOfDayUiState.Idle
    }

    fun executeEndOfDay() {
        viewModelScope.launch {
            _endOfDayState.value = EndOfDayUiState.Processing
            val backupResult = backupManager.createLocalBackup("END_OF_DAY")
            if (!backupResult.success) {
                _endOfDayState.value = EndOfDayUiState.Completed(
                    message = "تم إلغاء إنهاء اليوم لأن النسخ الاحتياطي فشل: ${backupResult.message}",
                    success = false
                )
                return@launch
            }

            // Optional upload to Google Drive if user already connected OAuth in this session
            val token = _driveAccessToken.value
            if (!token.isNullOrBlank()) {
                backupManager.uploadBackupToGoogleDrive(token)
            }

            val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val summaryJson = """{"backupFile":"${backupResult.fileName}","shipments":${backupResult.shipmentCount}}"""
            repo.archiveDayAfterBackup(
                archiveDate = dateKey,
                backupFilePath = backupResult.filePath,
                summaryJson = summaryJson
            )
            _endOfDayState.value = EndOfDayUiState.Completed(
                message = "تم حفظ النسخة الاحتياطية وأرشفة اليوم ($dateKey) وبدء يوم عمل جديد بنجاح.",
                success = true
            )
        }
    }

    // Backup & Restore
    fun createManualLocalBackup() {
        viewModelScope.launch {
            val res = backupManager.createLocalBackup("MANUAL_LOCAL")
            _statusMessage.value = res.message
        }
    }

    fun exportBackupToUri(uri: android.net.Uri) {
        viewModelScope.launch {
            val res = backupManager.exportLocalBackupToUri(uri)
            _statusMessage.value = res.message
        }
    }

    fun restoreFromLocalBackup(filePath: String) {
        viewModelScope.launch {
            val res = backupManager.restoreFromLocalFile(filePath)
            _statusMessage.value = res.message
        }
    }

    fun restoreFromUri(uri: android.net.Uri) {
        viewModelScope.launch {
            val res = backupManager.restoreFromUri(uri)
            _statusMessage.value = res.message
        }
    }

    fun onGoogleDriveTokenObtained(token: String, accountLabel: String) {
        _driveAccessToken.value = token
        viewModelScope.launch {
            prefs.setDriveAccountLabel(accountLabel)
            refreshGoogleDriveBackups()
        }
    }

    fun uploadBackupToGoogleDrive() {
        val token = _driveAccessToken.value
        if (token.isNullOrBlank()) {
            _statusMessage.value = "يرجى ربط حساب Google Drive أولًا"
            return
        }
        viewModelScope.launch {
            val res = backupManager.uploadBackupToGoogleDrive(token)
            _statusMessage.value = res.message
            refreshGoogleDriveBackups()
        }
    }

    fun refreshGoogleDriveBackups() {
        val token = _driveAccessToken.value ?: return
        viewModelScope.launch {
            backupManager.listGoogleDriveBackups(token)
                .onSuccess { _driveBackups.value = it }
                .onFailure { _statusMessage.value = "تعذر جلب نسخ Google Drive: ${it.localizedMessage ?: ""}" }
        }
    }

    fun restoreFromGoogleDrive(file: DriveBackupFile) {
        val token = _driveAccessToken.value ?: return
        viewModelScope.launch {
            val res = backupManager.downloadAndRestoreFromDrive(token, file.id, file.name)
            _statusMessage.value = res.message
        }
    }

    // Settings mutations
    fun setNumeralStyle(style: NumeralStyle) {
        viewModelScope.launch { prefs.setNumeralStyle(style) }
    }

    fun setOcrMode(mode: OcrEngineMode) {
        viewModelScope.launch { prefs.setOcrMode(mode) }
    }

    fun setCameraLowResolution(enabled: Boolean) {
        viewModelScope.launch { prefs.setCameraLowResolution(enabled) }
    }

    fun setCameraFrameIntervalMs(ms: Long) {
        viewModelScope.launch { prefs.setCameraFrameIntervalMs(ms) }
    }

    fun setAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setAutoBackupEnabled(enabled)
            if (enabled) BackupWorker.schedulePeriodicBackup(appContext)
            else BackupWorker.cancelPeriodicBackup(appContext)
        }
    }

    fun setReleaseOcrWhenIdle(enabled: Boolean) {
        viewModelScope.launch { prefs.setReleaseOcrWhenIdle(enabled) }
    }

    companion object {
        fun factory(appContext: Context, container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(appContext.applicationContext, container) as T
                }
            }
    }
}
