package com.example.bulkpaste

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.database.CompanyEntity
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.ShipmentSource
import com.example.ui.ImportTab
import com.example.ui.ImportUiState
import com.example.ui.components.CompanySelectorRow
import com.example.ui.components.DraftImportRowCard
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealDelivered
import java.io.File

@Composable
fun ImportShipmentsScreen(
    uiState: ImportUiState,
    companies: List<CompanyEntity>,
    numeralStyle: NumeralStyle,
    releaseOcrWhenIdle: Boolean,
    onSelectTab: (ImportTab) -> Unit,
    onSelectCompany: (Long) -> Unit,
    onAddCompanyClick: () -> Unit,
    onBulkTextChange: (String) -> Unit,
    onAnalyzeBulk: () -> Unit,
    onTogglePreview: (Boolean) -> Unit,
    onImportExcelUri: (Uri, String) -> Unit,
    onImportImageUri: (Uri, Boolean) -> Unit,
    onEditDraftRow: (BulkPasteDraftRow) -> Unit,
    onDeleteDraftRow: (Long) -> Unit,
    onCancelBatch: () -> Unit,
    onSaveBatch: (ShipmentSource) -> Unit,
    onAddSingleShipment: (name: String, phone: String, address: String, price: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val excelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val fileName = resolveFileName(context, uri) ?: "sheet.xlsx"
            onImportExcelUri(uri, fileName)
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onImportImageUri(uri, releaseOcrWhenIdle)
        }
    }

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            onImportImageUri(uri, releaseOcrWhenIdle)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = uiState.selectedTab.ordinal,
            edgePadding = 12.dp
        ) {
            ImportTab.entries.forEach { tab ->
                Tab(
                    selected = uiState.selectedTab == tab,
                    onClick = { onSelectTab(tab) },
                    text = { Text(tab.arabicTitle, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("import_tab_${tab.name}")
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                CompanySelectorRow(
                    companies = companies,
                    selectedCompanyId = uiState.selectedCompanyId,
                    onSelect = onSelectCompany,
                    onAddCompanyClick = onAddCompanyClick
                )
            }

            if (uiState.statusBanner != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TealContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = uiState.statusBanner,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TealDelivered,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            when (uiState.selectedTab) {
                ImportTab.BULK_PASTE -> {
                    item {
                        BulkPasteInputSection(
                            rawText = uiState.rawBulkText,
                            isBusy = uiState.isBusy,
                            showPreviewOnly = uiState.showPreviewOnly,
                            onRawTextChange = onBulkTextChange,
                            onPasteFromClipboard = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clipText = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                                if (clipText.isNotBlank()) {
                                    onBulkTextChange(clipText)
                                }
                            },
                            onAnalyze = onAnalyzeBulk,
                            onTogglePreview = onTogglePreview
                        )
                    }
                }

                ImportTab.IMAGE_OCR -> {
                    item {
                        ImageImportSection(
                            isBusy = uiState.isBusy,
                            ocrEngineInfo = uiState.ocrEngineInfo,
                            rawOcrTextPreview = uiState.rawOcrTextPreview,
                            onPickPhoto = {
                                photoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onCapturePhoto = {
                                val tmpFile = File(context.cacheDir, "ocr_sheet_${System.currentTimeMillis()}.jpg")
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    tmpFile
                                )
                                pendingCameraUri = uri
                                cameraCaptureLauncher.launch(uri)
                            }
                        )
                    }
                }

                ImportTab.EXCEL -> {
                    item {
                        ExcelImportSection(
                            isBusy = uiState.isBusy,
                            headersInfo = uiState.excelHeadersInfo,
                            errors = uiState.excelErrors,
                            onPickExcel = {
                                excelPicker.launch(
                                    arrayOf(
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/octet-stream",
                                        "*/*"
                                    )
                                )
                            }
                        )
                    }
                }

                ImportTab.MANUAL_SINGLE -> {
                    item {
                        ManualSingleShipmentSection(onAddSingle = onAddSingleShipment)
                    }
                }
            }

            // Shared Review & Save Section for Bulk Paste / Image OCR / Excel
            if (uiState.selectedTab != ImportTab.MANUAL_SINGLE && uiState.draftRows.isNotEmpty()) {
                item {
                    val totalDisp = PhoneNumberNormalizer.formatDigitsForDisplay(uiState.totalDetected.toString(), numeralStyle)
                    val validDisp = PhoneNumberNormalizer.formatDigitsForDisplay(uiState.validCount.toString(), numeralStyle)
                    val revDisp = PhoneNumberNormalizer.formatDigitsForDisplay(uiState.needsReviewCount.toString(), numeralStyle)

                    Card(
                        colors = CardDefaults.cardColors(containerColor = AmberContainer.copy(alpha = 0.55f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "معاينة الدفعة: إجمالي $totalDisp  •  سليم: $validDisp  •  يحتاج مراجعة: $revDisp",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val source = when (uiState.selectedTab) {
                                    ImportTab.BULK_PASTE -> ShipmentSource.BULK_PASTE
                                    ImportTab.IMAGE_OCR -> ShipmentSource.IMAGE_OCR
                                    ImportTab.EXCEL -> ShipmentSource.EXCEL
                                    ImportTab.MANUAL_SINGLE -> ShipmentSource.MANUAL
                                }
                                Button(
                                    onClick = { onSaveBatch(source) },
                                    enabled = !uiState.isBusy,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("save_all_orders_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = TealDelivered)
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("حفظ جميع الأوردرات")
                                }
                                OutlinedButton(
                                    onClick = onCancelBatch,
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("cancel_batch_button")
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("إلغاء الدفعة")
                                }
                            }
                        }
                    }
                }

                items(uiState.draftRows, key = { it.rowId }) { row ->
                    DraftImportRowCard(
                        row = row,
                        numeralStyle = numeralStyle,
                        onEdit = onEditDraftRow,
                        onDelete = onDeleteDraftRow
                    )
                }
            }
        }
    }
}

@Composable
private fun BulkPasteInputSection(
    rawText: String,
    isBusy: Boolean,
    showPreviewOnly: Boolean,
    onRawTextChange: (String) -> Unit,
    onPasteFromClipboard: () -> Unit,
    onAnalyze: () -> Unit,
    onTogglePreview: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "إضافة أوردرات بالنسخ واللصق",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "كل أوردر في سطر مستقل والأعمدة مفصولة بعلامة Tab بالترتيب: اسم العميل ⇥ رقم الهاتف ⇥ العنوان ⇥ السعر",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = rawText,
            onValueChange = onRawTextChange,
            label = { Text("الصق قائمة الأوردرات هنا (يدعم عشرات ومئات الأوردرات)") },
            modifier = Modifier
                .fillMaxWidth()
                .height(if (showPreviewOnly) 120.dp else 210.dp)
                .testTag("bulk_paste_input"),
            maxLines = 20
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(
                onClick = onPasteFromClipboard,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("paste_orders_button")
            ) {
                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("لصق الأوردرات")
            }
            Button(
                onClick = onAnalyze,
                enabled = !isBusy,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("analyze_orders_button"),
                colors = ButtonDefaults.buttonColors(containerColor = AmberAccent)
            ) {
                if (isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("تحليل البيانات")
                }
            }
        }
        OutlinedButton(
            onClick = { onTogglePreview(!showPreviewOnly) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("preview_orders_button")
        ) {
            Icon(Icons.Default.Preview, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(if (showPreviewOnly) "توسيع مربع اللصق" else "معاينة الأوردرات")
        }
    }
}

@Composable
private fun ImageImportSection(
    isBusy: Boolean,
    ocrEngineInfo: String,
    rawOcrTextPreview: String,
    onPickPhoto: () -> Unit,
    onCapturePhoto: () -> Unit
) {
    var showRawText by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "استخراج البيانات من الصور (OCR محلي دون إنترنت)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "اختر شركة الشحن ثم صوّر كشف الشحنات أو اختر صورة من الهاتف لاستخراج الاسم والهاتف والعنوان والسعر تلقائيًا.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCapturePhoto,
                enabled = !isBusy,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("image_import_camera_button")
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("تصوير كشف")
            }
            FilledTonalButton(
                onClick = onPickPhoto,
                enabled = !isBusy,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("image_import_gallery_button")
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("اختيار صورة")
            }
        }
        if (isBusy) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp))
                Text("جاري تحليل الصورة محليًا باستخدام Tesseract عربي/إنجليزي...")
            }
        }
        if (ocrEngineInfo.isNotBlank()) {
            Text(
                text = "محرك الاستخراج: $ocrEngineInfo",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (rawOcrTextPreview.isNotBlank()) {
            OutlinedButton(onClick = { showRawText = !showRawText }) {
                Text(if (showRawText) "إخفاء النص الخام المستخرج" else "عرض النص الخام المستخرج")
            }
            if (showRawText) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(
                        text = rawOcrTextPreview,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ExcelImportSection(
    isBusy: Boolean,
    headersInfo: List<String>,
    errors: List<String>,
    onPickExcel: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "استيراد ملفات Excel (.xlsx)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "يدعم اختلاف ترتيب الأعمدة، ويقرأ عناوين الأعمدة بالعربية والإنجليزية مع الحفاظ على الصفر الأول في أرقام الهواتف.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = onPickExcel,
            enabled = !isBusy,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("pick_excel_button")
        ) {
            if (isBusy) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("جاري قراءة ملف Excel...")
            } else {
                Icon(Icons.Default.Description, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("اختيار ملف Excel (XLSX)")
            }
        }
        if (headersInfo.isNotEmpty()) {
            Text(
                text = "الأعمدة المكتشفة: ${headersInfo.joinToString(" | ")}",
                style = MaterialTheme.typography.labelSmall,
                color = TealDelivered
            )
        }
        errors.forEach { err ->
            Text(text = err, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ManualSingleShipmentSection(
    onAddSingle: (name: String, phone: String, address: String, price: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("إضافة شحنة واحدة يدويًا", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم العميل *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("رقم الهاتف *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("السعر (ج.م) *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                onAddSingle(name, phone, address, price)
                if (name.isNotBlank() && phone.isNotBlank() && price.isNotBlank()) {
                    name = ""; phone = ""; address = ""; price = ""
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("حفظ الشحنة بحالة (تم)")
        }
    }
}

private fun resolveFileName(context: Context, uri: Uri): String? {
    return context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
    }
}
