package com.example.imageimport

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.bulkpaste.BulkPasteDraftRow
import com.example.ocr.OcrEngine
import com.example.shipments.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ImageImportResult(
    val rawOcrText: String,
    val engineUsed: String,
    val inferenceTimeMs: Long,
    val rows: List<BulkPasteDraftRow>
) {
    val totalDetected: Int get() = rows.size
    val validCount: Int get() = rows.count { !it.needsReview }
    val needsReviewCount: Int get() = rows.count { it.needsReview }
}

/**
 * Extracts shipment rows from photographed or gallery manifest sheets using local OcrEngine.
 * Recognizes differing column orders and Arabic/English price & phone aliases without inventing data.
 */
object ImageImporter {

    suspend fun importFromUri(
        context: Context,
        uri: Uri,
        ocrEngine: OcrEngine
    ): ImageImportResult = withContext(Dispatchers.IO) {
        val bitmap = decodeDownsampledBitmap(context, uri, maxSizePx = 1600)
            ?: return@withContext ImageImportResult("", "غير متاح", 0L, emptyList())
        try {
            importFromBitmap(bitmap, ocrEngine)
        } finally {
            bitmap.recycle()
        }
    }

    suspend fun importFromBitmap(
        bitmap: Bitmap,
        ocrEngine: OcrEngine
    ): ImageImportResult = withContext(Dispatchers.Default) {
        val ocrResult = ocrEngine.recognizeFullDocument(bitmap)
        val parsedRows = parseOcrLinesToDrafts(ocrResult.rawText)
        ImageImportResult(
            rawOcrText = ocrResult.rawText,
            engineUsed = ocrResult.engineUsed,
            inferenceTimeMs = ocrResult.inferenceTimeMs,
            rows = parsedRows
        )
    }

    fun parseOcrLinesToDrafts(rawText: String): List<BulkPasteDraftRow> {
        val lines = rawText
            .replace("\r\n", "\n")
            .split("\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (lines.isEmpty()) return emptyList()

        // Detect header positions if present in OCR text
        var headerIndex = -1
        var phoneColHint = -1
        var priceColHint = -1
        var nameColHint = -1
        var addressColHint = -1

        for (i in 0 until minOf(4, lines.size)) {
            val tokens = splitRowTokens(lines[i])
            if (tokens.size >= 2) {
                var hits = 0
                tokens.forEachIndexed { idx, token ->
                    val t = token.lowercase()
                    when {
                        t.contains("هاتف") || t.contains("موبايل") || t.contains("تليفون") || t.contains("phone") -> {
                            phoneColHint = idx; hits++
                        }
                        t.contains("قيمة الطلب") || t.contains("إجمالي الشحنة") || t.contains("المبلغ المطلوب تحصيله") ||
                            t.contains("سعر") || t.contains("مبلغ") || t.contains("price") || t.contains("cod") -> {
                            priceColHint = idx; hits++
                        }
                        t.contains("عميل") || t.contains("اسم") || t.contains("name") -> {
                            nameColHint = idx; hits++
                        }
                        t.contains("عنوان") || t.contains("منطقة") || t.contains("address") -> {
                            addressColHint = idx; hits++
                        }
                    }
                }
                if (hits >= 2) {
                    headerIndex = i
                    break
                }
            }
        }

        val drafts = mutableListOf<BulkPasteDraftRow>()
        var rowId = 1L
        val start = if (headerIndex >= 0) headerIndex + 1 else 0

        for (i in start until lines.size) {
            val line = lines[i]
            // Skip pure noise lines with no Arabic/Latin letters and no digits
            if (!line.any { it.isLetterOrDigit() }) continue

            val tokens = splitRowTokens(line)
            val phoneCandidates = PhoneNumberNormalizer.extractPhoneCandidatesFromOcr(line)
            val phone = when {
                phoneColHint in tokens.indices && PhoneNumberNormalizer.isLikelyPhoneNumber(tokens[phoneColHint]) ->
                    PhoneNumberNormalizer.preserveRawPhone(tokens[phoneColHint])
                phoneCandidates.isNotEmpty() -> phoneCandidates.first()
                else -> ""
            }

            // Remove identified phone token before searching for price to avoid mixing phone and price!
            val lineWithoutPhone = if (phone.isNotBlank()) {
                line.replace(phone, " ")
            } else {
                line
            }

            val priceRaw: String
            val parsedPrice: Double?
            if (priceColHint in tokens.indices) {
                val candidate = tokens[priceColHint]
                val p = PhoneNumberNormalizer.parsePrice(candidate)
                if (p != null && !PhoneNumberNormalizer.isLikelyPhoneNumber(candidate)) {
                    priceRaw = candidate
                    parsedPrice = p
                } else {
                    val extracted = extractPriceFromLine(lineWithoutPhone)
                    priceRaw = extracted?.first.orEmpty()
                    parsedPrice = extracted?.second
                }
            } else {
                val extracted = extractPriceFromLine(lineWithoutPhone)
                priceRaw = extracted?.first.orEmpty()
                parsedPrice = extracted?.second
            }

            val remainingTokens = tokens.filter { token ->
                val normToken = PhoneNumberNormalizer.normalize(token)
                val normPhone = PhoneNumberNormalizer.normalize(phone)
                val isPhoneToken = normPhone.isNotBlank() && normToken == normPhone
                val isPriceToken = priceRaw.isNotBlank() && token.trim() == priceRaw.trim()
                !isPhoneToken && !isPriceToken
            }

            val customerName = when {
                nameColHint in tokens.indices && tokens[nameColHint] in remainingTokens -> tokens[nameColHint]
                remainingTokens.isNotEmpty() -> remainingTokens.first()
                else -> ""
            }

            val address = when {
                addressColHint in tokens.indices && tokens[addressColHint] in remainingTokens -> tokens[addressColHint]
                remainingTokens.size >= 2 -> remainingTokens.drop(1).joinToString(" - ")
                else -> ""
            }

            val issues = mutableListOf<String>()
            if (customerName.isBlank()) issues.add("الاسم غير واضح")
            if (phone.isBlank()) issues.add("رقم الهاتف غير واضح")
            if (address.isBlank()) issues.add("العنوان غير واضح")
            if (parsedPrice == null) issues.add("السعر غير واضح")

            // Only include rows that yielded at least one meaningful shipping field
            if (customerName.isNotBlank() || phone.isNotBlank() || parsedPrice != null) {
                drafts.add(
                    BulkPasteDraftRow(
                        rowId = rowId++,
                        lineNumber = i + 1,
                        customerName = customerName.trim(),
                        rawPhone = phone,
                        address = address.trim(),
                        rawPrice = priceRaw,
                        parsedPrice = parsedPrice,
                        issues = issues
                    )
                )
            }
        }
        return drafts
    }

    private fun splitRowTokens(line: String): List<String> {
        return when {
            line.contains("\t") -> line.split("\t")
            line.contains("|") -> line.split("|")
            line.contains("،") -> line.split("،")
            else -> line.split(Regex("\\s{2,}"))
        }.map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun extractPriceFromLine(textWithoutPhone: String): Pair<String, Double>? {
        val western = PhoneNumberNormalizer.toWesternDigits(textWithoutPhone)
        val matches = Regex("([0-9]{2,6}(?:\\.[0-9]{1,2})?)").findAll(western).toList()
        val candidate = matches.lastOrNull()?.value ?: return null
        val parsed = candidate.toDoubleOrNull() ?: return null
        return if (parsed in 1.0..200_000.0) candidate to parsed else null
    }

    private fun decodeDownsampledBitmap(context: Context, uri: Uri, maxSizePx: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        var sampleSize = 1
        while (maxSide / sampleSize > maxSizePx) {
            sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
    }
}
