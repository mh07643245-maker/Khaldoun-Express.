package com.example.backup

import android.content.Context
import android.net.Uri
import com.example.database.BackupRecordEntity
import com.example.database.CompanyEntity
import com.example.database.DailyArchiveEntity
import com.example.database.EditHistoryEntity
import com.example.database.LocalDatabase
import com.example.database.ShipmentEntity
import com.example.database.ShipmentNoteEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Serializable
data class BackupCompanyDto(
    val id: Long,
    val name: String,
    val code: String,
    val contactPhone: String,
    val notes: String,
    val isActive: Boolean,
    val isArchived: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
data class BackupShipmentDto(
    val id: Long,
    val companyId: Long,
    val customerName: String,
    val rawPhone: String,
    val normalizedPhone: String,
    val last5Digits: String,
    val address: String,
    val originalPrice: Double,
    val deliveredPrice: Double,
    val folder: String,
    val statusCode: String,
    val notes: String,
    val sourceType: String,
    val needsReview: Boolean,
    val isArchived: Boolean,
    val archiveDate: String?,
    val batchId: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
data class BackupNoteDto(
    val id: Long,
    val shipmentId: Long,
    val noteText: String,
    val createdAt: Long
)

@Serializable
data class BackupEditHistoryDto(
    val id: Long,
    val shipmentId: Long,
    val fieldName: String,
    val oldValue: String,
    val newValue: String,
    val actionNote: String,
    val editedAt: Long
)

@Serializable
data class BackupDailyArchiveDto(
    val id: Long,
    val archiveDate: String,
    val totalShipments: Int,
    val deliveredFolderCount: Int,
    val casesFolderCount: Int,
    val totalOriginalPrice: Double,
    val totalDeliveredPrice: Double,
    val backupFilePath: String,
    val summaryJson: String,
    val createdAt: Long
)

@Serializable
data class KhaldounBackupSnapshot(
    val schemaVersion: Int = 1,
    val appName: String = "Khaldoun Express",
    val createdAt: Long,
    val createdDate: String,
    val companies: List<BackupCompanyDto>,
    val shipments: List<BackupShipmentDto>,
    val notes: List<BackupNoteDto>,
    val editHistory: List<BackupEditHistoryDto>,
    val dailyArchives: List<BackupDailyArchiveDto>
)

data class DriveBackupFile(
    val id: String,
    val name: String,
    val modifiedTime: String
)

data class BackupResult(
    val success: Boolean,
    val filePath: String,
    val fileName: String,
    val shipmentCount: Int,
    val companyCount: Int,
    val driveFileId: String? = null,
    val message: String
)

class BackupManager(
    private val context: Context,
    private val database: LocalDatabase
) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun observeBackupRecords(): Flow<List<BackupRecordEntity>> =
        database.metadataDao().observeBackupRecords()

    suspend fun createSnapshot(): KhaldounBackupSnapshot = withContext(Dispatchers.IO) {
        val companies = database.companyDao().getAllCompaniesOnce()
        val shipments = database.shipmentDao().getAllShipmentsOnce()
        val notes = database.metadataDao().getAllNotesOnce()
        val history = database.metadataDao().getAllEditHistoryOnce()
        val archives = database.metadataDao().getAllDailyArchivesOnce()
        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(now))

        KhaldounBackupSnapshot(
            createdAt = now,
            createdDate = dateStr,
            companies = companies.map {
                BackupCompanyDto(
                    it.id, it.name, it.code, it.contactPhone, it.notes,
                    it.isActive, it.isArchived, it.createdAt, it.updatedAt
                )
            },
            shipments = shipments.map {
                BackupShipmentDto(
                    it.id, it.companyId, it.customerName, it.rawPhone, it.normalizedPhone,
                    it.last5Digits, it.address, it.originalPrice, it.deliveredPrice,
                    it.folder, it.statusCode, it.notes, it.sourceType, it.needsReview,
                    it.isArchived, it.archiveDate, it.batchId, it.createdAt, it.updatedAt
                )
            },
            notes = notes.map { BackupNoteDto(it.id, it.shipmentId, it.noteText, it.createdAt) },
            editHistory = history.map {
                BackupEditHistoryDto(it.id, it.shipmentId, it.fieldName, it.oldValue, it.newValue, it.actionNote, it.editedAt)
            },
            dailyArchives = archives.map {
                BackupDailyArchiveDto(
                    it.id, it.archiveDate, it.totalShipments, it.deliveredFolderCount,
                    it.casesFolderCount, it.totalOriginalPrice, it.totalDeliveredPrice,
                    it.backupFilePath, it.summaryJson, it.createdAt
                )
            }
        )
    }

    suspend fun createLocalBackup(backupType: String = "MANUAL_LOCAL"): BackupResult =
        withContext(Dispatchers.IO) {
            try {
                val snapshot = createSnapshot()
                val payload = json.encodeToString(snapshot)
                val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
                val fileName = "khaldoun_backup_${snapshot.createdDate}.json"
                val file = File(backupDir, fileName)
                file.writeText(payload, Charsets.UTF_8)

                // Verify file exists and is non-empty
                if (!file.exists() || file.length() == 0L) {
                    return@withContext BackupResult(
                        success = false,
                        filePath = "",
                        fileName = fileName,
                        shipmentCount = snapshot.shipments.size,
                        companyCount = snapshot.companies.size,
                        message = "فشل التحقق من ملف النسخة الاحتياطية"
                    )
                }

                database.metadataDao().insertBackupRecord(
                    BackupRecordEntity(
                        backupType = backupType,
                        fileName = fileName,
                        localPath = file.absolutePath,
                        shipmentCount = snapshot.shipments.size,
                        companyCount = snapshot.companies.size,
                        status = "SUCCESS",
                        message = "تم حفظ النسخة الاحتياطية محليًا بنجاح"
                    )
                )

                BackupResult(
                    success = true,
                    filePath = file.absolutePath,
                    fileName = fileName,
                    shipmentCount = snapshot.shipments.size,
                    companyCount = snapshot.companies.size,
                    message = "تم حفظ النسخة الاحتياطية (${snapshot.shipments.size} شحنة)"
                )
            } catch (e: Exception) {
                BackupResult(
                    success = false,
                    filePath = "",
                    fileName = "",
                    shipmentCount = 0,
                    companyCount = 0,
                    message = "فشل إنشاء النسخة الاحتياطية: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                )
            }
        }

    suspend fun exportLocalBackupToUri(uri: Uri): BackupResult = withContext(Dispatchers.IO) {
        val local = createLocalBackup("SAF_EXPORT")
        if (!local.success) return@withContext local
        try {
            val bytes = File(local.filePath).readBytes()
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: return@withContext local.copy(success = false, message = "تعذر فتح مسار الحفظ المحدد")
            local.copy(message = "تم تصدير النسخة الاحتياطية إلى الملف بنجاح")
        } catch (e: Exception) {
            local.copy(success = false, message = "خطأ أثناء التصدير: ${e.localizedMessage ?: ""}")
        }
    }

    suspend fun restoreFromLocalFile(filePath: String): BackupResult = withContext(Dispatchers.IO) {
        val file = File(filePath)
        if (!file.exists()) {
            return@withContext BackupResult(false, filePath, file.name, 0, 0, message = "ملف النسخة الاحتياطية غير موجود")
        }
        restoreFromJsonString(file.readText(Charsets.UTF_8), file.name, filePath)
    }

    suspend fun restoreFromUri(uri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val content = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                it.readText()
            } ?: return@withContext BackupResult(false, "", "", 0, 0, message = "تعذر قراءة الملف المحدد")
            restoreFromJsonString(content, uri.lastPathSegment ?: "backup.json", "")
        } catch (e: Exception) {
            BackupResult(false, "", "", 0, 0, message = "فشل استعادة الملف: ${e.localizedMessage ?: ""}")
        }
    }

    suspend fun restoreFromJsonString(
        rawJson: String,
        sourceName: String = "snapshot.json",
        sourcePath: String = ""
    ): BackupResult = withContext(Dispatchers.IO) {
        try {
            val snapshot = json.decodeFromString<KhaldounBackupSnapshot>(rawJson)
            database.restoreDao().replaceDatabaseSnapshot(
                companies = snapshot.companies.map {
                    CompanyEntity(
                        it.id, it.name, it.code, it.contactPhone, it.notes,
                        it.isActive, it.isArchived, it.createdAt, it.updatedAt
                    )
                },
                shipments = snapshot.shipments.map {
                    ShipmentEntity(
                        it.id, it.companyId, it.customerName, it.rawPhone, it.normalizedPhone,
                        it.last5Digits, it.address, it.originalPrice, it.deliveredPrice,
                        it.folder, it.statusCode, it.notes, it.sourceType, it.needsReview,
                        it.isArchived, it.archiveDate, it.batchId, it.createdAt, it.updatedAt
                    )
                },
                notes = snapshot.notes.map {
                    ShipmentNoteEntity(it.id, it.shipmentId, it.noteText, it.createdAt)
                },
                history = snapshot.editHistory.map {
                    EditHistoryEntity(it.id, it.shipmentId, it.fieldName, it.oldValue, it.newValue, it.actionNote, it.editedAt)
                },
                archives = snapshot.dailyArchives.map {
                    DailyArchiveEntity(
                        it.id, it.archiveDate, it.totalShipments, it.deliveredFolderCount,
                        it.casesFolderCount, it.totalOriginalPrice, it.totalDeliveredPrice,
                        it.backupFilePath, it.summaryJson, it.createdAt
                    )
                }
            )
            BackupResult(
                success = true,
                filePath = sourcePath,
                fileName = sourceName,
                shipmentCount = snapshot.shipments.size,
                companyCount = snapshot.companies.size,
                message = "تمت استعادة ${snapshot.companies.size} شركة و ${snapshot.shipments.size} شحنة بنجاح"
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                filePath = sourcePath,
                fileName = sourceName,
                shipmentCount = 0,
                companyCount = 0,
                message = "تنسيق النسخة الاحتياطية غير صالح: ${e.localizedMessage ?: ""}"
            )
        }
    }

    /**
     * Uploads a local backup JSON directly to Google Drive API v3 (drive.file scope)
     * using the user's OAuth 2.0 access token.
     */
    suspend fun uploadBackupToGoogleDrive(accessToken: String): BackupResult = withContext(Dispatchers.IO) {
        val localResult = createLocalBackup("GOOGLE_DRIVE")
        if (!localResult.success) return@withContext localResult

        try {
            val file = File(localResult.filePath)
            val fileBytes = file.readBytes()
            val metadataJson = JSONObject().apply {
                put("name", localResult.fileName)
                put("mimeType", "application/json")
            }.toString()

            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addPart(
                    metadataJson.toRequestBody("application/json; charset=utf-8".toMediaType())
                )
                .addPart(
                    fileBytes.toRequestBody("application/json".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .addHeader("Authorization", "Bearer $accessToken")
                .post(body)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val respBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext localResult.copy(
                        success = false,
                        message = "تم الحفظ محليًا، ولكن فشل الرفع إلى Google Drive (HTTP ${response.code}). تأكد من إعداد OAuth وصلاحية drive.file."
                    )
                }
                val driveId = JSONObject(respBody).optString("id")
                database.metadataDao().insertBackupRecord(
                    BackupRecordEntity(
                        backupType = "GOOGLE_DRIVE",
                        fileName = localResult.fileName,
                        localPath = localResult.filePath,
                        driveFileId = driveId,
                        shipmentCount = localResult.shipmentCount,
                        companyCount = localResult.companyCount,
                        status = "SUCCESS",
                        message = "تم الرفع إلى Google Drive بنجاح"
                    )
                )
                localResult.copy(
                    driveFileId = driveId,
                    message = "تم حفظ النسخة محليًا وعلى Google Drive بنجاح"
                )
            }
        } catch (e: Exception) {
            localResult.copy(
                success = false,
                message = "تم الحفظ محليًا فقط؛ تعذر الاتصال بـ Google Drive: ${e.localizedMessage ?: "لا يوجد اتصال"}"
            )
        }
    }

    suspend fun listGoogleDriveBackups(accessToken: String): Result<List<DriveBackupFile>> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://www.googleapis.com/drive/v3/files?q=" +
                    java.net.URLEncoder.encode("name contains 'khaldoun_backup_' and trashed = false", "UTF-8") +
                    "&fields=files(id,name,modifiedTime)&orderBy=modifiedTime desc"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer $accessToken")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(IllegalStateException("HTTP ${response.code}"))
                    }
                    val jsonObj = JSONObject(response.body?.string().orEmpty())
                    val arr = jsonObj.optJSONArray("files")
                    val list = mutableListOf<DriveBackupFile>()
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val item = arr.getJSONObject(i)
                            list.add(
                                DriveBackupFile(
                                    id = item.optString("id"),
                                    name = item.optString("name"),
                                    modifiedTime = item.optString("modifiedTime")
                                )
                            )
                        }
                    }
                    Result.success(list)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun downloadAndRestoreFromDrive(accessToken: String, fileId: String, fileName: String): BackupResult =
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                    .addHeader("Authorization", "Bearer $accessToken")
                    .get()
                    .build()
                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext BackupResult(false, "", fileName, 0, 0, message = "فشل تحميل النسخة من Drive (HTTP ${response.code})")
                    }
                    val payload = response.body?.string().orEmpty()
                    restoreFromJsonString(payload, fileName, "drive://$fileId")
                }
            } catch (e: Exception) {
                BackupResult(false, "", fileName, 0, 0, message = "خطأ أثناء الاستعادة من Drive: ${e.localizedMessage ?: ""}")
            }
        }
}
