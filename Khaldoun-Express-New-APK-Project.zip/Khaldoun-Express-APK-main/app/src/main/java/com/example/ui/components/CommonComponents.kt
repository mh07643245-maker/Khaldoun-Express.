package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.bulkpaste.BulkPasteDraftRow
import com.example.database.CompanyEntity
import com.example.database.ShipmentWithCompany
import com.example.shipments.CompanyFolder
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.ShipmentStatus
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.ErrorContainerLight
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.OnAmberContainer
import com.example.ui.theme.OnErrorContainerLight
import com.example.ui.theme.OnTealContainer
import com.example.ui.theme.PostponedBlue
import com.example.ui.theme.PostponedContainer
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealDelivered

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KhaldounTopBar(
    title: String,
    onSettingsClick: (() -> Unit)? = null,
    navigationIcon: (@Composable () -> Unit)? = null
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "خلدون إكسبريس – Khaldoun Express",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        navigationIcon = { navigationIcon?.invoke() },
        actions = {
            if (onSettingsClick != null) {
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier.testTag("topbar_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات"
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun CompanySelectorRow(
    companies: List<CompanyEntity>,
    selectedCompanyId: Long?,
    onSelect: (Long) -> Unit,
    onAddCompanyClick: () -> Unit,
    includeAllOption: Boolean = false,
    onSelectAll: (() -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "شركة الشحن",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            TextButton(
                onClick = onAddCompanyClick,
                modifier = Modifier.testTag("quick_add_company_button")
            ) {
                Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("إضافة شركة")
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (includeAllOption && onSelectAll != null) {
                FilterChip(
                    selected = selectedCompanyId == null,
                    onClick = onSelectAll,
                    label = { Text("جميع الشركات") },
                    modifier = Modifier.testTag("company_chip_all")
                )
            }
            companies.forEach { company ->
                FilterChip(
                    selected = selectedCompanyId == company.id,
                    onClick = { onSelect(company.id) },
                    label = { Text(company.name) },
                    modifier = Modifier.testTag("company_chip_${company.id}")
                )
            }
        }
        if (companies.isEmpty()) {
            Text(
                text = "لا توجد شركات مضافة بعد — اضغط (إضافة شركة) لبدء العمل.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun StatusPill(statusCode: String) {
    val status = ShipmentStatus.fromCode(statusCode)
    val (bg, fg) = when (status) {
        ShipmentStatus.INITIAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        ShipmentStatus.DELIVERED -> TealContainer to OnTealContainer
        ShipmentStatus.POSTPONED -> PostponedContainer to PostponedBlue
        ShipmentStatus.DELIVERY_ISSUE -> AmberContainer to OnAmberContainer
        ShipmentStatus.CANCELLED -> ErrorContainerLight to OnErrorContainerLight
    }
    Surface(
        color = bg,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = status.arabicLabel,
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun FolderPill(folderCode: String) {
    val folder = CompanyFolder.fromCode(folderCode)
    val (bg, fg) = if (folder == CompanyFolder.DELIVERED) {
        TealContainer to TealDelivered
    } else {
        AmberContainer to AmberAccent
    }
    Surface(color = bg, shape = MaterialTheme.shapes.small) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Folder, contentDescription = null, tint = fg, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                text = folder.arabicLabel,
                style = MaterialTheme.typography.labelSmall,
                color = fg,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ShipmentSummaryCard(
    item: ShipmentWithCompany,
    numeralStyle: NumeralStyle,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = item.shipment
    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("shipment_card_${s.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = s.customerName.ifBlank { "عميل بدون اسم" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                FolderPill(s.folder)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = PhoneNumberNormalizer.formatDigitsForDisplay(s.rawPhone, numeralStyle),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                StatusPill(s.statusCode)
            }
            if (s.address.isNotBlank()) {
                Text(
                    text = s.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الشركة: ${item.companyName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "الأصلي: ${CurrencyFormatter.formatEgp(s.originalPrice, numeralStyle)} | المسلم: ${CurrencyFormatter.formatEgp(s.deliveredPrice, numeralStyle)}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (s.notes.isNotBlank()) {
                Text(
                    text = "ملاحظة: ${s.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberAccent
                )
            }
        }
    }
}

@Composable
fun DraftImportRowCard(
    row: BulkPasteDraftRow,
    numeralStyle: NumeralStyle,
    onEdit: (BulkPasteDraftRow) -> Unit,
    onDelete: (Long) -> Unit
) {
    var editing by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("draft_row_card_${row.rowId}"),
        colors = CardDefaults.cardColors(
            containerColor = if (row.needsReview) {
                AmberContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(
            1.dp,
            if (row.needsReview) AmberAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    if (row.needsReview) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "يحتاج مراجعة",
                            tint = AmberAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        text = "#${row.lineNumber} - ${row.customerName.ifBlank { "(اسم مفقود)" }}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Row {
                    IconButton(onClick = { editing = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل السطر")
                    }
                    IconButton(onClick = { onDelete(row.rowId) }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف السطر", tint = ErrorCrimson)
                    }
                }
            }
            Text(
                text = "الهاتف: ${PhoneNumberNormalizer.formatDigitsForDisplay(row.rawPhone.ifBlank { "مفقود" }, numeralStyle)}   •   السعر: ${row.parsedPrice?.let { CurrencyFormatter.formatEgp(it, numeralStyle) } ?: row.rawPrice.ifBlank { "غير واضح" }}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "العنوان: ${row.address.ifBlank { "مفقود" }}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (row.issues.isNotEmpty()) {
                Text(
                    text = "تنبيه: ${row.issues.joinToString(" • ")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = OnAmberContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (editing) {
        var name by remember { mutableStateOf(row.customerName) }
        var phone by remember { mutableStateOf(row.rawPhone) }
        var address by remember { mutableStateOf(row.address) }
        var price by remember { mutableStateOf(row.rawPrice) }

        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("تعديل بيانات الأوردر #${row.lineNumber}") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم العميل") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("العنوان") })
                    OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("السعر (ج.م)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    onEdit(
                        row.copy(
                            customerName = name,
                            rawPhone = phone,
                            address = address,
                            rawPrice = price
                        )
                    )
                    editing = false
                }) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                TextButton(onClick = { editing = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
fun AddCompanyDialog(
    initialCompany: CompanyEntity? = null,
    onDismiss: () -> Unit,
    onConfirm: (name: String, code: String, phone: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(initialCompany?.name.orEmpty()) }
    var code by remember { mutableStateOf(initialCompany?.code.orEmpty()) }
    var phone by remember { mutableStateOf(initialCompany?.contactPhone.orEmpty()) }
    var notes by remember { mutableStateOf(initialCompany?.notes.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialCompany == null) "إضافة شركة شحن جديدة" else "تعديل بيانات الشركة") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الشركة *") },
                    singleLine = true,
                    modifier = Modifier.testTag("company_name_input")
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("كود الشركة (اختياري)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("هاتف التواصل (اختياري)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name, code, phone, notes) },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("save_company_button")
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
