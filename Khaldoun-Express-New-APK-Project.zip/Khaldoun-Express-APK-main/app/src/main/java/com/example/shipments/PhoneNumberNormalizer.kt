package com.example.shipments

/**
 * Pure utility for normalizing Arabic-Indic / Persian / Western numerals,
 * preserving leading zeros on Egyptian and general phone numbers,
 * and extracting last-5-digit lookup keys without treating them as unique IDs.
 */
object PhoneNumberNormalizer {

    private val bidiAndFormatCharsRegex = Regex("[\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069\\u00A0\\uFEFF]")
    private val nonDigitOrPlusRegex = Regex("[^0-9+]")
    private val phoneCandidateRegex = Regex("(?:\\+?20|0020)?0?1[0125][0-9\\s\\-]{7,10}|[0-9]{7,15}")

    /**
     * Converts Arabic-Indic (٠-٩) and Extended Arabic-Indic (۰-۹) digits to Western ASCII (0-9).
     */
    fun toWesternDigits(input: String): String {
        if (input.isEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                '٫' -> sb.append('.')
                '٬' -> {} // Arabic thousands separator ignored in numeric normalization
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Converts Western ASCII digits (0-9) to Arabic-Indic (٠-٩) for UI display when enabled.
     */
    fun toArabicIndicDigits(input: String): String {
        if (input.isEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '0'..'9' -> sb.append(('٠'.code + (ch.code - '0'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatDigitsForDisplay(input: String, style: NumeralStyle): String {
        val western = toWesternDigits(input)
        return when (style) {
            NumeralStyle.WESTERN -> western
            NumeralStyle.ARABIC_INDIC -> toArabicIndicDigits(western)
        }
    }

    /**
     * Normalizes a phone string while strictly preserving any leading '0'.
     * Strips formatting spaces/dashes/parentheses and BiDi control marks.
     * Converts international Egypt prefixes (+2010... / 002010...) to local 010... when appropriate,
     * while keeping local leading zeros intact.
     */
    fun normalize(rawPhone: String): String {
        val cleaned = toWesternDigits(rawPhone)
            .replace(bidiAndFormatCharsRegex, "")
            .trim()
        if (cleaned.isEmpty()) return ""

        val compact = cleaned.replace(nonDigitOrPlusRegex, "")
        val digitsOnly = when {
            compact.startsWith("+20") && compact.length >= 12 -> {
                val rest = compact.removePrefix("+20")
                if (rest.startsWith("0")) rest else "0$rest"
            }
            compact.startsWith("0020") && compact.length >= 13 -> {
                val rest = compact.removePrefix("0020")
                if (rest.startsWith("0")) rest else "0$rest"
            }
            else -> compact.replace("+", "")
        }
        return digitsOnly
    }

    /**
     * Preserves the raw phone string safely (strips BiDi invisible chars only, keeps leading zero and original script).
     */
    fun preserveRawPhone(rawPhone: String): String {
        return rawPhone.replace(bidiAndFormatCharsRegex, "").trim()
    }

    /**
     * Extracts the last 5 digits of the normalized phone number for fast secondary indexing/lookup.
     * Note: Never use this as a unique ID!
     */
    fun extractLast5Digits(phoneOrDigits: String): String {
        val normalized = normalize(phoneOrDigits)
        return if (normalized.length <= 5) normalized else normalized.takeLast(5)
    }

    /**
     * Checks if a string looks like a plausible phone number (handles Arabic/English digits & leading zeros).
     */
    fun isLikelyPhoneNumber(input: String): Boolean {
        val normalized = normalize(input)
        if (normalized.length !in 7..15) return false
        // Egyptian mobile numbers: 11 digits starting with 010/011/012/015, or 10 digits starting with 10/11/12/15,
        // or landline 8-10 digits starting with 0
        return normalized.startsWith("01") && normalized.length == 11 ||
            (normalized.length in 8..15 && (normalized.startsWith("0") || normalized.length >= 9))
    }

    /**
     * Extracts candidate phone numbers from noisy OCR text (supports mixed Arabic/English digits).
     */
    fun extractPhoneCandidatesFromOcr(ocrText: String): List<String> {
        val western = toWesternDigits(ocrText)
            .replace(bidiAndFormatCharsRegex, " ")
            .replace('O', '0')
            .replace('o', '0')
            .replace('I', '1')
            .replace('l', '1')

        val candidates = linkedSetOf<String>()
        for (match in phoneCandidateRegex.findAll(western)) {
            val normalized = normalize(match.value)
            if (normalized.length in 8..15) {
                candidates.add(normalized)
            } else if (normalized.length == 10 && normalized.startsWith("1") &&
                normalized[1] in charArrayOf('0', '1', '2', '5')
            ) {
                // Recover Egyptian mobile if OCR clipped the leading 0 on label edge
                candidates.add("0$normalized")
            }
        }
        // Prefer 11-digit Egyptian mobile numbers first
        return candidates.sortedByDescending {
            when {
                it.length == 11 && it.startsWith("01") -> 3
                it.startsWith("0") && it.length >= 10 -> 2
                else -> 1
            }
        }
    }

    /**
     * Parses a price string cleanly without corrupting digits or inventing numbers.
     * Returns null if unparseable or negative.
     */
    fun parsePrice(rawPrice: String): Double? {
        val western = toWesternDigits(rawPrice)
            .replace(bidiAndFormatCharsRegex, "")
            .replace("ج.م", "")
            .replace("جنيه", "")
            .replace("EGP", "", ignoreCase = true)
            .replace("LE", "", ignoreCase = true)
            .replace(",", "")
            .trim()
        if (western.isEmpty()) return null
        val match = Regex("^[0-9]+(?:\\.[0-9]+)?$").find(western)
            ?: Regex("([0-9]+(?:\\.[0-9]+)?)").find(western)
            ?: return null
        val value = match.groupValues.firstOrNull()?.toDoubleOrNull() ?: return null
        return if (value >= 0.0) value else null
    }
}
