package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.app.KhaldounExpressApp
import com.example.backup.BackupWorker
import com.example.bulkpaste.ImportShipmentsScreen
import com.example.companies.CompaniesScreen
import com.example.companies.CompanyDetailScreen
import com.example.navigation.RouteCompanies
import com.example.navigation.RouteCompanyDetail
import com.example.navigation.RouteDashboard
import com.example.navigation.RouteImport
import com.example.navigation.RouteReports
import com.example.navigation.RouteSettings
import com.example.navigation.RouteStock
import com.example.reports.ReportsScreen
import com.example.settings.SettingsScreen
import com.example.stock.StockScreen
import com.example.ui.ImportTab
import com.example.ui.ImportViewModel
import com.example.ui.MainViewModel
import com.example.ui.ReportsViewModel
import com.example.ui.StockViewModel
import com.example.ui.components.AddCompanyDialog
import com.example.ui.components.KhaldounTopBar
import com.example.ui.screens.DashboardScreen
import com.example.ui.theme.KhaldounExpressTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appContainer = (application as KhaldounExpressApp).container
        BackupWorker.schedulePeriodicBackup(applicationContext)
        setContent {
            KhaldounExpressTheme {
                KhaldounMainApp(appContainer = appContainer)
            }
        }
    }
}

@Composable
fun KhaldounMainApp(appContainer: com.example.app.AppContainer) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val mainVm: MainViewModel = viewModel(factory = MainViewModel.factory(context, appContainer))
    val importVm: ImportViewModel = viewModel(factory = ImportViewModel.factory(context, appContainer))
    val stockVm: StockViewModel = viewModel(factory = StockViewModel.factory(appContainer))
    val reportsVm: ReportsViewModel = viewModel(factory = ReportsViewModel.factory(context, appContainer))

    val summary by mainVm.dashboardSummary.collectAsStateWithLifecycle()
    val companyCounts by mainVm.companyCounts.collectAsStateWithLifecycle()
    val allCompanies by mainVm.allCompanies.collectAsStateWithLifecycle()
    val selectableCompanies by mainVm.selectableCompanies.collectAsStateWithLifecycle()
    val archives by mainVm.dailyArchives.collectAsStateWithLifecycle()
    val backupRecords by mainVm.backupRecords.collectAsStateWithLifecycle()
    val settings by mainVm.settings.collectAsStateWithLifecycle()
    val endOfDayState by mainVm.endOfDayState.collectAsStateWithLifecycle()
    val mainMessage by mainVm.statusMessage.collectAsStateWithLifecycle()
    val ocrDiagnostics by mainVm.ocrDiagnostics.collectAsStateWithLifecycle()
    val driveBackups by mainVm.driveBackups.collectAsStateWithLifecycle()
    val driveToken by mainVm.driveAccessToken.collectAsStateWithLifecycle()

    val importState by importVm.uiState.collectAsStateWithLifecycle()
    val searchQuery by stockVm.searchQuery.collectAsStateWithLifecycle()
    val searchResults by stockVm.searchResults.collectAsStateWithLifecycle()
    val selectedShipment by stockVm.selectedShipment.collectAsStateWithLifecycle()
    val selectedNotes by stockVm.selectedNotes.collectAsStateWithLifecycle()
    val selectedHistory by stockVm.selectedEditHistory.collectAsStateWithLifecycle()
    val cameraLookupState by stockVm.cameraLookupState.collectAsStateWithLifecycle()
    val liveDetectedText by stockVm.liveDetectedText.collectAsStateWithLifecycle()
    val liveEngineStats by stockVm.liveEngineStats.collectAsStateWithLifecycle()
    val stockMessage by stockVm.feedbackMessage.collectAsStateWithLifecycle()

    val reportsState by reportsVm.uiState.collectAsStateWithLifecycle()

    var showQuickAddCompany by remember { mutableStateOf(false) }

    LaunchedEffect(selectableCompanies) {
        if (importState.selectedCompanyId == null && selectableCompanies.isNotEmpty()) {
            importVm.selectCompany(selectableCompanies.first().id)
        }
    }

    LaunchedEffect(mainMessage) {
        mainMessage?.let {
            snackbarHostState.showSnackbar(it)
            mainVm.clearStatusMessage()
        }
    }
    LaunchedEffect(stockMessage) {
        stockMessage?.let {
            snackbarHostState.showSnackbar(it)
            stockVm.clearFeedback()
        }
    }
    LaunchedEffect(reportsState.message) {
        reportsState.message?.let {
            snackbarHostState.showSnackbar(it)
            reportsVm.clearMessage()
        }
    }

    val navBackStack by navController.currentBackStackEntryAsState()
    val currentDest = navBackStack?.destination

    val topTitle = when {
        currentDest?.hasRoute<RouteDashboard>() == true -> "الرئيسية"
        currentDest?.hasRoute<RouteImport>() == true -> "إدخال الشحنات"
        currentDest?.hasRoute<RouteCompanies>() == true -> "الشركات"
        currentDest?.hasRoute<RouteCompanyDetail>() == true -> "ملف الشركة"
        currentDest?.hasRoute<RouteStock>() == true -> "المخزن"
        currentDest?.hasRoute<RouteReports>() == true -> "التقرير الشامل"
        currentDest?.hasRoute<RouteSettings>() == true -> "الإعدادات"
        else -> "خلدون إكسبريس"
    }

    val showBottomNav = currentDest?.hasRoute<RouteSettings>() != true &&
        currentDest?.hasRoute<RouteCompanyDetail>() != true

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (currentDest?.hasRoute<RouteSettings>() != true &&
                    currentDest?.hasRoute<RouteCompanyDetail>() != true
                ) {
                    KhaldounTopBar(
                        title = topTitle,
                        onSettingsClick = { navController.navigate(RouteSettings) }
                    )
                }
            },
            bottomBar = {
                if (showBottomNav && !useRail) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<RouteDashboard>() == true,
                            onClick = { navController.navigate(RouteDashboard) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                            label = { Text("الرئيسية") },
                            modifier = Modifier.testTag("nav_dashboard")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<RouteImport>() == true,
                            onClick = { navController.navigate(RouteImport()) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.AddCircle, contentDescription = "إدخال الشحنات") },
                            label = { Text("إدخال") },
                            modifier = Modifier.testTag("nav_import")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<RouteCompanies>() == true,
                            onClick = { navController.navigate(RouteCompanies) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Business, contentDescription = "الشركات") },
                            label = { Text("الشركات") },
                            modifier = Modifier.testTag("nav_companies")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<RouteStock>() == true,
                            onClick = { navController.navigate(RouteStock()) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Inventory2, contentDescription = "المخزن") },
                            label = { Text("المخزن") },
                            modifier = Modifier.testTag("nav_stock")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<RouteReports>() == true,
                            onClick = {
                                reportsVm.generateReport()
                                navController.navigate(RouteReports) { launchSingleTop = true }
                            },
                            icon = { Icon(Icons.Default.Assessment, contentDescription = "التقرير الشامل") },
                            label = { Text("التقارير") },
                            modifier = Modifier.testTag("nav_reports")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && showBottomNav) {
                    NavigationRail {
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteDashboard>() == true,
                            onClick = { navController.navigate(RouteDashboard) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                            label = { Text("الرئيسية") }
                        )
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteImport>() == true,
                            onClick = { navController.navigate(RouteImport()) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.AddCircle, contentDescription = "إدخال") },
                            label = { Text("إدخال") }
                        )
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteCompanies>() == true,
                            onClick = { navController.navigate(RouteCompanies) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Business, contentDescription = "الشركات") },
                            label = { Text("الشركات") }
                        )
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteStock>() == true,
                            onClick = { navController.navigate(RouteStock()) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Inventory2, contentDescription = "المخزن") },
                            label = { Text("المخزن") }
                        )
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteReports>() == true,
                            onClick = {
                                reportsVm.generateReport()
                                navController.navigate(RouteReports) { launchSingleTop = true }
                            },
                            icon = { Icon(Icons.Default.Assessment, contentDescription = "التقارير") },
                            label = { Text("التقارير") }
                        )
                        NavigationRailItem(
                            selected = currentDest?.hasRoute<RouteSettings>() == true,
                            onClick = { navController.navigate(RouteSettings) { launchSingleTop = true } },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") },
                            label = { Text("الإعدادات") }
                        )
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = RouteDashboard,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<RouteDashboard> {
                        DashboardScreen(
                            summary = summary,
                            companyCounts = companyCounts,
                            numeralStyle = settings.numeralStyle,
                            endOfDayState = endOfDayState,
                            onOpenBulkPaste = {
                                importVm.selectTab(ImportTab.BULK_PASTE)
                                navController.navigate(RouteImport(ImportTab.BULK_PASTE.name))
                            },
                            onOpenCameraStock = {
                                navController.navigate(RouteStock(openCamera = true))
                            },
                            onOpenImportHub = {
                                importVm.selectTab(ImportTab.EXCEL)
                                navController.navigate(RouteImport(ImportTab.EXCEL.name))
                            },
                            onOpenReports = {
                                reportsVm.generateReport()
                                navController.navigate(RouteReports)
                            },
                            onOpenCompanyDetail = { companyId ->
                                navController.navigate(RouteCompanyDetail(companyId))
                            },
                            onStartEndOfDay = mainVm::startEndOfDayFlow,
                            onConfirmEndOfDayStep1 = mainVm::advanceToSecondEndOfDayConfirm,
                            onConfirmEndOfDayStep2 = mainVm::executeEndOfDay,
                            onDismissEndOfDay = mainVm::cancelEndOfDayFlow
                        )
                    }

                    composable<RouteImport> { backStackEntry ->
                        val route = backStackEntry.toRoute<RouteImport>()
                        LaunchedEffect(route.initialTabName) {
                            runCatching { ImportTab.valueOf(route.initialTabName) }.getOrNull()?.let {
                                importVm.selectTab(it)
                            }
                        }
                        ImportShipmentsScreen(
                            uiState = importState,
                            companies = selectableCompanies,
                            numeralStyle = settings.numeralStyle,
                            releaseOcrWhenIdle = settings.releaseOcrWhenIdle,
                            onSelectTab = importVm::selectTab,
                            onSelectCompany = importVm::selectCompany,
                            onAddCompanyClick = { showQuickAddCompany = true },
                            onBulkTextChange = importVm::updateRawBulkText,
                            onAnalyzeBulk = importVm::analyzeBulkPaste,
                            onTogglePreview = importVm::togglePreviewMode,
                            onImportExcelUri = importVm::importExcelUri,
                            onImportImageUri = importVm::importImageUri,
                            onEditDraftRow = importVm::updateDraftRow,
                            onDeleteDraftRow = importVm::deleteDraftRow,
                            onCancelBatch = importVm::cancelBatch,
                            onSaveBatch = importVm::saveAllDrafts,
                            onAddSingleShipment = importVm::addManualSingleShipment
                        )
                    }

                    composable<RouteCompanies> {
                        CompaniesScreen(
                            companies = allCompanies,
                            companyCounts = companyCounts,
                            numeralStyle = settings.numeralStyle,
                            onAddCompany = mainVm::addCompany,
                            onUpdateCompany = mainVm::updateCompany,
                            onToggleActive = mainVm::toggleCompanyActive,
                            onToggleArchived = mainVm::toggleCompanyArchived,
                            onOpenCompanyDetail = { companyId ->
                                navController.navigate(RouteCompanyDetail(companyId))
                            }
                        )
                    }

                    composable<RouteCompanyDetail> { backStackEntry ->
                        val route = backStackEntry.toRoute<RouteCompanyDetail>()
                        val company = allCompanies.firstOrNull { it.id == route.companyId }
                        val shipmentsFlow = remember(route.companyId) {
                            mainVm.observeCompanyShipments(route.companyId)
                        }
                        val companyShipments by shipmentsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

                        CompanyDetailScreen(
                            company = company,
                            shipments = companyShipments,
                            numeralStyle = settings.numeralStyle,
                            onBack = { navController.popBackStack() },
                            onOpenShipment = { shipmentId ->
                                stockVm.selectShipment(shipmentId)
                                navController.navigate(RouteStock(openCamera = false))
                            }
                        )
                    }

                    composable<RouteStock> { backStackEntry ->
                        val route = backStackEntry.toRoute<RouteStock>()
                        var openCameraFlag by remember(route.openCamera) { mutableStateOf(route.openCamera) }
                        StockScreen(
                            searchQuery = searchQuery,
                            searchResults = searchResults,
                            selectedShipment = selectedShipment,
                            selectedNotes = selectedNotes,
                            selectedEditHistory = selectedHistory,
                            settings = settings,
                            ocrEngine = appContainer.ocrEngine,
                            cameraLookupState = cameraLookupState,
                            liveDetectedText = liveDetectedText,
                            liveEngineStats = liveEngineStats,
                            onSearchQueryChange = stockVm::updateSearchQuery,
                            onSelectShipment = stockVm::selectShipment,
                            onCameraDetected = stockVm::onLiveCameraDetected,
                            onResetCameraScan = stockVm::resetCameraScan,
                            onChooseCameraMatch = stockVm::chooseCameraMatch,
                            onSaveStockHandling = stockVm::saveStockHandling,
                            onSaveFullEdit = stockVm::saveFullShipmentEdit,
                            onDeleteShipment = stockVm::deleteShipment,
                            initialOpenCamera = openCameraFlag,
                            onConsumedInitialCamera = { openCameraFlag = false }
                        )
                    }

                    composable<RouteReports> {
                        ReportsScreen(
                            uiState = reportsState,
                            companies = allCompanies,
                            archives = archives,
                            numeralStyle = settings.numeralStyle,
                            onSelectReportType = reportsVm::selectReportType,
                            onSelectCompany = reportsVm::selectCompany,
                            onSelectFolder = reportsVm::selectFolder,
                            onSelectArchiveDate = reportsVm::selectArchiveDate,
                            onExportPdf = { onReady ->
                                reportsVm.exportCurrentReportToPdf(settings.numeralStyle, onReady)
                            },
                            onMessage = mainVm::showMessage
                        )
                    }

                    composable<RouteSettings> {
                        SettingsScreen(
                            settings = settings,
                            ocrDiagnostics = ocrDiagnostics,
                            deviceInfo = remember { mainVm.getDeviceInfo() },
                            backupRecords = backupRecords,
                            archives = archives,
                            driveBackups = driveBackups,
                            driveConnected = !driveToken.isNullOrBlank(),
                            onBack = { navController.popBackStack() },
                            onOpenCompanies = {
                                navController.popBackStack()
                                navController.navigate(RouteCompanies)
                            },
                            onNumeralStyleChange = mainVm::setNumeralStyle,
                            onOcrModeChange = mainVm::setOcrMode,
                            onCameraLowResChange = mainVm::setCameraLowResolution,
                            onCameraIntervalChange = mainVm::setCameraFrameIntervalMs,
                            onAutoBackupChange = mainVm::setAutoBackupEnabled,
                            onReleaseOcrIdleChange = mainVm::setReleaseOcrWhenIdle,
                            onCreateLocalBackup = mainVm::createManualLocalBackup,
                            onExportBackupUri = mainVm::exportBackupToUri,
                            onRestoreLocalFile = mainVm::restoreFromLocalBackup,
                            onRestoreUri = mainVm::restoreFromUri,
                            onDriveTokenObtained = mainVm::onGoogleDriveTokenObtained,
                            onUploadDriveBackup = mainVm::uploadBackupToGoogleDrive,
                            onRestoreDriveBackup = mainVm::restoreFromGoogleDrive,
                            onShowMessage = mainVm::showMessage
                        )
                    }
                }
            }
        }
    }

    if (showQuickAddCompany) {
        AddCompanyDialog(
            onDismiss = { showQuickAddCompany = false },
            onConfirm = { name, code, phone, notes ->
                mainVm.addCompany(name, code, phone, notes)
                showQuickAddCompany = false
            }
        )
    }
}
