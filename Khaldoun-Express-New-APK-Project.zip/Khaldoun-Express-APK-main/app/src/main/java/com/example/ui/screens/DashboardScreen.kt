package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.EventRepeat
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.database.CompanyShipmentCounts
import com.example.database.DashboardSummary
import com.example.shipments.CurrencyFormatter
import com.example.shipments.NumeralStyle
import com.example.shipments.PhoneNumberNormalizer
import com.example.ui.EndOfDayUiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealDelivered

@Composable
fun DashboardScreen(
    summary: DashboardSummary,
    companyCounts: List<CompanyShipmentCounts>,
    numeralStyle: NumeralStyle,
    endOfDayState: EndOfDayUiState,
    onOpenBulkPaste: () -> Unit,
    onOpenCameraStock: () -> Unit,
    onOpenImportHub: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenCompanyDetail: (Long) -> Unit,
    onStartEndOfDay: () -> Unit,
    onConfirmEndOfDayStep1: () -> Unit,
    onConfirmEndOfDayStep2: () -> Unit,
    onDismissEndOfDay: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp)
                    .clip(MaterialTheme.shapes.large)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_express_hero_1794555127463),
                    contentDescription = "شعار مركز عمليات خلدون إكسبريس",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    NavyPrimary.copy(alpha = 0.88f),
                                    NavyPrimary.copy(alpha = 0.52f)
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.align(Alignment.CenterStart),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "خلدون إكسبريس",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Khaldoun Express • إدارة الشحنات والمخزن",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AmberLight
                        )
                        Text(
                            text = "شحنات اليوم النشطة: ${PhoneNumberNormalizer.formatDigitsForDisplay(summary.totalTodayShipments.toString(), numeralStyle)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Primary quick action buttons (big, thumb-friendly)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenCameraStock,
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("dashboard_camera_scan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("بحث بالكاميرا")
                }
                FilledTonalButton(
                    onClick = onOpenBulkPaste,
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("dashboard_bulk_paste_button")
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("نسخ ولصق")
                }
            }
        }

        // Real-time Dashboard KPIs
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiStatCard(
                        title = "إجمالي شحنات اليوم",
                        value = PhoneNumberNormalizer.formatDigitsForDisplay(summary.totalTodayShipments.toString(), numeralStyle),
                        icon = Icons.Default.Inventory2,
                        accent = NavyPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiStatCard(
                        title = "في مجلد المسلم",
                        value = PhoneNumberNormalizer.formatDigitsForDisplay(summary.deliveredFolderCount.toString(), numeralStyle),
                        icon = Icons.Default.CheckCircle,
                        accent = TealDelivered,
                        modifier = Modifier.weight(1f)
                    )
                    KpiStatCard(
                        title = "في مجلد الحالات",
                        value = PhoneNumberNormalizer.formatDigitsForDisplay(summary.casesFolderCount.toString(), numeralStyle),
                        icon = Icons.Default.Warning,
                        accent = AmberAccent,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiAmountCard(
                        title = "إجمالي السعر الأصلي",
                        amount = CurrencyFormatter.formatEgp(summary.totalOriginalPrice, numeralStyle),
                        accent = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiAmountCard(
                        title = "إجمالي السعر المسلم",
                        amount = CurrencyFormatter.formatEgp(summary.totalDeliveredPrice, numeralStyle),
                        accent = TealDelivered,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Secondary Quick Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenImportHub,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("استيراد صور / Excel")
                }
                OutlinedButton(
                    onClick = onOpenReports,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("التقارير و PDF")
                }
            }
        }

        // Per-company breakdown
        item {
            Text(
                text = "الشحنات حسب الشركة (اليوم النشط)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        val activeCompanies = companyCounts.filter { !it.isArchived }
        if (activeCompanies.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Default.Business,
                    title = "لا توجد شركات شحن مسجلة بعد",
                    subtitle = "أضف شركات الشحن الخاصة بك ثم استورد الأوردرات عبر النسخ واللصق أو Excel أو الصور.",
                    actionLabel = "إدخال شحنات الآن",
                    onAction = onOpenBulkPaste
                )
            }
        } else {
            items(activeCompanies, key = { it.companyId }) { item ->
                Card(
                    onClick = { onOpenCompanyDetail(item.companyId) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_company_card_${item.companyId}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.companyName + if (!item.isActive) " (معطلة)" else "",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "المسلم: ${PhoneNumberNormalizer.formatDigitsForDisplay(item.deliveredFolderCount.toString(), numeralStyle)}  •  الحالات: ${PhoneNumberNormalizer.formatDigitsForDisplay(item.casesFolderCount.toString(), numeralStyle)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${PhoneNumberNormalizer.formatDigitsForDisplay(item.totalCount.toString(), numeralStyle)} شحنة",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = CurrencyFormatter.formatEgp(item.totalOriginalPrice, numeralStyle),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // End of Day / Start New Day action
        item {
            Spacer(Modifier.height(4.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "إغلاق اليوم وأرشفة العمل",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "يتم أخذ نسخة احتياطية كاملة والتحقق منها، ثم حفظ تقرير اليوم في الأرشيف وإفراغ قوائم العمل النشطة فقط دون حذف أي بيانات سابقة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onStartEndOfDay,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("end_of_day_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                    ) {
                        Icon(Icons.Default.EventRepeat, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("إنهاء اليوم / بدء يوم جديد", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Two-step End-of-Day Confirmation Dialogs
    when (endOfDayState) {
        EndOfDayUiState.Idle -> Unit
        EndOfDayUiState.FirstConfirm -> {
            AlertDialog(
                onDismissRequest = onDismissEndOfDay,
                title = { Text("إنهاء اليوم / بدء يوم جديد") },
                text = {
                    Text(
                        "سيقوم التطبيق الآن بـ:\n" +
                            "1. إنشاء نسخة احتياطية كاملة والتحقق من سلامتها.\n" +
                            "2. حفظ جميع شحنات وتقارير اليوم في الأرشيف الدائم.\n" +
                            "3. بدء يوم عمل جديد بقوائم نشطة فارغة دون حذف قاعدة البيانات."
                    )
                },
                confirmButton = {
                    Button(
                        onClick = onConfirmEndOfDayStep1,
                        modifier = Modifier.testTag("eod_confirm_step1")
                    ) {
                        Text("متابعة للتأكيد النهائي")
                    }
                },
                dismissButton = {
                    TextButton(onClick = onDismissEndOfDay) { Text("إلغاء") }
                }
            )
        }
        EndOfDayUiState.SecondConfirm -> {
            AlertDialog(
                onDismissRequest = onDismissEndOfDay,
                title = { Text("تأكيد نهائي") },
                text = {
                    Text("هل أنت متأكد من إنهاء يوم العمل الحالي وأرشفة الشحنات النشطة الآن؟ ستظل كافة التقارير والبيانات محفوظة في الأرشيف.")
                },
                confirmButton = {
                    Button(
                        onClick = onConfirmEndOfDayStep2,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberAccent),
                        modifier = Modifier.testTag("eod_confirm_step2")
                    ) {
                        Text("نعم، نفّذ النسخ والأرشفة")
                    }
                },
                dismissButton = {
                    TextButton(onClick = onDismissEndOfDay) { Text("تراجع") }
                }
            )
        }
        EndOfDayUiState.Processing -> {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("جاري إنشاء النسخة الاحتياطية والأرشفة...") },
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Text("يرجى الانتظار لحين التحقق من حفظ النسخة الاحتياطية...")
                    }
                },
                confirmButton = {}
            )
        }
        is EndOfDayUiState.Completed -> {
            AlertDialog(
                onDismissRequest = onDismissEndOfDay,
                title = { Text(if (endOfDayState.success) "تم بدء يوم جديد" else "تعذر إتمام العملية") },
                text = { Text(endOfDayState.message) },
                confirmButton = {
                    Button(onClick = onDismissEndOfDay) { Text("حسنًا") }
                }
            )
        }
    }
}

@Composable
private fun KpiStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun KpiAmountCard(
    title: String,
    amount: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = amount,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}
