package com.example.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.ocr.OcrEngine
import com.example.ocr.OcrEngineMode
import com.example.shipments.PhoneNumberNormalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class CameraScannerConfig(
    val frameIntervalMs: Long = 400L,
    val lowResolutionMode: Boolean = false,
    val ocrMode: OcrEngineMode = OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT,
    val stabilityRequiredCount: Int = 2
)

data class CameraScanFrameResult(
    val detectedPhone: String,
    val last5Digits: String,
    val engineUsed: String,
    val inferenceTimeMs: Long,
    val isConfirmedStable: Boolean
)

/**
 * Decoupled CameraX barcode-style live scanner.
 * - Uses STRATEGY_KEEP_ONLY_LATEST so frames never queue up on mid-range OPPO A5.
 * - Uses 1280x720 (or 640x480 in battery saver) — never 50MP.
 * - Crops center phone-number ROI and throttles frames to protect CPU/battery.
 * - Requires stability consensus before triggering database lookup.
 */
class CameraScanner(
    private val context: Context,
    private val ocrEngine: OcrEngine
) {
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var scope: CoroutineScope? = null
    private val isProcessing = AtomicBoolean(false)

    @Volatile
    private var lastFrameTimestamp = 0L

    @Volatile
    private var lastCandidateLast5: String = ""

    @Volatile
    private var consecutiveMatches: Int = 0

    @Volatile
    private var lastTriggeredPhone: String = ""

    @Volatile
    private var lastTriggeredAtMs: Long = 0L

    @Volatile
    private var cameraProvider: ProcessCameraProvider? = null

    fun start(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        config: CameraScannerConfig,
        onFrameResult: (CameraScanFrameResult) -> Unit,
        onError: (String) -> Unit
    ) {
        stop()
        val activeScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope = activeScope

        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val targetSize = if (config.lowResolutionMode) {
                    Size(640, 480)
                } else {
                    Size(1280, 720)
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setTargetResolution(targetSize)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()

                imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    processFrame(imageProxy, config, activeScope, onFrameResult)
                }

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis
                )
            } catch (e: Exception) {
                onError("تعذر تشغيل الكاميرا: ${e.localizedMessage ?: "خطأ غير متوقع"}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun resetTriggerCooldown() {
        lastTriggeredPhone = ""
        lastTriggeredAtMs = 0L
        lastCandidateLast5 = ""
        consecutiveMatches = 0
    }

    fun stop() {
        try {
            cameraProvider?.unbindAll()
        } catch (_: Exception) {
        }
        scope?.cancel()
        scope = null
        isProcessing.set(false)
    }

    fun shutdown() {
        stop()
        analysisExecutor.shutdown()
    }

    private fun processFrame(
        imageProxy: ImageProxy,
        config: CameraScannerConfig,
        activeScope: CoroutineScope,
        onFrameResult: (CameraScanFrameResult) -> Unit
    ) {
        val now = System.currentTimeMillis()
        if (now - lastFrameTimestamp < config.frameIntervalMs || !isProcessing.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }
        lastFrameTimestamp = now

        val roiBitmap = try {
            extractCenterRoiBitmap(imageProxy)
        } catch (_: Exception) {
            null
        } finally {
            imageProxy.close()
        }

        if (roiBitmap == null) {
            isProcessing.set(false)
            return
        }

        activeScope.launch {
            try {
                val result = ocrEngine.scanPhoneRegion(roiBitmap, config.ocrMode)
                val bestPhone = result.phoneCandidates.firstOrNull()
                if (bestPhone != null) {
                    val last5 = PhoneNumberNormalizer.extractLast5Digits(bestPhone)
                    if (last5 == lastCandidateLast5) {
                        consecutiveMatches++
                    } else {
                        lastCandidateLast5 = last5
                        consecutiveMatches = 1
                    }

                    val elapsedSinceLastTrigger = System.currentTimeMillis() - lastTriggeredAtMs
                    val isSameAsRecent = bestPhone == lastTriggeredPhone && elapsedSinceLastTrigger < 3500L
                    val isStable = consecutiveMatches >= config.stabilityRequiredCount && !isSameAsRecent

                    if (isStable) {
                        lastTriggeredPhone = bestPhone
                        lastTriggeredAtMs = System.currentTimeMillis()
                    }

                    onFrameResult(
                        CameraScanFrameResult(
                            detectedPhone = bestPhone,
                            last5Digits = last5,
                            engineUsed = result.engineUsed,
                            inferenceTimeMs = result.inferenceTimeMs,
                            isConfirmedStable = isStable
                        )
                    )
                }
            } finally {
                roiBitmap.recycle()
                isProcessing.set(false)
            }
        }
    }

    /**
     * Extracts RGBA buffer from CameraX ImageProxy, applies sensor rotation, and crops
     * the center horizontal scan band (68% width x 28% height) for fast OCR on OPPO A5.
     */
    private fun extractCenterRoiBitmap(imageProxy: ImageProxy): Bitmap? {
        val plane = imageProxy.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        buffer.rewind()
        val width = imageProxy.width
        val height = imageProxy.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride

        val fullBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        if (rowStride == width * pixelStride) {
            fullBitmap.copyPixelsFromBuffer(buffer)
        } else {
            val rowBytes = ByteArray(rowStride)
            val packed = java.nio.ByteBuffer.allocate(width * height * 4)
            for (y in 0 until height) {
                buffer.get(rowBytes, 0, minOf(rowStride, buffer.remaining()))
                packed.put(rowBytes, 0, width * 4)
            }
            packed.rewind()
            fullBitmap.copyPixelsFromBuffer(packed)
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val rotated = if (rotation != 0) {
            val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
            Bitmap.createBitmap(fullBitmap, 0, 0, fullBitmap.width, fullBitmap.height, matrix, false)
                .also { fullBitmap.recycle() }
        } else {
            fullBitmap
        }

        val cropW = (rotated.width * 0.72f).toInt().coerceAtLeast(100)
        val cropH = (rotated.height * 0.28f).toInt().coerceAtLeast(80)
        val left = ((rotated.width - cropW) / 2).coerceAtLeast(0)
        val top = ((rotated.height - cropH) / 2).coerceAtLeast(0)

        return Bitmap.createBitmap(
            rotated,
            left,
            top,
            minOf(cropW, rotated.width - left),
            minOf(cropH, rotated.height - top)
        ).also {
            if (it !== rotated) rotated.recycle()
        }
    }
}
