package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.app.AppContainer
import com.example.database.EditHistoryEntity
import com.example.database.ShipmentNoteEntity
import com.example.database.ShipmentWithCompany
import com.example.shipments.CompanyFolder
import com.example.shipments.ShipmentStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface CameraLookupState {
    data object Scanning : CameraLookupState
    data class SingleFound(val shipment: ShipmentWithCompany, val detectedPhone: String) : CameraLookupState
    data class MultipleFound(val matches: List<ShipmentWithCompany>, val detectedPhone: String, val last5: String) : CameraLookupState
    data class NotFound(val detectedPhone: String, val last5: String) : CameraLookupState
}

@OptIn(ExperimentalCoroutinesApi::class)
class StockViewModel(private val container: AppContainer) : ViewModel() {

    private val repo = container.shipmentRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<ShipmentWithCompany>> = _searchQuery
        .flatMapLatest { q -> repo.observeSearchShipments(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedShipmentId = MutableStateFlow<Long?>(null)
    val selectedShipment: StateFlow<ShipmentWithCompany?> = _selectedShipmentId
        .flatMapLatest { id -> if (id == null) flowOf(null) else repo.observeShipmentById(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedNotes: StateFlow<List<ShipmentNoteEntity>> = _selectedShipmentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observeNotesForShipment(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedEditHistory: StateFlow<List<EditHistoryEntity>> = _selectedShipmentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observeEditHistoryForShipment(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _cameraLookupState = MutableStateFlow<CameraLookupState>(CameraLookupState.Scanning)
    val cameraLookupState: StateFlow<CameraLookupState> = _cameraLookupState.asStateFlow()

    private val _liveDetectedText = MutableStateFlow("")
    val liveDetectedText: StateFlow<String> = _liveDetectedText.asStateFlow()

    private val _liveEngineStats = MutableStateFlow("")
    val liveEngineStats: StateFlow<String> = _liveEngineStats.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectShipment(shipmentId: Long?) {
        _selectedShipmentId.value = shipmentId
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun onLiveCameraDetected(
        detectedPhone: String,
        last5: String,
        engineUsed: String,
        inferenceMs: Long,
        isConfirmedStable: Boolean
    ) {
        _liveDetectedText.value = detectedPhone
        _liveEngineStats.value = "$engineUsed • ${inferenceMs}ms"
        if (!isConfirmedStable) return

        viewModelScope.launch {
            val matches = repo.findByScannedPhoneOrLast5(detectedPhone)
            when {
                matches.isEmpty() -> {
                    _cameraLookupState.value = CameraLookupState.NotFound(detectedPhone, last5)
                }
                matches.size == 1 -> {
                    _selectedShipmentId.value = matches.first().shipment.id
                    _cameraLookupState.value = CameraLookupState.SingleFound(matches.first(), detectedPhone)
                }
                else -> {
                    _cameraLookupState.value = CameraLookupState.MultipleFound(matches, detectedPhone, last5)
                }
            }
        }
    }

    fun resetCameraScan() {
        _cameraLookupState.value = CameraLookupState.Scanning
        _liveDetectedText.value = ""
    }

    fun chooseCameraMatch(shipment: ShipmentWithCompany) {
        _selectedShipmentId.value = shipment.shipment.id
        _cameraLookupState.value = CameraLookupState.SingleFound(shipment, shipment.shipment.rawPhone)
    }

    fun saveStockHandling(
        shipmentId: Long,
        deliveredPrice: Double,
        status: ShipmentStatus,
        noteText: String
    ) {
        viewModelScope.launch {
            repo.handleShipmentInStock(
                shipmentId = shipmentId,
                deliveredPrice = deliveredPrice,
                status = status,
                noteText = noteText
            )
            _feedbackMessage.value = "تم حفظ المعالجة ونقل الشحنة تلقائيًا إلى مجلد الحالات"
        }
    }

    fun saveFullShipmentEdit(
        shipmentId: Long,
        customerName: String,
        rawPhone: String,
        address: String,
        originalPrice: Double,
        deliveredPrice: Double,
        status: ShipmentStatus,
        notes: String,
        folder: CompanyFolder
    ) {
        viewModelScope.launch {
            repo.updateShipmentDetails(
                shipmentId = shipmentId,
                customerName = customerName,
                rawPhone = rawPhone,
                address = address,
                originalPrice = originalPrice,
                deliveredPrice = deliveredPrice,
                status = status,
                notes = notes,
                folder = folder
            )
            _feedbackMessage.value = "تم تعديل بيانات الشحنة وحفظ سجل التعديلات"
        }
    }

    fun deleteShipment(shipmentId: Long) {
        viewModelScope.launch {
            repo.deleteShipmentPermanently(shipmentId)
            if (_selectedShipmentId.value == shipmentId) {
                _selectedShipmentId.value = null
            }
            _feedbackMessage.value = "تم حذف الشحنة نهائيًا"
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return StockViewModel(container) as T
                }
            }
    }
}
