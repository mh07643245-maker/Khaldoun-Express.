package com.example.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.app.AppContainer
import com.example.bulkpaste.BulkPasteDraftRow
import com.example.bulkpaste.BulkPasteImporter
import com.example.excelimport.ExcelImporter
import com.example.imageimport.ImageImporter
import com.example.repositories.DraftShipmentInput
import com.example.shipments.PhoneNumberNormalizer
import com.example.shipments.ShipmentSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class ImportTab(val arabicTitle: String) {
    BULK_PASTE("نسخ ولصق مجمّع"),
    IMAGE_OCR("استيراد صور"),
    EXCEL("استيراد Excel"),
    MANUAL_SINGLE("إدخال فردي")
}

data class ImportUiState(
    val selectedTab: ImportTab = ImportTab.BULK_PASTE,
    val selectedCompanyId: Long? = null,
    val rawBulkText: String = "",
    val draftRows: List<BulkPasteDraftRow> = emptyList(),
    val batchId: String = "",
    val showPreviewOnly: Boolean = false,
    val isBusy: Boolean = false,
    val statusBanner: String? = null,
    val rawOcrTextPreview: String = "",
    val ocrEngineInfo: String = "",
    val excelHeadersInfo: List<String> = emptyList(),
    val excelErrors: List<String> = emptyList()
) {
    val totalDetected: Int get() = draftRows.size
    val validCount: Int get() = draftRows.count { !it.needsReview }
    val needsReviewCount: Int get() = draftRows.count { it.needsReview }
}

class ImportViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val repo = container.shipmentRepository

    private val _uiState = MutableStateFlow(ImportUiState())
    val uiState: StateFlow<ImportUiState> = _uiState.asStateFlow()

    fun selectTab(tab: ImportTab) {
        _uiState.update { it.copy(selectedTab = tab, statusBanner = null) }
    }

    fun selectCompany(companyId: Long) {
        _uiState.update { it.copy(selectedCompanyId = companyId) }
    }

    fun updateRawBulkText(text: String) {
        _uiState.update { it.copy(rawBulkText = text) }
    }

    fun togglePreviewMode(previewOnly: Boolean) {
        _uiState.update { it.copy(showPreviewOnly = previewOnly) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun analyzeBulkPaste() {
        val raw = _uiState.value.rawBulkText
        if (raw.isBlank()) {
            _uiState.update { it.copy(statusBanner = "يرجى لصق بيانات الأوردرات أولًا") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = null) }
            val result = BulkPasteImporter.parseTabSeparatedBatch(raw)
            _uiState.update {
                it.copy(
                    draftRows = result.rows,
                    batchId = result.batchId,
                    isBusy = false,
                    showPreviewOnly = true,
                    statusBanner = "تم تحليل ${result.totalDetected} أوردر (سليم: ${result.validCount} | يحتاج مراجعة: ${result.needsReviewCount})"
                )
            }
        }
    }

    fun importExcelUri(uri: Uri, fileName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = null, excelErrors = emptyList()) }
            val result = ExcelImporter.importFromUri(appContext, uri, fileName)
            val batchKey = "excel_${fileName}_${result.rows.size}_${System.currentTimeMillis()}"
            _uiState.update {
                it.copy(
                    draftRows = result.rows,
                    batchId = batchKey,
                    excelHeadersInfo = result.detectedHeaders,
                    excelErrors = result.errorMessages,
                    isBusy = false,
                    showPreviewOnly = true,
                    statusBanner = if (result.rows.isNotEmpty()) {
                        "تمت قراءة ${result.totalDetected} أوردر من $fileName (سليم: ${result.validCount} | مراجعة: ${result.needsReviewCount})"
                    } else {
                        result.errorMessages.firstOrNull() ?: "لم يتم العثور على صفوف في ملف Excel"
                    }
                )
            }
        }
    }

    fun importImageUri(uri: Uri, releaseAfter: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = null) }
            val result = ImageImporter.importFromUri(appContext, uri, container.ocrEngine)
            if (releaseAfter) {
                container.ocrEngine.release()
            }
            val batchKey = "img_${System.currentTimeMillis()}_${result.rows.size}"
            _uiState.update {
                it.copy(
                    draftRows = result.rows,
                    batchId = batchKey,
                    rawOcrTextPreview = result.rawOcrText,
                    ocrEngineInfo = "${result.engineUsed} (${result.inferenceTimeMs}ms)",
                    isBusy = false,
                    showPreviewOnly = true,
                    statusBanner = if (result.rows.isNotEmpty()) {
                        "تم استخراج ${result.totalDetected} سطر من الصورة عبر ${result.engineUsed}"
                    } else {
                        "لم يتم اكتشاف صفوف واضحة في الصورة. يمكنك مراجعة النص المستخرج وتصحيحه."
                    }
                )
            }
        }
    }

    fun updateDraftRow(updated: BulkPasteDraftRow) {
        val revalidated = BulkPasteImporter.revalidateRow(updated)
        _uiState.update { state ->
            state.copy(
                draftRows = state.draftRows.map { if (it.rowId == revalidated.rowId) revalidated else it }
            )
        }
    }

    fun deleteDraftRow(rowId: Long) {
        _uiState.update { state ->
            state.copy(draftRows = state.draftRows.filterNot { it.rowId == rowId })
        }
    }

    fun cancelBatch() {
        _uiState.update {
            it.copy(
                rawBulkText = "",
                draftRows = emptyList(),
                batchId = "",
                showPreviewOnly = false,
                rawOcrTextPreview = "",
                excelHeadersInfo = emptyList(),
                excelErrors = emptyList(),
                statusBanner = "تم إلغاء الدفعة بالكامل"
            )
        }
    }

    fun saveAllDrafts(source: ShipmentSource) {
        val state = _uiState.value
        val companyId = state.selectedCompanyId
        if (companyId == null) {
            _uiState.update { it.copy(statusBanner = "اختر شركة الشحن أولًا قبل الحفظ") }
            return
        }
        val savable = state.draftRows.filter { it.isSavable }
        if (savable.isEmpty()) {
            _uiState.update { it.copy(statusBanner = "لا توجد أوردرات جاهزة للحفظ. راجع الحقول الناقصة.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true) }
            val inputs = savable.map { row ->
                DraftShipmentInput(
                    customerName = row.customerName,
                    rawPhone = row.rawPhone,
                    address = row.address,
                    originalPrice = row.parsedPrice ?: 0.0,
                    needsReview = row.needsReview
                )
            }
            val result = repo.saveShipmentBatch(
                companyId = companyId,
                items = inputs,
                source = source,
                batchId = state.batchId.ifBlank { UUID.randomUUID().toString() }
            )
            if (result.duplicateBatchBlocked) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = "تم حفظ هذه الدفعة مسبقًا — تم منع التكرار بنجاح."
                    )
                }
            } else {
                val skippedCount = state.draftRows.size - savable.size
                val extraMsg = if (skippedCount > 0) " (تم استبعاد $skippedCount سطور ناقصة لم تكتمل)" else ""
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        rawBulkText = "",
                        draftRows = emptyList(),
                        batchId = "",
                        showPreviewOnly = false,
                        statusBanner = "تم حفظ ${result.insertedCount} شحنة بحالة (تم) في مجلد المسلم$extraMsg"
                    )
                }
            }
        }
    }

    fun addManualSingleShipment(
        name: String,
        phone: String,
        address: String,
        priceText: String
    ) {
        val companyId = _uiState.value.selectedCompanyId
        if (companyId == null) {
            _uiState.update { it.copy(statusBanner = "اختر شركة الشحن أولًا") }
            return
        }
        val price = PhoneNumberNormalizer.parsePrice(priceText)
        if (name.isBlank() || phone.isBlank() || price == null) {
            _uiState.update { it.copy(statusBanner = "يرجى إدخال الاسم ورقم الهاتف والسعر الصحيح") }
            return
        }
        viewModelScope.launch {
            repo.addSingleShipment(companyId, name, phone, address, price)
            _uiState.update { it.copy(statusBanner = "تمت إضافة الشحنة بنجاح بحالة (تم)") }
        }
    }

    companion object {
        fun factory(appContext: Context, container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ImportViewModel(appContext.applicationContext, container) as T
                }
            }
    }
}
