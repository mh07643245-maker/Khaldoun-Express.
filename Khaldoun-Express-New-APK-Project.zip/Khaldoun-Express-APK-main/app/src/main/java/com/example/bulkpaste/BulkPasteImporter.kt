package com.example.bulkpaste

import com.example.shipments.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class BulkPasteDraftRow(
    val rowId: Long,
    val lineNumber: Int,
    val customerName: String,
    val rawPhone: String,
    val address: String,
    val rawPrice: String,
    val parsedPrice: Double?,
    val issues: List<String>
) {
    val needsReview: Boolean get() = issues.isNotEmpty()
    val isSavable: Boolean get() = customerName.isNotBlank() && rawPhone.isNotBlank() && parsedPrice != null
}

data class BulkPasteParseResult(
    val rows: List<BulkPasteDraftRow>,
    val totalDetected: Int,
    val validCount: Int,
    val needsReviewCount: Int,
    val batchId: String
)

object BulkPasteImporter {

    suspend fun parseTabSeparatedBatch(rawInput: String): BulkPasteParseResult =
        withContext(Dispatchers.Default) {
            val lines = rawInput
                .replace("\r\n", "\n")
                .replace("\r", "\n")
                .split("\n")

            val rows = mutableListOf<BulkPasteDraftRow>()
            var rowIdCounter = 1L

            lines.forEachIndexed { index, rawLine ->
                val trimmedLine = rawLine.trimEnd()
                if (trimmedLine.isBlank()) return@forEachIndexed

                val lineNumber = index + 1
                val columns = rawLine.split("\t")

                // Skip an explicit header row if pasted from Excel
                if (lineNumber == 1 && isHeaderLine(columns)) {
                    return@forEachIndexed
                }

                val colName = columns.getOrNull(0)?.trim().orEmpty()
                val colPhone = PhoneNumberNormalizer.preserveRawPhone(columns.getOrNull(1).orEmpty())
                val colAddress = columns.getOrNull(2)?.trim().orEmpty()
                val colPriceRaw = columns.getOrNull(3)?.trim().orEmpty()

                val issues = validateColumns(
                    columnCount = columns.size,
                    name = colName,
                    rawPhone = colPhone,
                    address = colAddress,
                    rawPrice = colPriceRaw
                )
                val parsedPrice = PhoneNumberNormalizer.parsePrice(colPriceRaw)

                rows.add(
                    BulkPasteDraftRow(
                        rowId = rowIdCounter++,
                        lineNumber = lineNumber,
                        customerName = colName,
                        rawPhone = colPhone,
                        address = colAddress,
                        rawPrice = colPriceRaw,
                        parsedPrice = parsedPrice,
                        issues = issues
                    )
                )
            }

            val validCount = rows.count { !it.needsReview }
            val reviewCount = rows.count { it.needsReview }
            val batchId = computeBatchHash(rawInput)

            BulkPasteParseResult(
                rows = rows,
                totalDetected = rows.size,
                validCount = validCount,
                needsReviewCount = reviewCount,
                batchId = batchId
            )
        }

    fun revalidateRow(row: BulkPasteDraftRow): BulkPasteDraftRow {
        val cleanPhone = PhoneNumberNormalizer.preserveRawPhone(row.rawPhone)
        val parsedPrice = PhoneNumberNormalizer.parsePrice(row.rawPrice)
        val issues = validateColumns(
            columnCount = 4,
            name = row.customerName.trim(),
            rawPhone = cleanPhone,
            address = row.address.trim(),
            rawPrice = row.rawPrice.trim()
        )
        return row.copy(
            customerName = row.customerName.trim(),
            rawPhone = cleanPhone,
            address = row.address.trim(),
            rawPrice = row.rawPrice.trim(),
            parsedPrice = parsedPrice,
            issues = issues
        )
    }

    private fun validateColumns(
        columnCount: Int,
        name: String,
        rawPhone: String,
        address: String,
        rawPrice: String
    ): List<String> {
        val issues = mutableListOf<String>()
        if (columnCount < 4) {
            issues.add("أعمدة ناقصة (المطلوب 4 أعمدة مفصولة بـ Tab)")
        } else if (columnCount > 4) {
            issues.add("أعمدة زائدة عن 4")
        }
        if (name.isBlank()) {
            issues.add("اسم العميل مفقود")
        }
        val normalizedPhone = PhoneNumberNormalizer.normalize(rawPhone)
        if (rawPhone.isBlank()) {
            issues.add("رقم الهاتف مفقود")
        } else if (normalizedPhone.length < 7) {
            issues.add("رقم الهاتف غير مكتمل")
        }
        if (address.isBlank()) {
            issues.add("العنوان مفقود")
        }
        val parsedPrice = PhoneNumberNormalizer.parsePrice(rawPrice)
        if (rawPrice.isBlank() || parsedPrice == null) {
            issues.add("السعر غير واضح")
        }
        return issues
    }

    private fun isHeaderLine(columns: List<String>): Boolean {
        if (columns.size < 2) return false
        val joined = columns.joinToString(" ").lowercase()
        val hasNameWord = joined.contains("اسم") || joined.contains("العميل") || joined.contains("name")
        val hasPhoneWord = joined.contains("هاتف") || joined.contains("موبايل") || joined.contains("تليفون") || joined.contains("phone")
        return hasNameWord && hasPhoneWord
    }

    private fun computeBatchHash(raw: String): String {
        val normalized = raw.trim()
        if (normalized.isEmpty()) return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }
}
