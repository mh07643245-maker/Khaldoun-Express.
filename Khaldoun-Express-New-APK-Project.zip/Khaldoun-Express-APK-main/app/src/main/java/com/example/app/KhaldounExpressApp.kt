package com.example.app

import android.app.Application
import com.example.backup.BackupManager
import com.example.database.LocalDatabase
import com.example.ocr.HybridTesseractOcrEngine
import com.example.ocr.OcrEngine
import com.example.reports.ReportsManager
import com.example.repositories.ShipmentRepository
import com.example.settings.AppPreferences

class AppContainer(application: Application) {
    val database: LocalDatabase by lazy { LocalDatabase.getInstance(application) }
    val shipmentRepository: ShipmentRepository by lazy { ShipmentRepository(database) }
    val reportsManager: ReportsManager by lazy { ReportsManager(shipmentRepository) }
    val backupManager: BackupManager by lazy { BackupManager(application, database) }
    val ocrEngine: OcrEngine by lazy { HybridTesseractOcrEngine(application) }
    val preferences: AppPreferences by lazy { AppPreferences(application) }
}

class KhaldounExpressApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
