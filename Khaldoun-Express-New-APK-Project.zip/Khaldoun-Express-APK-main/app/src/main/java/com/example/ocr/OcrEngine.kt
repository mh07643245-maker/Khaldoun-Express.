package com.example.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.example.shipments.PhoneNumberNormalizer
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

enum class OcrEngineMode(val code: String, val arabicLabel: String) {
    HYBRID_TESSERACT_AND_MLKIT("HYBRID", "محرك مزدوج: Tesseract (عربي/إنجليزي) + ML Kit للأرقام السريعة"),
    TESSERACT_ONLY("TESSERACT_ONLY", "Tesseract 5 محلي فقط (عربي + إنجليزي)"),
    TESSERACT_ARABIC_DIGITS("TESSERACT_ARABIC", "Tesseract محسن للأرقام العربية والإنجليزية");

    companion object {
        fun fromCode(code: String): OcrEngineMode =
            entries.firstOrNull { it.code == code } ?: HYBRID_TESSERACT_AND_MLKIT
    }
}

data class OcrRecognitionResult(
    val rawText: String,
    val phoneCandidates: List<String>,
    val engineUsed: String,
    val inferenceTimeMs: Long
)

data class OcrDiagnostics(
    val arabicModelReady: Boolean,
    val englishModelReady: Boolean,
    val activeBackendLabel: String,
    val paddleNote: String
)

interface OcrEngine {
    suspend fun getDiagnostics(): OcrDiagnostics
    suspend fun scanPhoneRegion(bitmap: Bitmap, mode: OcrEngineMode): OcrRecognitionResult
    suspend fun recognizeFullDocument(bitmap: Bitmap): OcrRecognitionResult
    fun release()
}

/**
 * Real offline OCR Engine powered by Tesseract 5 LSTM (Tesseract4Android) with bundled
 * ara.traineddata + eng.traineddata in assets/tessdata, optionally paired with ML Kit Latin
 * for rapid English digit acceleration on shipping labels (never ML Kit alone for Arabic).
 */
class HybridTesseractOcrEngine(context: Context) : OcrEngine {

    private val appContext = context.applicationContext
    private val tessDir = File(appContext.filesDir, "tesseract_data")
    private val tessdataFolder = File(tessDir, "tessdata")
    private val mutex = Mutex()

    @Volatile
    private var tessDigitsApi: TessBaseAPI? = null

    @Volatile
    private var tessFullDocApi: TessBaseAPI? = null

    private val mlKitLatinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    override suspend fun getDiagnostics(): OcrDiagnostics = withContext(Dispatchers.IO) {
        ensureTessdataCopied()
        val araExists = File(tessdataFolder, "ara.traineddata").length() > 100_000
        val engExists = File(tessdataFolder, "eng.traineddata").length() > 100_000
        OcrDiagnostics(
            arabicModelReady = araExists,
            englishModelReady = engExists,
            activeBackendLabel = "Tesseract 5 LSTM (ara+eng) + ML Kit Latin",
            paddleNote = "تم تضمين نماذج Tesseract 5 العربية والإنجليزية محليًا (5.4 MB)؛ نموذج PaddleOCR PP-OCRv5 متاح بصيغة Paddle PIR فقط ويحتاج تحويلًا إلى ONNX قبل التشغيل المباشر على ARM64."
        )
    }

    override suspend fun scanPhoneRegion(bitmap: Bitmap, mode: OcrEngineMode): OcrRecognitionResult =
        withContext(Dispatchers.Default) {
            if (bitmap.isRecycled) {
                return@withContext OcrRecognitionResult("", emptyList(), "تم إلغاء الإطار", 0L)
            }
            val startTime = System.currentTimeMillis()
            val preprocessed = preprocessForPhoneOcr(bitmap)
            val candidates = linkedSetOf<String>()
            val texts = mutableListOf<String>()
            var engineTag = "Tesseract (ara+eng)"

            try {
                // Fast ML Kit Latin pass when hybrid mode is active (handles clean English 010/011/012/015 digits in ~25-45ms)
                if (mode == OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT) {
                    val latinText = runMlKitLatin(preprocessed)
                    if (latinText.isNotBlank()) {
                        texts.add(latinText)
                        candidates.addAll(PhoneNumberNormalizer.extractPhoneCandidatesFromOcr(latinText))
                    }
                }

                // Always run Tesseract Arabic+English if no 11-digit Egyptian mobile was confidently found yet,
                // or whenever user selects Tesseract-only / Arabic mode
                val hasStrong11Digit = candidates.any { it.length == 11 && it.startsWith("01") }
                if (!hasStrong11Digit || mode != OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT) {
                    val tessText = runTesseractDigits(preprocessed)
                    if (tessText.isNotBlank()) {
                        texts.add(tessText)
                        candidates.addAll(PhoneNumberNormalizer.extractPhoneCandidatesFromOcr(tessText))
                    }
                    engineTag = if (mode == OcrEngineMode.HYBRID_TESSERACT_AND_MLKIT) {
                        "Tesseract 5 (ara+eng) + ML Kit"
                    } else {
                        "Tesseract 5 (ara+eng)"
                    }
                } else {
                    engineTag = "ML Kit Latin (مسار سريع)"
                }
            } finally {
                if (preprocessed !== bitmap) {
                    preprocessed.recycle()
                }
            }

            OcrRecognitionResult(
                rawText = texts.joinToString("\n").trim(),
                phoneCandidates = candidates.toList(),
                engineUsed = engineTag,
                inferenceTimeMs = System.currentTimeMillis() - startTime
            )
        }

    override suspend fun recognizeFullDocument(bitmap: Bitmap): OcrRecognitionResult =
        withContext(Dispatchers.Default) {
            val startTime = System.currentTimeMillis()
            val scaled = downscaleForMemorySafety(bitmap, maxDimension = 1600)
            val text = try {
                runTesseractFullPage(scaled)
            } finally {
                if (scaled !== bitmap) scaled.recycle()
            }
            val candidates = PhoneNumberNormalizer.extractPhoneCandidatesFromOcr(text)
            OcrRecognitionResult(
                rawText = text,
                phoneCandidates = candidates,
                engineUsed = "Tesseract 5 (ara+eng)",
                inferenceTimeMs = System.currentTimeMillis() - startTime
            )
        }

    override fun release() {
        try {
            tessDigitsApi?.recycle()
        } catch (_: Exception) {
        }
        tessDigitsApi = null
        try {
            tessFullDocApi?.recycle()
        } catch (_: Exception) {
        }
        tessFullDocApi = null
    }

    private suspend fun runTesseractDigits(bitmap: Bitmap): String = mutex.withLock {
        ensureTessdataCopied()
        val api = tessDigitsApi ?: TessBaseAPI().also { instance ->
            val initialized = instance.init(tessDir.absolutePath, "ara+eng")
            if (initialized) {
                instance.pageSegMode = TessBaseAPI.PageSegMode.PSM_AUTO
                instance.setVariable(
                    TessBaseAPI.VAR_CHAR_WHITELIST,
                    "0123456789٠١٢٣٤٥٦٧٨٩+ -:"
                )
            }
            tessDigitsApi = instance
        }
        return@withLock try {
            api.setImage(bitmap)
            api.utF8Text.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private suspend fun runTesseractFullPage(bitmap: Bitmap): String = mutex.withLock {
        ensureTessdataCopied()
        val api = tessFullDocApi ?: TessBaseAPI().also { instance ->
            val initialized = instance.init(tessDir.absolutePath, "ara+eng")
            if (initialized) {
                instance.pageSegMode = TessBaseAPI.PageSegMode.PSM_AUTO
            }
            tessFullDocApi = instance
        }
        return@withLock try {
            api.setImage(bitmap)
            api.utF8Text.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private suspend fun runMlKitLatin(bitmap: Bitmap): String {
        if (bitmap.isRecycled) return ""
        val safeCopy = bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: return ""
        return suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(safeCopy, 0)
            mlKitLatinRecognizer.process(image)
                .addOnCompleteListener { task ->
                    val text = if (task.isSuccessful) task.result?.text.orEmpty() else ""
                    if (!safeCopy.isRecycled) {
                        safeCopy.recycle()
                    }
                    if (cont.isActive) {
                        cont.resume(text)
                    }
                }
        }
    }

    private fun ensureTessdataCopied() {
        if (!tessdataFolder.exists()) {
            tessdataFolder.mkdirs()
        }
        listOf("ara.traineddata", "eng.traineddata").forEach { fileName ->
            val target = File(tessdataFolder, fileName)
            if (!target.exists() || target.length() < 10_000L) {
                appContext.assets.open("tessdata/$fileName").use { input ->
                    target.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }
    }

    private fun preprocessForPhoneOcr(src: Bitmap): Bitmap {
        val scaled = downscaleForMemorySafety(src, maxDimension = 960)
        val result = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        // High-contrast grayscale improves both Arabic-Indic and English digit separation on thermal shipping labels
        val contrast = 1.45f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val matrix = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) }
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        if (scaled !== src) scaled.recycle()
        return result
    }

    private fun downscaleForMemorySafety(src: Bitmap, maxDimension: Int): Bitmap {
        val maxSide = maxOf(src.width, src.height)
        if (maxSide <= maxDimension) return src
        val ratio = maxDimension.toFloat() / maxSide.toFloat()
        val w = (src.width * ratio).toInt().coerceAtLeast(1)
        val h = (src.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }
}
