package com.example.backup

import android.content.Context
import androidx.work.Configuration
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.database.LocalDatabase
import java.util.concurrent.TimeUnit

class BackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = LocalDatabase.getInstance(applicationContext)
        val manager = BackupManager(applicationContext, db)
        val res = manager.createLocalBackup("AUTO_DAY")
        return if (res.success) Result.success() else Result.retry()
    }

    companion object {
        private const val WORK_NAME = "khaldoun_auto_daily_backup"

        private fun getWorkManagerSafely(context: Context): WorkManager {
            if (!WorkManager.isInitialized()) {
                WorkManager.initialize(
                    context.applicationContext,
                    Configuration.Builder().build()
                )
            }
            return WorkManager.getInstance(context.applicationContext)
        }

        fun schedulePeriodicBackup(context: Context) {
            val request = PeriodicWorkRequestBuilder<BackupWorker>(6, TimeUnit.HOURS)
                .build()
            getWorkManagerSafely(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancelPeriodicBackup(context: Context) {
            getWorkManagerSafely(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
